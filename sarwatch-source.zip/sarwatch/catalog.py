"""Public metadata discovery. Catalogue compatibility is not pixel validation."""
from datetime import datetime
from itertools import combinations
from urllib.parse import urlparse
import re

PATTERN = re.compile(r"^NISAR_L2_PR_GCOV_\d{3}_\d{3}_[AD]_\d{3}_\d{4}_[A-Z]{4}_[A-Z]_\d{8}T\d{6}_\d{8}T\d{6}_[PX]\d{5}_[A-Z]_[A-Z]_[A-Z]_\d{3}$")


def scene_identity(url: str, maturity: str) -> dict:
    name = urlparse(url).path.rsplit('/', 1)[-1].removesuffix('.h5')
    if not PATTERN.fullmatch(name):
        raise ValueError('Unsupported GCOV product name; cannot establish compatibility')
    t = name.split('_')
    return dict(id=name, url=url, maturity=maturity, track=t[5], direction=t[6],
                frame=t[7], mode=t[8], polarization_mode=t[9], configuration=t[10],
                start=datetime.strptime(t[11], '%Y%m%dT%H%M%S').isoformat()+'Z', crid=t[13])


def compatible_pairs(scenes: list[dict]) -> list[dict]:
    keys = ('maturity', 'track', 'direction', 'frame', 'mode', 'polarization_mode', 'configuration', 'crid')
    out = []
    unique = {s['id']: s for s in scenes}
    for a, b in combinations(sorted(unique.values(), key=lambda s: s['start']), 2):
        if a['start'] != b['start'] and all(a[k] == b[k] for k in keys):
            out.append({'before': a['id'], 'after': b['id'],
                        'status': 'metadata_candidate',
                        'remaining_checks': ['full AOI coverage', 'HDF5 grids and channels', 'quality masks', 'pixel validation']})
    return out


def search(bbox: list[float], start: str, end: str, maturity: str, limit: int = 250) -> dict:
    import asf_search as asf
    w, s, e, n = bbox
    if not (-180 <= w < e <= 180 and -90 <= s < n <= 90):
        raise ValueError('Expected west,south,east,north; antimeridian is not supported')
    wkt = f'POLYGON(({w} {s},{e} {s},{e} {n},{w} {n},{w} {s}))'
    results = asf.search(dataset='NISAR', processingLevel='GCOV', dataMaturity=maturity,
                         productionConfiguration='PR', intersectsWith=wkt,
                         start=start, end=end, maxResults=limit)
    scenes, rejected = [], 0
    for product in results:
        for url in product.get_urls():
            if not urlparse(url).path.endswith('.h5') or 'QA_STATS' in url:
                continue
            try:
                scene = scene_identity(url, maturity)
            except ValueError:
                rejected += 1
                continue
            scene['geometry'] = product.geojson()['geometry']
            scene['browse_urls'] = product.properties.get('browse',[])
            scene['browse_preview_url'] = '/api/scenes/'+scene['id']+'/browse.png' if scene['browse_urls'] else None
            scenes.append(scene)
    scenes = list({s['id']: s for s in scenes}.values())
    return dict(query=dict(bbox=bbox, start=start, end=end, maturity=maturity, limit=limit),
                scene_count=len(scenes), potentially_truncated=len(results) >= limit,
                unrecognized_products=rejected, scenes=scenes, pairs=compatible_pairs(scenes))
