"""Public metadata discovery. Catalogue compatibility is not pixel validation."""
from datetime import date, datetime, timedelta
from concurrent.futures import ThreadPoolExecutor
from itertools import combinations
from urllib.parse import urlparse
import re
from .limits import NISAR_SEARCH_DAYS, NISAR_START

PATTERN = re.compile(r"^NISAR_L2_PR_GCOV_\d{3}_\d{3}_[AD]_\d{3}_\d{4}_[A-Z]{4}_[A-Z]_\d{8}T\d{6}_\d{8}T\d{6}_[PX]\d{5}_[A-Z]_[A-Z]_[A-Z]_\d{3}$")
NISAR_MATURITIES = ('VALIDATED', 'PROVISIONAL', 'BETA')
COMPATIBILITY_FIELDS = ('maturity', 'track', 'direction', 'frame', 'mode', 'polarization_mode', 'configuration', 'crid')


def maturity_order(preferred):
    if preferred == 'AUTO':
        return NISAR_MATURITIES
    return tuple(dict.fromkeys((preferred, *NISAR_MATURITIES)))


def scene_identity(url: str, maturity: str) -> dict:
    name = urlparse(url).path.rsplit('/', 1)[-1].removesuffix('.h5')
    if not PATTERN.fullmatch(name):
        raise ValueError('Unsupported GCOV product name; cannot establish compatibility')
    t = name.split('_')
    return dict(id=name, url=url, maturity=maturity, track=t[5], direction=t[6],
                frame=t[7], mode=t[8], polarization_mode=t[9], configuration=t[10],
                start=datetime.strptime(t[11], '%Y%m%dT%H%M%S').isoformat()+'Z', crid=t[13])


def compatible_pairs(scenes: list[dict]) -> list[dict]:
    out = []
    unique = {s['id']: s for s in scenes}
    for a, b in combinations(sorted(unique.values(), key=lambda s: s['start']), 2):
        if a['start'] != b['start'] and all(a[k] == b[k] for k in COMPATIBILITY_FIELDS):
            out.append({'before': a['id'], 'after': b['id'],
                        'status': 'metadata_candidate',
                        'remaining_checks': ['full AOI coverage', 'HDF5 grids and channels', 'quality masks', 'pixel validation']})
    return out


def search(bbox: list[float], start: str, end: str, maturity: str, limit: int = 250) -> dict:
    import asf_search as asf
    w, s, e, n = bbox
    if not (-180 <= w < e <= 180 and -90 <= s < n <= 90):
        raise ValueError('Expected west,south,east,north; antimeridian is not supported')
    wkt = f'POLYGON(({w} {s},{e} {s},{e} {n},{w} {n},{w} {s}))'
    results = asf.search(dataset='NISAR', processingLevel='GCOV', dataMaturity=maturity,
                         productionConfiguration='PR', intersectsWith=wkt,
                         start=start, end=end, maxResults=limit)
    scenes, rejected = [], 0
    for product in results:
        for url in product.get_urls():
            if not urlparse(url).path.endswith('.h5') or 'QA_STATS' in url:
                continue
            try:
                scene = scene_identity(url, maturity)
            except ValueError:
                rejected += 1
                continue
            scene['geometry'] = product.geojson()['geometry']
            scene['browse_urls'] = product.properties.get('browse',[])
            scene['browse_preview_url'] = '/api/scenes/'+scene['id']+'/browse.png' if scene['browse_urls'] else None
            scene['collection_id'] = product.properties.get('conceptID')
            scenes.append(scene)
    scenes = list({s['id']: s for s in scenes}.values())
    return dict(query=dict(bbox=bbox, start=start, end=end, maturity=maturity, limit=limit),
                scene_count=len(scenes), potentially_truncated=len(results) >= limit,
                unrecognized_products=rejected, scenes=scenes, pairs=compatible_pairs(scenes))


def search_near_dates(bbox, start, end, limit, preferred):
    from shapely.geometry import box, shape

    result = {'scenes': [], 'pairs': [], 'potentially_truncated': False}
    if start >= end:
        return result
    midpoint = start + (end - start) / 2
    aoi = box(*bbox)
    launch = date.fromisoformat(NISAR_START)
    maturities = maturity_order(preferred)
    unavailable = False
    intersecting, covered = set(), set()
    covered_dates = set()
    for radius in NISAR_SEARCH_DAYS:
        span = timedelta(days=radius)
        early = (max(launch, start - span), min(midpoint, date.today(), start + span))
        late = (max(midpoint + timedelta(days=1), end - span), min(date.today(), end + span))
        if early[0] > early[1] or late[0] > late[1]:
            continue
        periods = [(early[0], late[1])] if early[1] + timedelta(days=1) == late[0] else [early, late]
        def lookup(maturity):
            found = [search(bbox, f'{first}T00:00:00Z', f'{last}T23:59:59Z', maturity, limit) for first, last in periods]
            return found

        candidates = []
        with ThreadPoolExecutor(max_workers=3) as pool:
            searches = [pool.submit(lookup, maturity) for maturity in maturities]
            for rank, query in enumerate(searches):
                try:
                    found = query.result()
                except Exception:
                    unavailable = True
                    continue
                observations = {}
                dates = {}
                for page in found:
                    result['potentially_truncated'] |= bool(page.get('potentially_truncated'))
                    for item in page['scenes']:
                        acquired = date.fromisoformat(item['start'][:10])
                        epoch = int(acquired > midpoint)
                        intersecting.add(epoch)
                        if shape(item['geometry']).covers(aoi):
                            covered.add(epoch)
                            covered_dates.add(acquired)
                            observations[item['id']] = item
                            dates[item['id']] = acquired
                pairs = [pair for pair in compatible_pairs(list(observations.values()))
                         if early[0] <= dates[pair['before']] <= early[1] and late[0] <= dates[pair['after']] <= late[1]]
                for pair in pairs:
                    distance = abs((dates[pair['before']] - start).days) + abs((dates[pair['after']] - end).days)
                    candidates.append((distance, rank, pair, observations[pair['before']], observations[pair['after']]))
        if candidates:
            candidates.sort(key=lambda item: item[:2] if preferred == 'AUTO' else (item[1], item[0]))
            chosen_level = candidates[0][1]
            candidates = [item for item in candidates if item[1] == chosen_level]
            scenes = {}
            for _, _, _, before, after in candidates:
                scenes.update({before['id']: before, after['id']: after})
            return {**result, 'scenes': list(scenes.values()), 'pairs': [item[2] for item in candidates]}
    if unavailable:
        raise RuntimeError('NISAR catalogue search was incomplete')
    reason = 'no_observations' if len(intersecting) < 2 else 'coverage' if len(covered) < 2 else 'compatibility'
    return {**result, 'radar_reason': reason, 'radar_dates': sorted(covered_dates)[:10]}


def recommend_dates(bbox, requested):
    """Find real alternative dates with full coverage and consistent metadata."""
    from shapely.geometry import box, shape

    aoi = box(*bbox)
    with ThreadPoolExecutor(max_workers=3) as pool:
        searches = [pool.submit(search, bbox, f'{NISAR_START}T00:00:00Z',
                                f'{date.today()}T23:59:59Z', level) for level in NISAR_MATURITIES]
        results = [query.result() for query in searches]

    groups = {}
    for result in results:
        for scene in result['scenes']:
            if shape(scene['geometry']).covers(aoi):
                signature = tuple(scene[key] for key in COMPATIBILITY_FIELDS)
                groups.setdefault(signature, set()).add(date.fromisoformat(scene['start'][:10]))

    options = {}
    for signature, available in groups.items():
        if len(available) >= len(requested):
            distance, dates = _nearest_sequence(sorted(available), requested)
            maturity = signature[0]
            rank = (distance, NISAR_MATURITIES.index(maturity))
            if dates not in options or rank < options[dates][0]:
                options[dates] = (rank, maturity)

    return {
        'options': [{'dates': dates, 'maturity': options[dates][1]}
                    for dates in sorted(options, key=lambda dates: (options[dates][0], dates))[:5]],
        'available_dates': sorted(set().union(*groups.values()),
                                  key=lambda day: (min(abs((day - wanted).days) for wanted in requested), day))[:10],
        'potentially_truncated': any(result.get('potentially_truncated') for result in results),
    }


def _nearest_sequence(available, requested):
    # At each date keep the least costly ordered path ending at that observation.
    paths = [(abs((day - requested[0]).days), (day,)) for day in available]
    for index, wanted in enumerate(requested[1:], start=1):
        following = []
        best = paths[0]
        for previous, day in zip(paths, available[index:]):
            best = min(best, previous)
            following.append((best[0] + abs((day - wanted).days), (*best[1], day)))
        paths = following
    return min(paths)
