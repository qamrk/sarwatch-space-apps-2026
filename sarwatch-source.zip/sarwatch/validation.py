"""Agreement against an automatic optical reference, not ground truth accuracy."""
import json
from datetime import datetime
from pathlib import Path
import numpy as np
import rasterio
from rasterio.warp import reproject,Resampling


def reference_agreement(prediction,reference_scl):
    valid=(prediction!=255)&np.isin(reference_scl,[4,5,6])
    observed=np.isin(prediction,[1,2]); expected=reference_scl==6
    tp=int((valid&observed&expected).sum());fp=int((valid&observed&~expected).sum())
    fn=int((valid&~observed&expected).sum());tn=int((valid&~observed&~expected).sum())
    precision=tp/(tp+fp) if tp+fp else None
    recall=tp/(tp+fn) if tp+fn else None
    iou=tp/(tp+fp+fn) if tp+fp+fn else None
    enough=int(valid.sum())>=100 and int((valid&expected).sum())>=100 and int((valid&~expected).sum())>=100
    return dict(reference='Sentinel-2 L2A automatic SCL; clear classes 4,5,6; water class 6',
                true_positive=tp,false_positive=fp,false_negative=fn,true_negative=tn,
                precision_vs_reference=precision,recall_vs_reference=recall,iou_vs_reference=iou,
                assessed_pixels=int(valid.sum()),clear_reference_fraction=float(valid.sum()/max(1,(prediction!=255).sum())),
                sufficient_reference=enough,
                spatial_agreement_gate=bool(enough and precision is not None and precision>=.8 and iou>=.65),
                limitations=['Automatic optical labels are not field ground truth.',
                             'Dates may differ and shoreline mixed pixels can disagree.',
                             'This is a case-specific comparison, not general algorithm accuracy.'])


def evaluate_reference(water_path,scl_path,reference_id,reference_time,radar_time,output,epoch='after'):
    if epoch not in ('before','after'):raise ValueError('Reference epoch must be before or after')
    with rasterio.open(water_path) as w,rasterio.open(scl_path) as ref:
        scl=np.zeros(w.shape,dtype='uint8')
        reproject(ref.read(1),scl,src_transform=ref.transform,src_crs=ref.crs,
                  dst_transform=w.transform,dst_crs=w.crs,resampling=Resampling.nearest,
                  src_nodata=0,dst_nodata=0,num_threads=1)
        classes=w.read(1)
        if epoch=='before':
            classes=np.where(classes==255,255,np.isin(classes,[1,3]).astype('uint8'))
        report=reference_agreement(classes,scl)
    gap=abs((datetime.fromisoformat(reference_time.replace('Z','+00:00'))-datetime.fromisoformat(radar_time.replace('Z','+00:00'))).total_seconds())/86400
    report.update(reference_id=reference_id,reference_time=reference_time,radar_time=radar_time,date_gap_days=gap,epoch=epoch,
                  gate_passed=report['spatial_agreement_gate'] and gap<=3 and report['clear_reference_fraction']>=.8,
                  status='optical_reference_agreement_assessed')
    Path(output).write_text(json.dumps(report,indent=2)+'\n')
    return report
