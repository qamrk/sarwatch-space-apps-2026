"""Georeferenced PNG layers for the web map, rendered in Web Mercator."""
from pathlib import Path
import numpy as np
import rasterio
from .case_assets import overlay


def render_layers(folder):
    folder=Path(folder);target=folder/'mapping';target.mkdir(exist_ok=True)
    layers=[]
    with rasterio.open(folder/'before.tif') as a,rasterio.open(folder/'after.tif') as b:
        arrays=[a.read(1),b.read(1)]
        values=np.concatenate([v[np.isfinite(v)] for v in arrays])
        lo,hi=np.percentile(values,[2,98]);hi=max(hi,lo+1)
        for name,src,data in zip(['before','after'],[a,b],arrays):
            gray=(np.nan_to_num(np.clip((data-lo)/(hi-lo),0,1),nan=0)*255).astype('uint8')
            rgba=np.stack([gray,gray,gray,np.where(np.isfinite(data),255,0).astype('uint8')],axis=-1)
            bounds=overlay(rgba,src,target/f'{name}.png')
            layers.append({'id':name,'file':f'{name}.png','bounds':bounds,'display_range_db':[float(lo),float(hi)]})
    with rasterio.open(folder/'comparison/delta_db.tif') as src:
        d=src.read(1);valid=np.isfinite(d);limit=max(float(np.percentile(np.abs(d[valid]),98)),1.)
        signed=np.nan_to_num(np.clip(d/limit,-1,1),nan=0)
        rgb=np.stack([1-np.maximum(-signed,0),1-np.abs(signed),1-np.maximum(signed,0)],axis=-1)
        rgba=np.concatenate([(rgb*255).astype('uint8'),np.where(valid,255,0).astype('uint8')[:,:,None]],axis=-1)
        bounds=overlay(rgba,src,target/'delta.png')
        layers.append({'id':'delta','file':'delta.png','bounds':bounds,'display_range_db':[-limit,limit]})
    if (folder/'water/water_changes.tif').is_file() and (folder/'water/water.png').is_file():
        from PIL import Image
        with rasterio.open(folder/'water/water_changes.tif') as src:
            bounds=overlay(np.asarray(Image.open(folder/'water/water.png')),src,target/'water.png')
            layers.append({'id':'water','file':'water.png','bounds':bounds})
    if (folder/'flood/potential_flood.tif').is_file():
        from PIL import Image
        with rasterio.open(folder/'flood/potential_flood.tif') as src:
            bounds=overlay(np.asarray(Image.open(folder/'flood/potential_flood.png')),src,target/'potential_flood.png')
            layers.append({'id':'potential_flood','file':'potential_flood.png','bounds':bounds})
    return layers
