"""One reproducible, byte-bounded analysis from public metadata to real layers."""
import json
import time
import resource
import sys
from pathlib import Path
from shapely.geometry import shape,box
from .catalog import compatible_pairs
from .gcov import inspect_window,validate_aoi
from .comparison import compare
from .water import analyze_water
from .limits import MAX_NETWORK_BYTES
from pyproj import Geod


def run_analysis(catalog,before_id,after_id,bbox,token,output_dir,theme='water',channel='auto',side_km=None):
    validate_aoi(bbox)
    byid={s['id']:s for s in catalog['scenes']}
    if before_id not in byid or after_id not in byid: raise ValueError('Refresh scene search before analysis')
    before,after=byid[before_id],byid[after_id]
    if before['start']>=after['start'] or not compatible_pairs([before,after]):
        raise ValueError('Select an ordered compatible scene pair')
    if not all(shape(s['geometry']).covers(box(*bbox)) for s in (before,after)):
        raise ValueError('Both scene footprints must fully cover the AOI')
    if theme not in ('water','forest','fire','agri_fire'):
        raise ValueError('Unsupported analysis theme')
    output_dir=Path(output_dir);output_dir.mkdir(parents=True,exist_ok=True)
    started=time.monotonic();remaining=MAX_NETWORK_BYTES;observations=[]
    for label,scene in [('before',before),('after',after)]:
        info=inspect_window(scene['url'],token,bbox,output_dir/f'{label}.tif',channel=channel,
                            budget=remaining,seconds=900-(time.monotonic()-started))
        remaining-=info['transferred_bytes'];observations.append(info)
        channel=info['channel']
    w,s,e,n=bbox
    aoi_area=abs(Geod(ellps='WGS84').polygon_area_perimeter([w,e,e,w],[s,s,n,n])[0])/1e6
    result={'theme':theme,'bbox':bbox,'observations':observations,
            'requested_side_km':side_km,'total_area_km2':side_km*side_km if side_km is not None else aoi_area,
            'aoi_geodesic_area_km2':aoi_area,'area_method':'valid_pixel_count_times_projected_pixel_area',
            'sources':[before,after], 'comparison':compare(output_dir/'before.tif',output_dir/'after.tif',output_dir/'comparison'),
            'water':{'status':'not_requested'},'ready_for_demo':False,
            'validation_status':'not_independently_validated'}
    result['flood']={'status':'not_requested'}
    if theme=='water':
        try:
            result['water']={'status':'experimental',**analyze_water(output_dir/'before.tif',output_dir/'after.tif',output_dir/'water')}
        except ValueError as exc:
            result['water']={'status':'unavailable','reason':str(exc)}
        if result['water']['status']=='experimental':
            from .flood import analyze_flood
            aux_budget=min(30_000_000,remaining)
            ledger={'remaining':aux_budget,'deadline':started+min(900,time.monotonic()-started+120)}
            try:
                result['flood']=analyze_flood(output_dir,bbox,ledger=ledger)
                result['water']['potential_flood_available']=True
            except Exception:
                # Missing auxiliary coverage must not discard the real SAR comparison.
                result['flood']={'status':'unavailable','reason':'Auxiliary water-history or terrain data are unavailable for this area; no inundation estimate is shown.'}
            finally:remaining-=aux_budget-ledger['remaining']
    from .map_layers import render_layers
    result['layers']=render_layers(output_dir)
    from .report import create_report
    from .exports import render_preview
    for lang in ('ru','en'):
        render_preview(result,output_dir,output_dir/f'preview-{lang}.png',lang)
        create_report(result,output_dir,output_dir/f'report-{lang}.pdf',lang)
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    if time.monotonic()-started>900:raise ValueError('Analysis time budget exceeded')
    result.update(transferred_bytes=MAX_NETWORK_BYTES-remaining,elapsed_seconds=round(time.monotonic()-started,3),
                  peak_process_rss_mib=round(rss/(1024**2 if sys.platform=='darwin' else 1024),1))
    (output_dir/'result.json').write_text(json.dumps(result,indent=2)+'\n')
    return result
