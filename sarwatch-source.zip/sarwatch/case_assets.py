"""Shared raster overlays and bundled report font."""
from pathlib import Path
import numpy as np
import rasterio
from rasterio.warp import calculate_default_transform,reproject,Resampling,transform_bounds
from PIL import Image

FONT=Path(__file__).parent/'assets/fonts/NotoSans-Regular.ttf'


def overlay(rgba,src,path):
    trans,width,height=calculate_default_transform(src.crs,3857,src.width,src.height,*src.bounds)
    dst=np.zeros((4,height,width),dtype='uint8')
    for i in range(4):
        reproject(rgba[:,:,i],dst[i],src_transform=src.transform,src_crs=src.crs,
                  dst_transform=trans,dst_crs=3857,resampling=Resampling.nearest,num_threads=1)
    Image.fromarray(np.moveaxis(dst,0,-1)).save(path)
    from rasterio.transform import array_bounds
    return list(transform_bounds(3857,4326,*array_bounds(height,width,trans)))
