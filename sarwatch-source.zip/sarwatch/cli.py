import argparse
import json
import os
from pathlib import Path
import resource
import sys
from dotenv import load_dotenv


def bbox(value):
    try:
        out=[float(x) for x in value.split(',')]
        if len(out)!=4: raise ValueError()
        return out
    except ValueError:
        raise argparse.ArgumentTypeError('Expected west,south,east,north')


def main():
    load_dotenv(override=False)
    parser=argparse.ArgumentParser(description='SARWatch data feasibility: metadata, then authenticated window read')
    sub=parser.add_subparsers(dest='command',required=True)
    s=sub.add_parser('search')
    s.add_argument('--bbox',type=bbox,default=[73.8,45.9,75.0,46.8])
    s.add_argument('--start',default='2026-06-17T00:00:00Z')
    s.add_argument('--end',default='2026-11-13T23:59:59Z')
    s.add_argument('--maturity',choices=['PROVISIONAL','VALIDATED'],default='PROVISIONAL')
    s.add_argument('--limit',type=int,default=250)
    s.add_argument('--out',default='work/catalog.json')
    w=sub.add_parser('window')
    w.add_argument('--url',required=True)
    w.add_argument('--bbox',type=bbox,required=True)
    w.add_argument('--channel',default='HHHH')
    w.add_argument('--out',default='work/window.tif')
    c=sub.add_parser('compare')
    c.add_argument('--before',required=True)
    c.add_argument('--after',required=True)
    c.add_argument('--out',default='work/comparison')
    c=sub.add_parser('water')
    c.add_argument('--before',required=True)
    c.add_argument('--after',required=True)
    c.add_argument('--out',default='work/water')
    c=sub.add_parser('validate-water')
    c.add_argument('--water',required=True)
    c.add_argument('--reference',required=True)
    c.add_argument('--reference-id',required=True)
    c.add_argument('--reference-time',required=True)
    c.add_argument('--radar-time',required=True)
    c.add_argument('--out',default='work/validation.json')
    c.add_argument('--epoch',choices=['before','after'],default='after')
    args=parser.parse_args()
    try:
        if args.command=='search':
            from .catalog import search
            if not 1<=args.limit<=1000: raise ValueError('limit must be 1..1000')
            result=search(args.bbox,args.start,args.end,args.maturity,args.limit)
            p=Path(args.out); p.parent.mkdir(parents=True,exist_ok=True)
            p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps({'catalog':str(p),'scenes':result['scene_count'],'metadata_pairs':len(result['pairs']),'potentially_truncated':result['potentially_truncated']}))
        elif args.command=='validate-water':
            from .validation import evaluate_reference
            print(json.dumps(evaluate_reference(args.water,args.reference,args.reference_id,args.reference_time,args.radar_time,args.out,args.epoch),ensure_ascii=False))
        elif args.command=='water':
            from .water import analyze_water
            print(json.dumps(analyze_water(args.before,args.after,args.out),ensure_ascii=False))
        elif args.command=='compare':
            from .comparison import compare
            print(json.dumps(compare(args.before,args.after,args.out),ensure_ascii=False))
        else:
            from .gcov import inspect_window
            result=inspect_window(args.url,os.environ.get('EARTHDATA_TOKEN',''),args.bbox,args.out,args.channel)
            rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            result['peak_rss_mb']=round(rss/(1024**2 if sys.platform=='darwin' else 1024),1)
            Path(args.out+'.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
            print(json.dumps(result,ensure_ascii=False))
    except Exception as exc:
        # Do not print request internals, tokens, environment values or credentials.
        from .range_reader import AccessError
        message=str(exc) if isinstance(exc,(AccessError,ValueError,KeyError)) else 'Dependency or remote-service failure; inspect environment/connectivity and retry'
        print(json.dumps({'status':'failed','error_type':type(exc).__name__,'message':message},ensure_ascii=False),file=sys.stderr)
        return 1
    return 0


if __name__=='__main__':
    raise SystemExit(main())
