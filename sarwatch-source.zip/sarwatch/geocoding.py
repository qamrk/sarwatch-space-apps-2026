"""Place search through the public ArcGIS World Geocoding Service."""
import requests


GEOCODER = 'https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/findAddressCandidates'


def search_places(query: str, language: str) -> list[dict]:
    response = requests.get(GEOCODER, params={
        'SingleLine': query,
        'langCode': language,
        'outSR': 4326,
        'outFields': 'Addr_type,Region,Country',
        'maxLocations': 6,
        'forStorage': 'false',
        'f': 'json',
    }, timeout=(3, 6))
    response.raise_for_status()
    data = response.json()
    if not isinstance(data, dict) or not isinstance(data.get('candidates'), list):
        raise ValueError('Invalid geocoding response')

    places = []
    seen = set()
    for candidate in data['candidates']:
        if not isinstance(candidate, dict):
            continue
        label = candidate.get('address')
        location = candidate.get('location')
        if not isinstance(label, str) or not label or not isinstance(location, dict):
            continue
        lon, lat = location.get('x'), location.get('y')
        if not _coordinate(lon, 180) or not _coordinate(lat, 90):
            continue
        key = (label, lon, lat)
        if key in seen:
            continue
        seen.add(key)
        attributes = candidate.get('attributes')
        country = attributes.get('Country') if isinstance(attributes, dict) else None
        places.append({
            'label': label,
            'latitude': lat,
            'longitude': lon,
            'country': country if isinstance(country, str) else None,
            'bounds': _bounds(candidate.get('extent'), lon, lat),
        })
    return places


def _coordinate(value, limit):
    return type(value) in (float, int) and -limit <= value <= limit


def _bounds(extent, lon, lat):
    if not isinstance(extent, dict):
        return None
    west, south, east, north = (extent.get(key) for key in ('xmin', 'ymin', 'xmax', 'ymax'))
    if (all(_coordinate(x, 180) for x in (west, east)) and
            all(_coordinate(y, 90) for y in (south, north)) and
            west < east and south < north and west <= lon <= east and south <= lat <= north):
        return [west, south, east, north]
    return None
