"""Conservative potential-inundation screening, never a confirmed flood label."""
from collections import OrderedDict
import io
import json
import math
from pathlib import Path
import time
from urllib.parse import urlparse
import numpy as np
import requests
import rasterio
from rasterio.warp import reproject,Resampling,transform_bounds
from rasterio.windows import from_bounds,Window
from scipy import ndimage
from PIL import Image
from .range_reader import RangeReader,AccessError
from .water import clean_mask
from .limits import MAX_AUXILIARY_PIXELS


class PublicRasterReader(RangeReader):
    """Reuse the tested bounded range protocol, with no Earthdata credential."""
    def __init__(self,url,ledger):
        io.RawIOBase.__init__(self)
        p=urlparse(url)
        allowed=(p.hostname=='s3.waw4-1.cloudferro.com' and p.path.startswith('/swift/v1/global-surface-water/download2024/Aggregated/VER1-5/occurrence/')) or (p.hostname=='copernicus-dem-30m.s3.amazonaws.com' and p.path.startswith('/Copernicus_DSM_COG_10_'))
        if p.scheme!='https' or p.query or p.username or p.password or p.port not in (None,443) or not allowed or not p.path.endswith('.tif'):
            raise AccessError('Unsupported public auxiliary raster')
        self.url=url;self.asset_url=url;self.token='';self.ledger=ledger
        self.session=requests.Session();self.deadline=ledger['deadline']
        self.block_size=65536;self.transferred=0;self.pos=0;self.cache=OrderedDict();self.size=None
        self.cache[0]=self._fetch(0,self.block_size-1)

    def _fetch(self,start,end):
        self.budget=self.transferred+self.ledger['remaining']
        previous=self.transferred
        try:return super()._fetch(start,end)
        finally:self.ledger['remaining']-=self.transferred-previous


def raster_window(url,target,ledger,resampling=Resampling.nearest):
    """Custom GDAL opener avoids Rasterio's full-file MemoryFile fallback."""
    opened=[]
    def opener(path,mode='rb'):
        if path!='aux.tif' or mode not in ('r','rb'):raise FileNotFoundError(path)
        reader=PublicRasterReader(url,ledger);opened.append(reader);return reader
    try:
        with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN='EMPTY_DIR',GDAL_CACHEMAX=16_000_000):
            with rasterio.open('aux.tif',opener=opener) as src:
                extent=transform_bounds(target.crs,src.crs,*target.bounds,densify_pts=21)
                window=from_bounds(*extent,transform=src.transform)
                window=Window(math.floor(window.col_off)-2,math.floor(window.row_off)-2,math.ceil(window.width)+4,math.ceil(window.height)+4)
                window=window.intersection(Window(0,0,src.width,src.height))
                if window.width*window.height>MAX_AUXILIARY_PIXELS:raise ValueError('Auxiliary pixel budget exceeded')
                array=src.read(1,window=window,masked=True).astype('float32').filled(np.nan)
                out=np.full(target.shape,np.nan,dtype='float32')
                reproject(array,out,src_transform=src.window_transform(window),src_crs=src.crs,
                          dst_transform=target.transform,dst_crs=target.crs,src_nodata=np.nan,
                          dst_nodata=np.nan,resampling=resampling,num_threads=1,warp_mem_limit=16)
                return out
    finally:
        for reader in opened:
            if not reader.closed:reader.close()


def auxiliary_urls(bbox):
    west,south,east,north=bbox
    lon=math.floor(west/10)*10;lat=math.ceil(north/10)*10
    if math.floor((east-1e-9)/10)*10!=lon or math.ceil((south+1e-9)/10)*10!=lat:
        raise ValueError('AOI crosses an auxiliary tile boundary; select a slightly smaller area')
    label=lambda v,pos,neg:f'{abs(v)}{pos if v>=0 else neg}'
    occurrence=f'https://s3.waw4-1.cloudferro.com/swift/v1/global-surface-water/download2024/Aggregated/VER1-5/occurrence/occurrence_{label(lon,"E","W")}_{label(lat,"N","S")}_v1_5_2024.tif'
    dem=[]
    for y in range(math.floor(south),math.floor(north)+1):
        for x in range(math.floor(west),math.floor(east)+1):
            tile=f'Copernicus_DSM_COG_10_{"N" if y>=0 else "S"}{abs(y):02d}_00_{"E" if x>=0 else "W"}{abs(x):03d}_00_DEM'
            dem.append(f'https://copernicus-dem-30m.s3.amazonaws.com/{tile}/{tile}.tif')
    return occurrence,dem


def screen(classes,occurrence,dem,pixel_size,pixel_area):
    if classes.shape!=occurrence.shape or dem.shape!=classes.shape:raise ValueError('Auxiliary grids must match the classification')
    if min(classes.shape)<3:raise ValueError('Insufficient terrain samples')
    valid=(classes!=255)&np.isfinite(occurrence)&(occurrence>=0)&(occurrence<=100)&np.isfinite(dem)
    # Neighbourhood validity prevents slope estimates through DEM gaps.
    valid &= ndimage.minimum_filter(np.isfinite(dem).astype('uint8'),size=3,mode='constant')==1
    gy,gx=np.gradient(dem,*pixel_size)
    slope=np.degrees(np.arctan(np.hypot(gx,gy)))
    permanent=occurrence>=90
    # Buffer known/current water by 60m to suppress geolocation and mixed shoreline pixels.
    known_water=permanent|np.isin(classes,[1,3])
    exclusion=(ndimage.distance_transform_edt(~known_water,sampling=pixel_size)<=60) if known_water.any() else np.zeros(classes.shape,dtype=bool)
    candidate=clean_mask((classes==2)&~exclusion&valid&(slope<=5),minimum_pixels=9)
    out=np.full(classes.shape,255,dtype='uint8');out[valid]=0;out[candidate]=1
    fraction=float(valid.sum()/max(1,(classes!=255).sum()))
    if fraction<.8:raise ValueError('Auxiliary coverage is insufficient for inundation screening')
    return out,dict(candidate_area_km2=float(candidate.sum()*pixel_area/1e6),assessed_fraction=fraction,
                    permanent_water_occurrence_percent=90,maximum_slope_degrees=5,shoreline_exclusion_metres=60,
                    minimum_component_pixels=9,classification='potential_inundation_not_confirmed',
                    limitations=['Dark land and wet soil can still cause false positives.',
                                 'Copernicus DEM is a surface model, not a hydraulic flood model.',
                                 'Historical water occurrence may miss recent permanent water.',
                                 'No independent flood validation or event attribution is performed.'])


def analyze_flood(folder,bbox,budget=30_000_000,seconds=120,ledger=None):
    folder=Path(folder);water=folder/'water/water_changes.tif'
    ledger=ledger if ledger is not None else {'remaining':budget,'deadline':time.monotonic()+seconds}
    budget=ledger['remaining']
    occurrence_url,dem_urls=auxiliary_urls(bbox)
    with rasterio.open(water) as src:
        occurrence=raster_window(occurrence_url,src,ledger)
        occurrence[(occurrence<0)|(occurrence>100)]=np.nan
        terrain=np.full(src.shape,np.nan,dtype='float32')
        for url in dem_urls:
            arr=raster_window(url,src,ledger,Resampling.bilinear)
            terrain[np.isfinite(arr)]=arr[np.isfinite(arr)]
        mask,stats=screen(src.read(1),occurrence,terrain,(abs(src.transform.e),abs(src.transform.a)),abs(src.transform.a*src.transform.e))
        profile=src.profile.copy();profile.update(dtype='uint8',nodata=255)
        out=folder/'flood';out.mkdir(exist_ok=True)
        with rasterio.open(out/'potential_flood.tif','w',**profile) as dst:dst.write(mask,1)
        rgba=np.zeros((*src.shape,4),dtype='uint8');rgba[mask==1]=(215,70,147,255)
        Image.fromarray(rgba).save(out/'potential_flood.png')
    stats.update(status='experimental',sources=[{'name':'JRC Global Surface Water v1.5 occurrence 1984–2024','url':occurrence_url,'attribution':'EC JRC/Google'},
                    *[{'name':'Copernicus DEM GLO-30 DSM','url':u,'attribution':'Copernicus DEM / ESA / Sinergise'} for u in dem_urls]],
                 transferred_bytes=budget-ledger['remaining'])
    (out/'flood.json').write_text(json.dumps(stats,indent=2)+'\n')
    return stats
