"""Transfer only browser-facing analysis results between compute hosts."""
import json
import re
import shutil
from pathlib import Path, PurePosixPath
from zipfile import BadZipFile, ZIP_DEFLATED, ZipFile

MAX_BUNDLE_BYTES = 60 * 1024 * 1024
PUBLIC_FILES = re.compile(
    r'(?:steps/[0-4]/)?(?:result\.json|(?:preview-(?:en|ru|kk)|comparison/comparison)\.png|'
    r'report-(?:en|ru|kk)\.pdf|mapping/(?:before|after|delta|water|potential_flood)\.png|water/water\.geojson)'
)


def package_bundle(folder, output):
    with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
        for path in sorted(folder.rglob('*')):
            name = path.relative_to(folder).as_posix()
            if path.is_file() and PUBLIC_FILES.fullmatch(name):
                archive.write(path, name)


def install_bundle(path, output):
    try:
        with ZipFile(path) as archive:
            files = archive.infolist()
            names = {entry.filename for entry in files}
            if len(files) != len(names) or 'result.json' not in names or len(files) > 100:
                raise ValueError('Invalid result manifest')
            if sum(entry.file_size for entry in files) > MAX_BUNDLE_BYTES:
                raise ValueError('Expanded result is too large')
            for entry in files:
                if not PUBLIC_FILES.fullmatch(entry.filename):
                    raise ValueError('Unknown result file')
                target = output.joinpath(*PurePosixPath(entry.filename).parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(entry) as source, target.open('wb') as destination:
                    shutil.copyfileobj(source, destination)
        result = json.loads((output/'result.json').read_text(encoding='utf-8'))
        if 'steps' in result:
            if not 2 <= len(result['steps']) <= 5:
                raise ValueError('Invalid number of intervals')
            intervals = [(f'steps/{i}/', step['result']) for i, step in enumerate(result['steps'])]
        else:
            intervals = [('', result)]
        for prefix, interval in intervals:
            if interval['water']['status'] is None or len(interval['sources']) != 2:
                raise ValueError('Invalid result metadata')
            required = {f'{prefix}mapping/{layer["file"]}' for layer in interval['layers']}
            required.update(f'{prefix}report-{lang}.pdf' for lang in ('en','ru','kk'))
            if not required <= names or not {f'{prefix}mapping/{name}.png' for name in ('before','after')} <= names:
                raise ValueError('Missing layers or reports')
        return result
    except (BadZipFile, KeyError, TypeError, UnicodeError, AttributeError) as exc:
        raise ValueError('Invalid result bundle') from exc
