"""Bounded readers for the predictors used by the environmental risk screen."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta, timezone
from functools import lru_cache
from io import BytesIO
from math import ceil, cos, floor, isfinite, log2, pi, radians
from time import monotonic
from urllib.parse import urlencode, urlparse

import numpy as np
import requests
from PIL import Image
from pyproj import Transformer
from rasterio.errors import RasterioError, WindowError
from rasterio.transform import from_bounds
from rasterio.warp import Resampling, reproject
from scipy import ndimage

from .flood import PublicRasterReader, raster_window
from .range_reader import AccessError, BudgetedRangeReader
from .weather import POWER, fetch_weather, value


WORLDCOVER = 'https://esa-worldcover.s3.eu-central-1.amazonaws.com/v200/2021/map/'
GFW_LOSS = 'https://tiles.globalforestwatch.org/umd_tree_cover_loss/v1.13/dynamic'
WATER = 'https://s3.waw4-1.cloudferro.com/swift/v1/global-surface-water/download2024/Aggregated/VER1-5/occurrence/'
DEM = 'https://copernicus-dem-30m.s3.amazonaws.com/'
GIBS = 'https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi'
GFS = 'https://api.open-meteo.com/v1/forecast'
HANSEN_LAST_YEAR = 2025
RASTER_SOURCES = {
    'land': ('ESA WorldCover', 'Покров поверхности по данным Sentinel-1/2', '2021',
             'https://esa-worldcover.org/en/data-access'),
    'terrain': ('Copernicus DEM GLO-30', 'Высота поверхности и уклон', '2011–2015 · съёмка TanDEM-X',
                'https://registry.opendata.aws/copernicus-dem/'),
    'water': ('JRC Global Surface Water 1.5', 'Повторяемость открытой воды по Landsat', '1984–2024',
              'https://global-surface-water.appspot.com/download'),
    'loss': ('Hansen Global Forest Change · Global Forest Watch',
             'Годы потери древесного покрова по Landsat, базовая сомкнутость крон от 30%', '2001–2025 · версия 1.13',
             'https://developers.google.com/earth-engine/datasets/catalog/UMD_hansen_global_forest_change_2025_v1_13'),
}
HOUR = 3600
WEATHER_FIELDS = ('rain', 'temperature_2m', 'relative_humidity_2m', 'wind_gusts_10m')
THERMAL_LAYERS = ('VIIRS_NOAA20_Thermal_Anomalies_375m_Day', 'VIIRS_SNPP_Thermal_Anomalies_375m_Day')
MERCATOR = Transformer.from_crs(4326, 3857, always_xy=True)
MERCATOR_EDGE = pi * 6378137


class PredictionRasterReader(BudgetedRangeReader):
    def __init__(self, url, ledger):
        p = urlparse(url)
        allowed = url.startswith(WORLDCOVER)
        if not allowed or p.query or p.fragment or not p.path.endswith('.tif'):
            raise AccessError('Unsupported prediction raster')
        super().__init__(url, ledger)


def _anchors(low, high, step):
    return range(floor(low / step) * step, ceil(high / step) * step, step)


def _tile_names(bbox, step, north_edge=False, suffix=False):
    west, south, east, north = bbox
    for bottom in _anchors(south, north, step):
        lat = bottom + step if north_edge else bottom
        for lon in _anchors(west, east, step):
            a, b = ('N' if lat >= 0 else 'S'), ('E' if lon >= 0 else 'W')
            if suffix:
                yield f'{abs(lon)}{b}_{abs(lat)}{a}'
            else:
                yield f'{a}{abs(lat):02d}', f'{b}{abs(lon):03d}'


def _urls(source, bbox):
    if source == 'land':
        return [f'{WORLDCOVER}ESA_WorldCover_10m_2021_v200_{lat}{lon}_Map.tif'
                for lat, lon in _tile_names(bbox, 3)]
    if source == 'water':
        return [f'{WATER}occurrence_{tile}_v1_5_2024.tif'
                for tile in _tile_names(bbox, 10, north_edge=True, suffix=True)]
    tiles = [f'Copernicus_DSM_COG_10_{lat}_00_{lon}_00_DEM' for lat, lon in _tile_names(bbox, 1)]
    return [f'{DEM}{tile}/{tile}.tif' for tile in tiles]


def raster(source, target):
    if source == 'loss':
        result = _forest_loss(target)
    else:
        result = _raster_window(source, target)
    name, description, edition, url = RASTER_SOURCES[source]
    return result, source_record(source, name, description, url, edition,
                                 'available' if np.isfinite(result).any() else 'unavailable')


def _raster_window(source, target):
    result = np.full(target.shape, np.nan, dtype=np.float32)
    ledger = {'remaining': 14_000_000, 'deadline': monotonic() + 29}
    reader = PredictionRasterReader if source == 'land' else PublicRasterReader
    resampling = Resampling.bilinear if source == 'terrain' else Resampling.nearest
    for url in _urls(source, target.bounds):
        try:
            data = raster_window(url, target, ledger, resampling=resampling, reader_class=reader,
                                 max_samples=(target.shape[0] * 2) ** 2)
        except (AccessError, requests.RequestException, ValueError, RasterioError, WindowError, OSError):
            continue
        valid = np.isfinite(data)
        if source == 'land':
            valid &= np.isin(data, (10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100))
        elif source == 'water':
            valid &= (data >= 0) & (data <= 100)
        result[valid] = data[valid]
    return result


def _decode_loss(image):
    # GFW encodes the year since 2000 in blue and sets alpha on loss pixels.
    # Reference: wri/gfw-tile-cache, TreeCoverLossBase.create_encoded_rgb.
    rgba = np.asarray(image.convert('RGBA'))
    blue, alpha = rgba[:, :, 2], rgba[:, :, 3]
    return np.where((alpha > 0) & (blue <= HANSEN_LAST_YEAR - 2000), blue, 0).astype(np.uint8, copy=False)


def _download_png(url, params, limit, timeout):
    payload = bytearray()
    with requests.get(url, params=params, stream=True, timeout=timeout) as response:
        response.raise_for_status()
        if not response.headers.get('Content-Type', '').startswith('image/png'):
            raise ValueError('Unexpected raster response format')
        for chunk in response.iter_content(65536):
            payload.extend(chunk)
            if len(payload) > limit:
                raise ValueError('Remote raster exceeds size limit')
    return payload


@lru_cache(maxsize=48)
def _loss_tile(z, x, y):
    url = f'{GFW_LOSS}/{z}/{x}/{y}.png'
    raw = _download_png(url, {'render_type': 'encoded', 'tree_cover_density_threshold': '30'}, 1_000_000, (4, 10))
    with Image.open(BytesIO(raw)) as image:
        if image.size not in ((256, 256), (512, 512)):
            raise ValueError('Unexpected forest tile dimensions')
        return _decode_loss(image)


def _forest_loss(target):
    west, south, east, north = target.bounds
    result = np.full(target.shape, np.nan, dtype=np.float32)
    if south >= 80 or north <= -60:
        return result
    left, bottom, right, top = MERCATOR.transform_bounds(max(west, -180), max(south, -60),
                                                         min(east, 180), min(north, 80))
    resolution = max(20, max(target.spacing) / 2)
    z = min(12, max(6, ceil(log2(2 * MERCATOR_EDGE * cos(radians((south + north) / 2)) / (512 * resolution)))))
    tile_span = (2 * MERCATOR_EDGE) / (2 ** z)
    col0, col1 = floor((left + MERCATOR_EDGE) / tile_span), ceil((right + MERCATOR_EDGE) / tile_span)
    row0, row1 = floor((MERCATOR_EDGE - top) / tile_span), ceil((MERCATOR_EDGE - bottom) / tile_span)
    tiles = [(x, y) for x in range(max(0, col0), min(2**z, col1))
             for y in range(max(0, row0), min(2**z, row1))]
    if len(tiles) > 12:
        return result

    def window(tile):
        x, y = tile
        try:
            band = _loss_tile(z, x, y)
        except (requests.RequestException, ValueError, OSError):
            return None
        w, n = -MERCATOR_EDGE + x * tile_span, MERCATOR_EDGE - y * tile_span
        transform = from_bounds(w, n - tile_span, w + tile_span, n, band.shape[1], band.shape[0])
        patch = np.full(target.shape, np.nan, dtype=np.float32)
        reproject(band, patch, src_transform=transform, src_crs='EPSG:3857',
                  dst_transform=target.transform, dst_crs=target.crs,
                  dst_nodata=np.nan, resampling=Resampling.nearest, num_threads=1)
        return patch

    with ThreadPoolExecutor(max_workers=4) as pool:
        for patch in pool.map(window, tiles):
            if patch is not None:
                valid = np.isfinite(patch)
                result[valid] = patch[valid]
    row_lats = north - (np.arange(target.shape[0]) + .5) * (north - south) / target.shape[0]
    result[(row_lats > 80) | (row_lats < -60), :] = np.nan
    return result


def source_record(key, name, description, url, edition, status='available'):
    return {'id': key, 'name': name, 'description': description, 'url': url,
            'edition': edition, 'status': status}


@lru_cache(maxsize=128)
def _forecast_payload(points, hour):
    response = requests.get(GFS, params={
        'latitude': ','.join(f'{lat:.4f}' for lat, _ in points),
        'longitude': ','.join(f'{lon:.4f}' for _, lon in points),
        'hourly': ','.join(WEATHER_FIELDS),
        'models': 'gfs_global',
        'timeformat': 'unixtime', 'timezone': 'GMT', 'wind_speed_unit': 'kmh',
        'past_days': 8, 'forecast_days': 8, 'cell_selection': 'nearest',
    }, timeout=(4, 12))
    response.raise_for_status()
    payload = response.json()
    rows = payload if isinstance(payload, list) else [payload]
    if len(rows) != len(points):
        raise ValueError('Unexpected forecast locations')
    return rows, datetime.now(timezone.utc)


def _hourly_values(raw, field, indexes):
    series = raw.get(field, [])
    if not indexes or max(indexes) >= len(series):
        return None
    values = [series[i] for i in indexes]
    if not all(type(v) in (int, float) and isfinite(v) for v in values):
        return None
    return np.asarray(values, dtype=np.float64)


def weather(points, now, forecast_hours):
    hour = int(now.timestamp() // HOUR)
    start = hour * HOUR
    rows, received = [], None
    try:
        rows, received = _forecast_payload(tuple(points), hour)
    except (requests.RequestException, KeyError, TypeError, ValueError):
        pass
    forecasts = []
    for row in rows:
        if not isinstance(row, dict):
            forecasts.append(None)
            continue
        raw = row.get('hourly', {})
        starts = {t: i for i, t in enumerate(raw.get('time', [])) if type(t) is int}
        future = [starts[t] for t in range(start + HOUR, start + (forecast_hours + 1) * HOUR, HOUR) if t in starts]
        past = [starts[t] for t in range(start - 7 * 24 * HOUR + HOUR, start + HOUR, HOUR) if t in starts]
        values = {field: _hourly_values(raw, field, future) for field in WEATHER_FIELDS}
        rain_past = _hourly_values(raw, 'rain', past)
        if (len(future) != forecast_hours or len(past) != 7 * 24 or rain_past is None
                or any(item is None for item in values.values())):
            forecasts.append(None)
            continue
        values['past_rain'] = np.clip(rain_past, 0, None)
        forecasts.append(values)
    count = sum(row is not None for row in forecasts)
    status = ('available' if count == len(points) else 'partial' if count else 'unavailable')
    source = source_record('weather', 'NOAA GFS · Open-Meteo',
                           'Почасовой прогноз и предшествующая погода. Узлы модели около 0,25°',
                           'https://open-meteo.com/en/docs/gfs-api', received.isoformat() if received else None, status)
    return forecasts or [None] * len(points), source


def satellite_rain(lat, lon, now):
    end = now.date() - timedelta(days=1)
    first = end - timedelta(days=4)
    query = urlencode({'parameters': 'IMERG_PRECTOT', 'community': 'AG', 'latitude': round(lat, 3),
                       'longitude': round(lon, 3), 'format': 'JSON', 'time-standard': 'UTC',
                       'start': first.strftime('%Y%m%d'), 'end': end.strftime('%Y%m%d')})
    wet = None
    observed = None
    data, _ = fetch_weather(POWER + '/daily/point?' + query, int(now.timestamp() // HOUR))
    for lag in (0, 1):
        recent = end - timedelta(days=lag)
        rain = [value(data, 'IMERG_PRECTOT', (recent - timedelta(days=i)).strftime('%Y%m%d')) for i in range(3)]
        if all(v is not None and v >= 0 for v in rain):
            wet, observed = sum(rain), recent.isoformat()
            break
    return wet, source_record('imerg', 'NASA GPM IMERG · NASA POWER',
                              'Спутниковая оценка осадков за три предшествующих полных дня',
                              'https://gpm.nasa.gov/data/imerg', observed, 'available' if wet is not None else 'unavailable')


def _thermal_mask(target, day, layer):
    shape = target.shape
    params = {'service': 'WMS', 'request': 'GetMap', 'version': '1.1.1', 'layers': layer,
              'srs': 'EPSG:4326', 'bbox': ','.join(map(str, target.bounds)),
              'width': shape[1], 'height': shape[0], 'format': 'image/png',
              'transparent': 'true', 'time': day.isoformat()}
    try:
        data = _download_png(GIBS, params, 500_000, (4, 8))
        with Image.open(BytesIO(data)) as image:
            if image.size != (shape[1], shape[0]):
                return None
            mask = np.asarray(image.convert('RGBA'))[:, :, 3] > 0
        return mask
    except (requests.RequestException, ValueError, OSError):
        return None


def thermal(target, now):
    days = [now.date() - timedelta(days=i) for i in range(1, 4)]
    # A rendered point provides positive evidence only. Transparent
    # imagery is not evidence that the selected area was observed.
    tasks = [(day, layer) for day in days for layer in THERMAL_LAYERS]
    with ThreadPoolExecutor(max_workers=3) as pool:
        masks = list(pool.map(lambda pair: _thermal_mask(target, *pair), tasks))
    observed = [day for (day, _), mask in zip(tasks, masks) if mask is not None and mask.any()]
    detected = np.zeros(target.shape, dtype=bool)
    for mask in masks:
        if mask is not None:
            detected |= mask
    detected = ndimage.binary_dilation(detected, iterations=2)
    return detected, source_record('viirs', 'NASA GIBS · VIIRS',
                                   'Недавние спутниковые тепловые аномалии, только положительный сигнал',
                                   'https://firms.modaps.eosdis.nasa.gov/', max(observed).isoformat() if observed else None,
                                   'available' if observed else 'unconfirmed')
