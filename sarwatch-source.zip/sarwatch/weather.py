"""Atmospheric context from NASA POWER for actual satellite observation dates."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from functools import lru_cache
import json
import math
import os
from statistics import mean
from time import time
from urllib.parse import urlencode

import requests


POWER = 'https://power.larc.nasa.gov/api/temporal'
PARAMETERS = 'PRECTOTCORR,T2M,RH2M,WS10M'
WINDOW = 14
MONTHS = 'JAN FEB MAR APR MAY JUN JUL AUG SEP OCT NOV DEC'.split()
FIRST_DATE = date(1981, 1, 1)


@lru_cache(maxsize=512)
def fetch(url, cache_hour):
    response = requests.get(url, timeout=(4, 15))
    response.raise_for_status()
    payload = response.json()
    return payload['properties']['parameter'], payload.get('header', {})


def value(data, key, day):
    number = data.get(key, {}).get(day)
    return number if isinstance(number, (float, int)) and math.isfinite(number) and number > -999 else None


def weather_window(data, normal, last):
    dates = [last - timedelta(days=offset) for offset in reversed(range(WINDOW))]
    rows = []
    for day in dates:
        key = day.strftime('%Y%m%d')
        rows.append({'date': day.isoformat(), 'rain_mm': value(data, 'PRECTOTCORR', key),
                     'temperature_c': value(data, 'T2M', key), 'humidity_pct': value(data, 'RH2M', key),
                     'wind_ms': value(data, 'WS10M', key)})
    result = {'start': rows[0]['date'], 'end': rows[-1]['date'], 'days': rows}
    count = sum(row['rain_mm'] is not None for row in rows)
    result['days_with_rain_data'] = count
    if count == WINDOW:
        result['rain_mm'] = round(sum(row['rain_mm'] for row in rows), 1)
    for key in ('temperature_c', 'humidity_pct', 'wind_ms'):
        samples = [row[key] for row in rows if row[key] is not None]
        if len(samples) >= 10:
            result[key] = round(mean(samples), 1)
    normals = [value(normal, 'PRECTOTCORR', MONTHS[day.month - 1]) for day in dates]
    if all(number is not None for number in normals):
        result['normal_rain_mm'] = round(sum(normals), 1)
    return result


def fetch_weather(url, cache_hour):
    try:
        return fetch(url, cache_hour)
    except (requests.RequestException, ValueError, KeyError):
        return {}, {}


def atmosphere(lat, lon, first, last, event_day=None):
    query = urlencode({'parameters': PARAMETERS, 'community': 'AG', 'latitude': lat,
                       'longitude': lon, 'format': 'JSON'})
    climate_url = POWER + '/climatology/point?' + query
    anchors = dict(before=first, after=last)
    if event_day:
        anchors['event'] = event_day

    # Nearby epochs share a request. Widely separated dates keep the payload small.
    periods = []
    for day in sorted(set(anchors.values())):
        start = max(FIRST_DATE, day - timedelta(days=WINDOW - 1))
        if periods and (day - periods[-1][0]).days <= 61:
            periods[-1][1] = day
        else:
            periods.append([start, day])
    urls = [f"{POWER}/daily/point?{query}&start={start:%Y%m%d}&end={end:%Y%m%d}&time-standard=UTC"
            for start, end in periods]

    cache_hour = int(time() // 3600)
    with ThreadPoolExecutor(max_workers=4) as pool:
        baseline = pool.submit(fetch_weather, climate_url, cache_hour)
        observations = [pool.submit(fetch_weather, url, cache_hour) for url in urls]
        updated = [observation.result()[0] for observation in observations]
        normal, header = baseline.result()
    data = {}
    for part in updated:
        for key, days in part.items():
            data.setdefault(key, {}).update(days)
    return {'latitude': lat, 'longitude': lon,
            'windows': {name: weather_window(data, normal, day) for name, day in anchors.items()},
            'baseline': header.get('range'), 'daily_urls': urls, 'climatology_url': climate_url}


def explain_with_ai(context, theme, sensor, metrics, event, lang):
    """Use the deployment's model key when one has been configured."""
    key = os.environ.get('OPENAI_API_KEY')
    if not key:
        return None
    evidence = {'theme': theme, 'sensor': sensor, 'metrics': metrics, 'event': event,
                'weather': {name: {k: v for k, v in window.items() if k != 'days'}
                            for name, window in context['windows'].items()},
                'baseline': context['baseline'], 'language': lang}
    model = os.environ.get('SARWATCH_AI_MODEL', 'gpt-4.1-mini')
    return model_explanation(model, json.dumps(evidence, ensure_ascii=False, sort_keys=True))


@lru_cache(maxsize=128)
def model_explanation(model, evidence):
    prompt = (
        'Explain a satellite comparison to the public in the supplied language, in at most 95 words. '
        'Use only the JSON evidence. Attribute any documented event cause to its supplied source. '
        'Distinguish possible weather contributions and ordinary seasonal differences from documented causes. '
        'The data are estimates for one grid cell, and 14-day weather alone cannot establish why a lake '
        'changed over years or identify a fire ignition. Missing values mean unavailable. '
        'Use plain text, no links, and express uncertainty explicitly.'
    )
    try:
        response = requests.post('https://api.openai.com/v1/responses',
                                 headers={'Authorization': 'Bearer ' + os.environ['OPENAI_API_KEY']},
                                 json={'model': model, 'instructions': prompt, 'input': evidence,
                                       'max_output_tokens': 280, 'store': False}, timeout=(5, 18))
        response.raise_for_status()
        return ' '.join(part['text'] for item in response.json().get('output', [])
                        if item.get('type') == 'message' for part in item.get('content', [])
                        if part.get('type') == 'output_text').strip() or None
    except (requests.RequestException, KeyError, ValueError):
        return None
