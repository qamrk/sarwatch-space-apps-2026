"""Find one consistent series of observations in disjoint date windows."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta

from .limits import LANDSAT_START, NISAR_START

MAX_DATES = 6


def find_chain(groups, compatible):
    """Keep only the best path to each scene, preserving the source's ranking."""
    paths = [(rank, [scene]) for rank, scene in enumerate(groups[0])]
    for group in groups[1:]:
        following = []
        for rank, scene in enumerate(group):
            previous = [(score, path) for score, path in paths if compatible(path[-1], scene)]
            if previous:
                score, path = min(previous, key=lambda item: item[0])
                following.append((score + rank, [*path, scene]))
        paths = following
    return min(paths, key=lambda item: item[0])[1] if paths else []


def search_series(coords, dates, sensor, maturity):
    from shapely.geometry import box, shape
    from . import catalog, landsat, modis
    import requests

    aoi = box(*coords)
    today = date.today()
    midpoints = [left + (right - left) / 2 for left, right in zip(dates, dates[1:])]
    windows = list(zip(dates, [date.fromisoformat(LANDSAT_START),
                              *(day + timedelta(days=1) for day in midpoints)], [*midpoints, today]))

    def optical(window, level):
        with requests.Session() as session:
            return landsat.epoch_options(session, aoi, *window)

    def radar(window, level):
        day, first, last = window
        first = max(first, date.fromisoformat(NISAR_START), day - timedelta(days=24))
        last = min(last, day + timedelta(days=24))
        found = catalog.search(coords, f'{first}T00:00:00Z', f'{last}T23:59:59Z', level)
        return sorted((scene for scene in found['scenes'] if shape(scene['geometry']).covers(aoi)),
                      key=lambda scene: abs((date.fromisoformat(scene['start'][:10]) - day).days))

    def overview(window, level):
        day, first, last = window
        item = modis.nearby_scene(coords, day, max(first, modis.START), last)
        return [item] if item else []

    sources = [('nisar', radar, lambda a, b: bool(catalog.compatible_pairs([a, b])), NISAR_START),
               ('landsat', optical, lambda a, b: a['_footprint'].intersection(b['_footprint']).area >= landsat.MIN_COVERAGE * aoi.area, LANDSAT_START),
               ('modis', overview, lambda a, b: True, modis.START.isoformat())]
    last_error = None
    searched = False
    for name, lookup, compatible, earliest in sources:
        if sensor not in ('auto', name) or dates[0].isoformat() < earliest:
            continue
        for level in (dict.fromkeys((maturity, 'VALIDATED', 'PROVISIONAL', 'BETA')) if name == 'nisar' and sensor == 'auto' else [maturity]):
            try:
                with ThreadPoolExecutor(max_workers=3) as pool:
                    groups = list(pool.map(lambda window: lookup(window, level), windows))
            except Exception as exc:
                last_error = exc
                continue
            searched = True
            chain = find_chain(groups, compatible)
            if chain:
                for scene in chain:
                    scene.pop('_footprint', None)
                return name, chain
    if last_error and not searched:
        raise last_error
    return sensor, []
