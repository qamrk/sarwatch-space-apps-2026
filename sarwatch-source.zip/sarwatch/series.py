"""Find one consistent series of observations in disjoint date windows."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta

from .limits import LANDSAT_START, NISAR_SEARCH_DAYS, NISAR_START, automatic_sensor

MAX_DATES = 6


def find_chain(groups, compatible):
    """Keep only the best path to each scene, preserving the source's ranking."""
    paths = [(rank, [scene]) for rank, scene in enumerate(groups[0])]
    for group in groups[1:]:
        following = []
        for rank, scene in enumerate(group):
            previous = [(score, path) for score, path in paths if compatible(path[-1], scene)]
            if previous:
                score, path = min(previous, key=lambda item: item[0])
                following.append((score + rank, [*path, scene]))
        paths = following
    return min(paths, key=lambda item: item[0])[1] if paths else []


def search_series(coords, dates, sensor, maturity):
    from shapely.geometry import box, shape
    from . import catalog, landsat, modis
    import requests

    aoi = box(*coords)
    requested_sensor = sensor
    sensor = automatic_sensor(sensor, dates[0])
    today = date.today()
    midpoints = [left + (right - left) / 2 for left, right in zip(dates, dates[1:])]
    windows = list(zip(dates, [date.fromisoformat(LANDSAT_START),
                              *(day + timedelta(days=1) for day in midpoints)], [*midpoints, today]))

    def optical(window, level, radius):
        with requests.Session() as session:
            return landsat.epoch_options(session, aoi, *window)

    def radar(window, level, radius):
        day, first, last = window
        first = max(first, date.fromisoformat(NISAR_START), day - timedelta(days=radius))
        last = min(last, day + timedelta(days=radius))
        found = catalog.search(coords, f'{first}T00:00:00Z', f'{last}T23:59:59Z', level)
        return sorted((scene for scene in found['scenes'] if shape(scene['geometry']).covers(aoi)),
                      key=lambda scene: abs((date.fromisoformat(scene['start'][:10]) - day).days))

    def overview(window, level, radius):
        day, first, last = window
        item = modis.nearby_scene(coords, day, max(first, modis.START), last)
        return [item] if item else []

    sources = [('nisar', radar, lambda a, b: bool(catalog.compatible_pairs([a, b])), NISAR_START),
               ('landsat', optical, lambda a, b: a['_footprint'].intersection(b['_footprint']).area >= landsat.MIN_COVERAGE * aoi.area, LANDSAT_START),
               ('modis', overview, lambda a, b: True, modis.START.isoformat())]
    last_error = None
    searched = False
    for name, lookup, compatible, earliest in sources:
        if sensor not in ('auto', name) or dates[0].isoformat() < earliest:
            continue
        automatic_radar = name == 'nisar' and requested_sensor == 'auto'
        levels = tuple(dict.fromkeys((maturity, 'VALIDATED', 'PROVISIONAL', 'BETA'))) if automatic_radar else (maturity,)
        radii = NISAR_SEARCH_DAYS if automatic_radar else NISAR_SEARCH_DAYS[:1]
        for radius, level in ((radius, level) for radius in radii for level in levels):
            try:
                with ThreadPoolExecutor(max_workers=3) as pool:
                    groups = list(pool.map(lambda window: lookup(window, level, radius), windows))
            except Exception as exc:
                last_error = exc
                continue
            searched = True
            chain = find_chain(groups, compatible)
            if chain:
                for scene in chain:
                    scene.pop('_footprint', None)
                return name, chain
    if last_error and (sensor == 'nisar' or not searched):
        raise last_error
    return sensor, []
