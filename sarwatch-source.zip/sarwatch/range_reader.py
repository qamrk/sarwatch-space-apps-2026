"""Seekable HTTPS reader. Never accepts an unbounded 200 response as a range."""
from collections import OrderedDict
from contextlib import ExitStack
import io
import re
import time
from urllib.parse import urlparse
import requests


class AccessError(RuntimeError):
    pass


class RangeReader(io.RawIOBase):
    def __init__(self, url, token, budget=100_000_000, seconds=900, block_size=262144, session=None):
        super().__init__()
        p = urlparse(url)
        if p.scheme != 'https' or p.hostname != 'nisar.asf.earthdatacloud.nasa.gov' or p.username or p.password or p.query or not p.path.endswith('.h5'):
            raise AccessError('Only official NISAR HTTPS HDF5 assets are supported')
        if not token:
            raise AccessError('EARTHDATA_TOKEN is missing; put it in the local .env file')
        self.url, self.token = url, token
        self.session = session or requests.Session()
        self.budget, self.deadline = budget, time.monotonic()+seconds
        self.block_size, self.transferred, self.pos = block_size, 0, 0
        self.cache = OrderedDict()
        self.size = None
        self.asset_url = None
        first = self._fetch(0, block_size-1)
        self.cache[0] = first

    def _fetch(self, start, end):
        left = self.deadline-time.monotonic()
        if left <= 0:
            raise AccessError('Analysis time budget exceeded')
        requested = end-start+1
        if self.transferred+requested > self.budget:
            raise AccessError('Network byte budget exceeded; no full-file fallback')
        headers = {'Range': f'bytes={start}-{end}', 'Accept-Encoding': 'identity'}
        if self.asset_url is None:
            headers['Authorization'] = 'Bearer '+self.token
        with ExitStack() as stack:
            r=stack.enter_context(self.session.get(self.asset_url or self.url, headers=headers, stream=True, allow_redirects=False, timeout=min(30, left)))
            if r.status_code in (302,303,307,308) and self.asset_url is None:
                target=r.headers.get('Location','')
                p=urlparse(target)
                # This exact CDN was observed in the authenticated NASA response.
                # Signed URLs remain in memory only; the bearer is never forwarded.
                if p.scheme!='https' or p.hostname!='d1mv8zhcvry6x4.cloudfront.net' or p.username or p.password or p.port not in (None,443):
                    raise AccessError('Unexpected asset redirect; credentials were not forwarded')
                self.asset_url=target
                headers.pop('Authorization',None)
                r=stack.enter_context(self.session.get(target,headers=headers,stream=True,allow_redirects=False,timeout=min(30,left)))
            if r.status_code in (401, 403):
                raise AccessError('Earthdata access was refused; check token and account authorization')
            if r.status_code != 206:
                raise AccessError(f'Expected HTTP 206; received {r.status_code}. Full download refused')
            m = re.fullmatch(r'bytes (\d+)-(\d+)/(\d+)', r.headers.get('Content-Range', ''))
            if not m:
                raise AccessError('Missing or invalid Content-Range')
            lo, hi, total = map(int, m.groups())
            if lo != start or hi != min(end, total-1) or (self.size is not None and total != self.size):
                raise AccessError('Inconsistent range response')
            self.size = total
            data = r.raw.read(hi-lo+2, decode_content=False)
            self.transferred += len(data)
            if len(data) != hi-lo+1:
                raise AccessError('Truncated or oversized range response')
            if time.monotonic() > self.deadline:
                raise AccessError('Analysis time budget exceeded')
            return data

    def readable(self): return True
    def seekable(self): return True
    def tell(self): return self.pos

    def seek(self, offset, whence=0):
        if whence not in (0,1,2): raise ValueError('Invalid seek mode')
        self.pos = offset + (self.pos if whence == 1 else self.size if whence == 2 else 0)
        if self.pos < 0: raise ValueError('Negative seek')
        return self.pos

    def readinto(self, buf):
        data = self.read(len(buf))
        buf[:len(data)] = data
        return len(data)

    def read(self, size=-1):
        if self.closed: raise ValueError('Reader is closed')
        size = self.size-self.pos if size < 0 else min(size, max(0, self.size-self.pos))
        if size > self.budget: raise AccessError('Requested read exceeds memory/network budget')
        out = bytearray()
        while size > 0:
            index = self.pos//self.block_size
            if index not in self.cache:
                # HDF5 often requests a compressed ~1 MiB chunk. Fetch its
                # contiguous blocks together rather than paying an HTTP round
                # trip for every 256 KiB. The temporary response stays <=4 MiB.
                offset=self.pos%self.block_size
                blocks=min(16,max(1,(offset+size+self.block_size-1)//self.block_size))
                if size>=self.block_size:
                    blocks=min(16,max(1,(self.budget-self.transferred)//self.block_size))
                start=index*self.block_size
                data=self._fetch(start,min(self.size-1,start+blocks*self.block_size-1))
                for j in range(0,len(data),self.block_size):
                    self.cache[index+j//self.block_size]=data[j:j+self.block_size]
                # 16 MiB at the normal block size. Reuse HDF5 chunks across
                # adjacent processing tiles instead of downloading them again.
                while len(self.cache) > 64: self.cache.popitem(last=False)
            self.cache.move_to_end(index)
            offset = self.pos % self.block_size
            part = self.cache[index][offset:offset+size]
            if not part: raise AccessError('Unexpected end of remote file')
            out.extend(part)
            self.pos += len(part)
            size -= len(part)
        return bytes(out)

    def close(self):
        self.cache.clear()
        self.session.close()
        super().close()
