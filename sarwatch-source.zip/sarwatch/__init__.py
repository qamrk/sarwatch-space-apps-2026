"""SARWatch: real-data preflight before application development."""
