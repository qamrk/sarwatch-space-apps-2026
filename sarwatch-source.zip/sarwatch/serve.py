"""Start the complete local prototype and open it once the server is ready."""
import os
from pathlib import Path
import socket
import threading
import time
import webbrowser
from urllib.request import urlopen
from urllib.error import URLError
import json
import uvicorn


def main():
    os.chdir(Path(__file__).resolve().parent.parent)
    host='127.0.0.1';port=int(os.environ.get('SARWATCH_PORT','8000'))
    address=f'http://{host}:{port}'
    webroot=Path(os.environ.get('SARWATCH_WEB_DIR','frontend/dist'))
    if not (webroot/'index.html').is_file():
        raise SystemExit('Frontend build missing. Follow the build instructions in README.md.')
    def ready():
        for _ in range(80):
            try:
                with urlopen(address+'/api/health',timeout=1) as response:
                    if response.status==200:
                        with urlopen(address,timeout=1) as page:
                            if page.status!=200:continue
                        print(f'\nSARWatch: {address}\n',flush=True)
                        if os.environ.get('SARWATCH_NO_BROWSER')!='1':webbrowser.open(address)
                        return
            except OSError:time.sleep(.25)
    # Reuse an already running SARWatch; do not kill unrelated processes.
    try:
        with socket.create_connection((host,port),timeout=.5):
            with urlopen(address+'/api/health',timeout=2) as r:
                if json.load(r).get('application')!='sarwatch':raise RuntimeError('Port is occupied by another service')
            if os.environ.get('SARWATCH_NO_BROWSER')!='1':webbrowser.open(address)
            print(f'SARWatch is already running: {address}');return
    except (ConnectionRefusedError,TimeoutError):pass
    except (URLError,json.JSONDecodeError) as exc:
        raise RuntimeError('Port is occupied by another service; set SARWATCH_PORT to a free port') from exc
    threading.Thread(target=ready,daemon=True).start()
    uvicorn.run('sarwatch.api:app',host=host,port=port,workers=1,log_level='warning')


if __name__=='__main__':main()
