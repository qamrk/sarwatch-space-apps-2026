"""Experimental open-water mapping. Water gains are not confirmed floods."""
import json
import warnings
from pathlib import Path
import numpy as np
from scipy import ndimage
import rasterio
from rasterio.features import shapes
from rasterio.warp import reproject, Resampling, transform_geom
from PIL import Image
from pyproj import CRS
from .catalog import scene_identity, compatible_pairs


def filtered_power_db(db):
    """3x3 median in linear power; do not fill missing original samples."""
    valid=np.isfinite(db)
    power=np.where(valid,np.power(10,db/10),np.nan)
    windows=np.lib.stride_tricks.sliding_window_view(np.pad(power,1,mode='edge'),(3,3))
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore',message='All-NaN slice encountered')
        filtered=np.nanmedian(windows,axis=(-2,-1))
    valid &= np.isfinite(windows).sum(axis=(-2,-1))>=5
    out=np.full(db.shape,np.nan,dtype='float32')
    out[valid]=10*np.log10(filtered[valid])
    return out


def otsu_threshold(values):
    values=np.asarray(values); values=values[np.isfinite(values)]
    if values.size<100: raise ValueError('Insufficient valid samples for water mapping')
    lo,hi=np.percentile(values,[.5,99.5])
    if hi-lo<1.: raise ValueError('Insufficient intensity range for water mapping')
    hist,edges=np.histogram(np.clip(values,lo,hi),bins=256,range=(lo,hi))
    p=hist/hist.sum(); centers=(edges[:-1]+edges[1:])/2
    w=np.cumsum(p); mu=np.cumsum(p*centers); mean=mu[-1]
    between=np.zeros_like(w)
    ok=(w>0)&(w<1)
    between[ok]=(mean*w[ok]-mu[ok])**2/(w[ok]*(1-w[ok]))
    k=int(np.argmax(between)); variance=np.sum(p*(centers-mean)**2)
    eta=float(between[k]/variance) if variance else 0.
    threshold=float(edges[k+1])
    # A quality gate, not a universal physical water threshold.
    if eta<.75 or not .01<w[k]<.99:
        raise ValueError('Histogram does not separate water and land reliably; use intensity comparison')
    return threshold,eta


def clean_mask(mask,minimum_pixels=9):
    labels,n=ndimage.label(mask,structure=np.ones((3,3)))
    counts=np.bincount(labels.ravel())
    keep=counts>=minimum_pixels; keep[0]=False
    return keep[labels]


def classify_pair(before_db,after_db,pixel_area_m2):
    before=filtered_power_db(before_db); after=filtered_power_db(after_db)
    valid=np.isfinite(before)&np.isfinite(after)
    threshold,separation=otsu_threshold(np.concatenate([before[valid],after[valid]]))
    a=clean_mask((before<threshold)&valid)&valid
    b=clean_mask((after<threshold)&valid)&valid
    classes=np.full(a.shape,255,dtype='uint8'); classes[valid]=0
    classes[a&b]=1; classes[~a&b&valid]=2; classes[a&~b&valid]=3
    area=lambda mask:float(np.count_nonzero(mask)*pixel_area_m2/1_000_000)
    stats=dict(water_before_km2=area(a),water_after_km2=area(b),
               water_gain_km2=area(classes==2),water_loss_km2=area(classes==3),
               comparable_area_km2=area(valid),valid_pixels=int(valid.sum()),
               threshold_db=threshold,histogram_separability=separation,
               minimum_component_pixels=9,median_window_pixels=3,
               classification_status='experimental_open_water',
               validation_status='not_independently_validated',
               ready_for_demo=False,
               potential_flood_available=False,
               limitations=['Open exposed water only; dark land, wind and wet soils may confound mapping.',
                            'Subswath quality mask does not exclude terrain shadows.',
                            'Water gain is not a flood label; permanent water and terrain exclusion are required.'])
    return classes,stats


def analyze_water(before_path,after_path,output_dir):
    out=Path(output_dir); out.mkdir(parents=True,exist_ok=True)
    with rasterio.open(before_path) as a,rasterio.open(after_path) as b:
        tags=[a.tags(),b.tags()]
        if any(t.get('quality_mask_applied')!='true' for t in tags):
            raise ValueError('Water analysis requires GCOV quality-masked inputs')
        if not tags[0].get('channel') or tags[0].get('channel')!=tags[1].get('channel'):
            raise ValueError('Water analysis requires the same polarization channel')
        identities=[]
        for t in tags:
            url=t.get('source_url','')
            maturity='PROVISIONAL' if '_PROVISIONAL_' in url else 'BETA' if '_BETA_' in url else 'VALIDATED'
            identities.append(scene_identity(url,maturity))
        if identities[0]['start']>=identities[1]['start'] or not compatible_pairs(identities):
            raise ValueError('Water inputs are not an ordered compatible NISAR pair')
        if not a.crs.is_projected or any(axis.unit_name!='metre' for axis in CRS(a.crs).axis_info):
            raise ValueError('Area calculation requires metric projected coordinates')
        before=a.read(1,masked=True).filled(np.nan)
        after_power=np.power(10,b.read(1,masked=True).filled(np.nan)/10)
        aligned=np.full(before.shape,np.nan,dtype='float32')
        reproject(after_power,aligned,src_transform=b.transform,src_crs=b.crs,
                  dst_transform=a.transform,dst_crs=a.crs,src_nodata=np.nan,dst_nodata=np.nan,
                  resampling=Resampling.bilinear,num_threads=1,warp_mem_limit=16)
        # Require all contributing source pixels to be valid; no interpolation across NoData.
        coverage=np.zeros(before.shape,dtype='float32')
        reproject(np.isfinite(after_power).astype('float32'),coverage,src_transform=b.transform,
                  src_crs=b.crs,dst_transform=a.transform,dst_crs=a.crs,resampling=Resampling.bilinear,
                  dst_nodata=0,num_threads=1,warp_mem_limit=16)
        valid=np.isfinite(aligned)&(aligned>0)&(coverage>=.99999)
        after=np.full(before.shape,np.nan,dtype='float32'); after[valid]=10*np.log10(aligned[valid])
        area=abs(a.transform.a*a.transform.e-a.transform.b*a.transform.d)
        classes,stats=classify_pair(before,after,area)
        profile=a.profile.copy(); profile.update(dtype='uint8',nodata=255,count=1)
        with rasterio.open(out/'water_changes.tif','w',**profile) as dst:
            dst.write(classes,1); dst.update_tags(classification='experimental_open_water',quality_mask_applied='true')
        features=[]
        labels={1:'water_both_dates',2:'water_gain',3:'water_loss'}
        for geom,value in shapes(classes,mask=(classes>0)&(classes<255),transform=a.transform):
            features.append(dict(type='Feature',geometry=transform_geom(a.crs,'EPSG:4326',geom),
                                 properties={'class':labels[int(value)]}))
            if len(features)>5000: raise ValueError('Vector feature limit exceeded')
        (out/'water.geojson').write_text(json.dumps(dict(type='FeatureCollection',features=features)))
        lo,hi=np.nanpercentile(before,[2,98]); hi=max(hi,lo+1)
        grey=(np.nan_to_num(np.clip((before-lo)/(hi-lo),0,1),nan=0)*180).astype('uint8')
        rgba=np.stack([grey,grey,grey,np.where(classes==255,0,255).astype('uint8')],axis=-1)
        for value,color in {1:(38,111,192,255),2:(44,222,207,255),3:(246,167,61,255)}.items(): rgba[classes==value]=color
        Image.fromarray(rgba).save(out/'water.png')
        from rasterio.warp import transform_bounds
        stats.update(sources=identities,channel=tags[0]['channel'],quality_mask_applied=True,
                     bounds=list(transform_bounds(a.crs,'EPSG:4326',*a.bounds)),
                     pixel_area_m2=area,epsg=a.crs.to_epsg())
        (out/'water.json').write_text(json.dumps(stats,indent=2)+'\n')
        return stats
