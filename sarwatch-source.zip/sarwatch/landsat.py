"""Search and compare Landsat Collection 2 Level-2 optical observations."""
from collections import defaultdict
from datetime import date, timedelta
import json
import math
from pathlib import Path
import re
import time
from urllib.parse import urlparse

import numpy as np
from pyproj import CRS, Transformer
import requests
from rasterio.transform import from_origin, array_bounds
from rasterio.warp import Resampling
from shapely.geometry import box, shape
from shapely.ops import unary_union

from .case_assets import overlay
from .flood import raster_window
from .gcov import validate_aoi
from .limits import LANDSAT_START, MAX_NETWORK_BYTES, MAX_OUTPUT_SIDE
from .range_reader import AccessError, BudgetedRangeReader


HOST = 'https://planetarycomputer.microsoft.com'
CATALOG = HOST + '/api/stac/v1'
COLLECTION = 'landsat-c2-l2'
ITEM_ID = re.compile(r'(LT04|LT05|LE07|LC08|LC09)_L2S[PR]_(\d{3})(\d{3})_(\d{8})_02_T[12]')
RGB = ('red', 'green', 'blue')
ASSETS = ('qa_pixel', 'swir16', *RGB)
WATER_SWIR_MAX = .06
SEARCH_DAYS = 32
ATTRIBUTION = 'USGS Landsat Collection 2 Level-2 · Microsoft Planetary Computer'
QA_URL = 'https://www.usgs.gov/landsat-missions/landsat-collection-2-quality-assessment-bands'


def search_epochs(bbox, before, after):
    """Find observations near each requested date independently."""
    aoi = box(*bbox)
    if before >= after:
        return {'scenes': [], 'pairs': [], 'sensor': 'landsat'}
    with requests.Session() as session:
        groups = [epoch_options(session, aoi, day) for day in (before, after)]
    scenes = {s['id']: s for candidates in groups for s in candidates}
    midpoint = before + (after - before) / 2
    pairs = [{'before': a['id'], 'after': b['id']} for a in groups[0] for b in groups[1]
             if a['start'][:10] <= midpoint.isoformat() < b['start'][:10]]
    return {'scenes': list(scenes.values()), 'pairs': pairs, 'sensor': 'landsat'}


def epoch_options(session, aoi, day):
    minimum = max(date.fromisoformat(LANDSAT_START), day - timedelta(days=SEARCH_DAYS))
    maximum = day + timedelta(days=min(SEARCH_DAYS, (date.max - day).days))
    query = {'collections': COLLECTION, 'bbox': ','.join(map(str, aoi.bounds)),
             'datetime': f'{minimum}T00:00:00Z/{maximum}T23:59:59Z', 'limit': 100}
    response = session.get(CATALOG + '/search', params=query, timeout=25)
    response.raise_for_status()
    passes = defaultdict(list)
    for item in response.json()['features']:
        match = ITEM_ID.fullmatch(item['id'])
        if not match or not item.get('geometry') or not all(key in item['assets'] for key in ASSETS):
            continue
        spacecraft, path, _, _ = match.groups()
        observed = item['properties']['datetime'][:10]
        if not minimum.isoformat() <= observed <= maximum.isoformat():
            continue
        footprint = shape(item['geometry']).intersection(aoi)
        if footprint.area > 0:
            passes[spacecraft, path, observed].append((item, footprint))

    candidates = []
    for (spacecraft, path, observed), assets in passes.items():
        assets.sort(key=lambda row: row[1].area, reverse=True)
        selected = []
        footprint = None
        for item, geometry in assets[:3]:
            if footprint is not None and geometry.difference(footprint).area < .005 * aoi.area:
                continue
            selected.append(item)
            footprint = unary_union([footprint, geometry]) if footprint is not None else geometry
            if footprint.area / aoi.area >= .995:
                break
        coverage = footprint.area / aoi.area
        if coverage < .75:
            continue
        ids = [item['id'] for item in selected]
        cloud = sum(max(0, c) if isinstance(c, (int, float)) and 0 <= c <= 100 else 100
                    for c in (item['properties'].get('eo:cloud_cover') for item in selected)) / len(selected)
        record = {'id': '+'.join(ids), 'sensor': 'landsat', 'start': selected[0]['properties']['datetime'],
                  'platform': 'Landsat ' + str(int(spacecraft[-2:])), 'track': path,
                  'scene_ids': ids, 'cloud_cover': cloud, 'coverage': round(coverage, 4),
                  '_items': [{'id': item['id'], 'assets': {k: item['assets'][k]['href'] for k in ASSETS},
                              'geometry': item['geometry']} for item in selected]}
        distance = abs((date.fromisoformat(observed) - day).days)
        score = distance + cloud * .35 + (1 - coverage) * 100
        candidates.append((score, record))
    candidates.sort(key=lambda entry: (entry[0], entry[1]['id']))
    return [record for _, record in candidates[:6]]


def public_scene(scene):
    return {key: value for key, value in scene.items() if key != '_items'}


class LandsatReader(BudgetedRangeReader):
    def __init__(self, url, ledger):
        parsed = urlparse(url)
        if (parsed.scheme != 'https' or parsed.hostname != 'landsateuwest.blob.core.windows.net'
                or parsed.username or parsed.password or parsed.port not in (None, 443)
                or not parsed.query or not parsed.path.startswith('/landsat-c2/level-2/')
                or not parsed.path.lower().endswith('.tif')):
            raise AccessError('Unsupported Landsat raster')
        super().__init__(url, ledger, block_size=262144)


def analysis_grid(bbox):
    w, s, e, n = bbox
    lon, lat = (w + e) / 2, (s + n) / 2
    # An equal-area grid allows raw pixel counts to express comparable areas.
    crs = CRS.from_proj4(f'+proj=laea +lat_0={lat} +lon_0={lon} +datum=WGS84 +units=m')
    forward = Transformer.from_crs(4326, crs, always_xy=True)
    left, bottom, right, top = forward.transform_bounds(*bbox, densify_pts=21)
    step = 30 * max(1, math.ceil(max(right-left, top-bottom) / (30 * MAX_OUTPUT_SIDE)))
    width, height = math.ceil((right-left)/step), math.ceil((top-bottom)/step)
    transform = from_origin(left, top, step, step)
    x, y = np.meshgrid(left + (np.arange(width) + .5) * step, top - (np.arange(height) + .5) * step)
    longitude, latitude = Transformer.from_crs(crs, 4326, always_xy=True).transform(x, y)
    inside = (longitude >= w) & (longitude <= e) & (latitude >= s) & (latitude <= n)
    from types import SimpleNamespace
    target = SimpleNamespace(crs=crs, transform=transform, width=width, height=height,
                             bounds=array_bounds(height, width, transform), shape=(height, width))
    return target, step, inside


def read_epoch(scene, target, inside, credential, ledger):
    rgba = np.zeros((*target.shape, 4), dtype='uint8')
    valid = np.zeros(target.shape, dtype=bool)
    water = valid.copy()
    for item in scene['_items']:
        def read(key, resampling=Resampling.nearest):
            return raster_window(item['assets'][key] + '?' + credential, target, ledger,
                                 resampling=resampling, reader_class=LandsatReader)

        qa = read('qa_pixel')
        flags = np.nan_to_num(qa, nan=1).astype('uint16')
        usable = inside & ~valid & ((flags & 63) == 0)
        if not usable.any():
            continue
        rgb = np.stack([read(k, Resampling.bilinear) for k in RGB], axis=-1)
        swir = read('swir16')
        usable &= np.isfinite(rgb).all(axis=-1) & (rgb > 0).all(axis=-1)
        usable &= np.isfinite(swir) & (swir > 0)
        reflectance = rgb[usable] * .0000275 - .2
        rgba[usable, :3] = (255 * np.clip(reflectance / .32, 0, 1) ** .72).astype('uint8')
        rgba[usable, 3] = 255
        # Water has low shortwave infrared reflectance. Screen bright salt
        # deposits that can be flagged as water in the QA band.
        water[usable] = ((flags[usable] & 128) != 0) & (swir[usable] * .0000275 - .2 <= WATER_SWIR_MAX)
        valid |= usable
    return rgba, valid, water


def run_comparison(catalog, before_id, after_id, bbox, folder, side_km=None):
    validate_aoi(bbox)
    start = time.monotonic()
    scenes = {scene['id']: scene for scene in catalog['scenes']}
    before, after = scenes[before_id], scenes[after_id]
    if before['start'][:10] >= after['start'][:10]:
        raise ValueError('Select Landsat observations from two ordered dates')
    aoi = box(*bbox)
    for scene in (before, after):
        coverage = unary_union([shape(item['geometry']) for item in scene['_items']]).intersection(aoi)
        if coverage.area < .75 * aoi.area:
            raise ValueError('Landsat observations no longer cover the selected area. Search again.')
    auth = requests.get(HOST + '/api/sas/v1/token/' + COLLECTION, timeout=20)
    auth.raise_for_status()
    credential = auth.json()['token']
    ledger = {'deadline': start + 900, 'remaining': MAX_NETWORK_BYTES}
    folder = Path(folder)
    mapping = folder / 'mapping'
    mapping.mkdir(parents=True, exist_ok=True)
    target, step, inside = analysis_grid(bbox)
    layers = []
    epochs = []
    for name, scene in [('before', before), ('after', after)]:
        rgba, valid, water = read_epoch(scene, target, inside, credential, ledger)
        if not valid.any():
            raise ValueError('No clear pixels in a selected Landsat epoch. Try another date.')
        epochs.append((valid, water))
        bounds = overlay(rgba, target, mapping / (name + '.png'))
        layers.append({'id': name, 'file': name + '.png', 'bounds': bounds})
    (valid_a, water_a), (valid_b, water_b) = epochs
    common = valid_a & valid_b
    fraction = float(common.sum() / inside.sum())
    if fraction < .60:
        raise ValueError('Less than 60% clear overlap in the selected Landsat images. Try a different pair.')
    rgba = np.zeros((*target.shape, 4), dtype='uint8')
    rgba[common & water_a & water_b] = (38, 111, 192, 230)
    rgba[common & ~water_a & water_b] = (44, 222, 207, 245)
    rgba[common & water_a & ~water_b] = (246, 167, 61, 245)
    bounds = overlay(rgba, target, mapping / 'water.png')
    layers.append({'id': 'water', 'file': 'water.png', 'bounds': bounds})
    pixel_area = step ** 2 / 1e6
    water = {'status': 'optical', 'water_before_km2': float((common & water_a).sum() * pixel_area),
             'water_after_km2': float((common & water_b).sum() * pixel_area),
             'water_gain_km2': float((common & ~water_a & water_b).sum() * pixel_area),
             'water_loss_km2': float((common & water_a & ~water_b).sum() * pixel_area),
             'comparable_area_km2': float(common.sum() * pixel_area)}
    result = {'sensor': 'landsat', 'theme': 'water', 'bbox': bbox, 'requested_side_km': side_km,
              'sources': [public_scene(before), public_scene(after)], 'layers': layers, 'water': water,
              'flood': {'status': 'not_requested'}, 'attribution': [ATTRIBUTION],
              'comparison': {'finite_overlap_fraction': fraction, 'comparable_pixels': int(common.sum())},
              'observations': [{'pixel_spacing_m': [step, step]}],
              'elapsed_seconds': round(time.monotonic()-start, 3),
              'transferred_bytes': MAX_NETWORK_BYTES - ledger['remaining']}
    return result
