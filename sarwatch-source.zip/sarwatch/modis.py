"""NASA GIBS imagery for visual comparisons outside the Landsat archive coverage."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date, timedelta
from functools import lru_cache
from io import BytesIO
from pathlib import Path
from urllib.parse import urlencode

from PIL import Image
import requests

from .gcov import validate_aoi


START = date(2000, 2, 24)
WMS = 'https://gibs.earthdata.nasa.gov/wms/epsg3857/best/wms.cgi'
LAYERS = ('MODIS_Terra_CorrectedReflectance_TrueColor', 'MODIS_Aqua_CorrectedReflectance_TrueColor')
ATTRIBUTION = 'NASA EOSDIS GIBS · MODIS Corrected Reflectance'
# Definite liquid and ice cloud classes in the NASA GIBS optical cloud-phase legend.
CLOUD_COLORS = {(0, 0, 100, 255), (188, 210, 254, 255)}


def scene(day, layer, bbox):
    query = urlencode({'l': layer, 't': day.isoformat(), 'v': ','.join(map(str, bbox))})
    platform = 'Terra MODIS' if layer == LAYERS[0] else 'Aqua MODIS'
    return {'id': f'{layer}:{day}', 'start': day.isoformat(), 'sensor': 'modis',
            'platform': platform, 'layer': layer, 'source_url': f'https://worldview.earthdata.nasa.gov/?{query}'}


@lru_cache(maxsize=80)
def image_for(bbox, day, layer, size):
    from pyproj import Transformer
    bounds = Transformer.from_crs(4326, 3857, always_xy=True).transform_bounds(*bbox)
    query = {'service': 'WMS', 'request': 'GetMap', 'version': '1.1.1', 'layers': layer,
             'srs': 'EPSG:3857', 'bbox': ','.join(map(str, bounds)), 'width': size,
             'height': size, 'format': 'image/png', 'transparent': 'true', 'time': day}
    with requests.get(WMS, params=query, timeout=(5, 12), stream=True) as response:
        response.raise_for_status()
        if not response.headers.get('Content-Type', '').startswith('image/png'):
            return None
        payload = bytearray()
        for chunk in response.iter_content(65536):
            payload.extend(chunk)
            if len(payload) > 2_000_000:
                return None
    with Image.open(BytesIO(payload)) as image:
        if image.size != (size, size) or image.convert('RGBA').getchannel('A').getbbox() is None:
            return None
    return bytes(payload)


def nearby_scene(bbox, requested, earliest, latest):
    for offset in (0, -1, 1, -2, 2, -3, 3):
        ordinal = requested.toordinal() + offset
        if not earliest.toordinal() <= ordinal <= latest.toordinal():
            continue
        day = date.fromordinal(ordinal)
        for layer in LAYERS if day >= date(2002, 7, 3) else LAYERS[:1]:
            if image_for(bbox, day.isoformat(), layer, 96):
                return scene(day, layer, bbox)
    return None


def detects_clouds(bbox, item):
    platform = 'Terra' if item['layer'] == LAYERS[0] else 'Aqua'
    layer = f'MODIS_{platform}_Cloud_Phase_Optical_Properties'
    try:
        payload = image_for(tuple(bbox), item['start'], layer, 96)
        if payload:
            with Image.open(BytesIO(payload)) as image:
                colors = image.convert('RGBA').getcolors(96 * 96)
                return any(color in CLOUD_COLORS for _, color in colors)
    except (requests.RequestException, OSError):
        # Optical imagery remains available when the separate cloud product is down.
        pass
    return False


def search_comparison(bbox, before, after):
    result = {'sensor': 'modis', 'scenes': [], 'pairs': []}
    if before < START or before >= after:
        return result
    midpoint = before + (after - before) / 2
    with ThreadPoolExecutor(max_workers=2) as pool:
        older = pool.submit(nearby_scene, tuple(bbox), before, START, midpoint)
        newer = pool.submit(nearby_scene, tuple(bbox), after, midpoint + timedelta(days=1), date.today())
        first, second = older.result(), newer.result()
    if first and second:
        result['scenes'] = [first, second]
        result['pairs'] = [{'before': first['id'], 'after': second['id']}]
    return result


def run_comparison(catalog, before_id, after_id, bbox, folder, theme, side_km=None):
    validate_aoi(bbox)
    sources = sorted(catalog['scenes'], key=lambda item: item['start'])
    if [item['id'] for item in sources] != [before_id, after_id] or sources[0]['start'] >= sources[1]['start']:
        raise ValueError('Select MODIS observations from two ordered dates')
    mapping = Path(folder) / 'mapping'
    mapping.mkdir(parents=True, exist_ok=True)
    layers = []
    for name, item in zip(('before', 'after'), sources):
        payload = image_for(tuple(bbox), item['start'], item['layer'], 512)
        if not payload:
            raise ValueError('A MODIS image is unavailable on the selected date')
        filename = name + '.png'
        (mapping / filename).write_bytes(payload)
        layers.append({'id': name, 'file': filename, 'bounds': bbox})
    with ThreadPoolExecutor(max_workers=2) as pool:
        cloud_obscured = any(pool.map(lambda item: detects_clouds(bbox, item), sources))
    return {'sensor': 'modis', 'theme': theme, 'bbox': bbox, 'requested_side_km': side_km,
            'sources': [scene(date.fromisoformat(item['start']), item['layer'], bbox) for item in sources],
            'layers': layers, 'water': {'status': 'not_requested'}, 'attribution': [ATTRIBUTION],
            'cloud_obscured': cloud_obscured}
