"""Small public ASF browse images. Display only, never scientific inputs."""
from io import BytesIO
from contextlib import ExitStack
from urllib.parse import urlparse
import requests
from PIL import Image


def preview_png(url):
    p=urlparse(url)
    if p.scheme!='https' or p.hostname!='nisar.asf.earthdatacloud.nasa.gov' or not p.path.startswith('/BROWSE/') or p.query or not p.path.endswith('.png'):
        raise ValueError('Unsupported ASF browse asset')
    payload=bytearray()
    # Public browse needs no token. Only the observed official ASF CDN is
    # accepted for redirects; signed URLs remain in memory and are not returned.
    with ExitStack() as stack:
        response=stack.enter_context(requests.get(url,stream=True,allow_redirects=False,timeout=30))
        if response.status_code in (302,303,307,308):
            target=response.headers.get('Location','');redirect=urlparse(target)
            if redirect.scheme!='https' or redirect.hostname!='d1mv8zhcvry6x4.cloudfront.net' or redirect.username or redirect.password or redirect.port not in (None,443):
                raise ValueError('Unsupported ASF browse redirect')
            response=stack.enter_context(requests.get(target,stream=True,allow_redirects=False,timeout=30))
        response.raise_for_status()
        if response.status_code!=200:raise ValueError('Browse asset unavailable')
        for block in response.iter_content(65536):
            payload.extend(block)
            if len(payload)>8_000_000:raise ValueError('Browse image exceeds 8 MB limit')
    with Image.open(BytesIO(payload)) as image:
        if image.width*image.height>16_000_000:raise ValueError('Browse image pixel budget exceeded')
        image.thumbnail((1024,1024))
        out=BytesIO();image.convert('RGB').save(out,format='PNG');return out.getvalue()
