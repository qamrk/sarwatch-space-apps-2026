"""Experimental risk indices, evaluated on geographic sectors for the map."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, time, timedelta, timezone
from types import SimpleNamespace

import numpy as np
from pyproj import Geod
from rasterio.transform import from_bounds
from scipy import ndimage

from . import prediction_data as data


PERIODS = {'water': (1, 3, 7), 'fire': (1, 3, 7), 'agri_fire': (1, 3, 7), 'forest': (90, 365)}
SECTORS = 6
SAMPLES = 12
PADDING = SAMPLES
GEOD = Geod(ellps='WGS84')
SOURCES = {'water': ('land', 'terrain', 'water'), 'fire': ('land', 'terrain'),
           'agri_fire': ('land',), 'forest': ('land', 'terrain', 'loss')}
LIMITS = {
    'water': [
        'Индекс учитывает прогноз дождя, недавние осадки и рельеф. Для расчёта затопления нужны данные о стоке, дамбах и уровне воды выше по течению.',
        'Границы цветных секторов показывают сетку расчёта. Прогноз погоды имеет более крупное разрешение.',
    ],
    'fire': [
        'Оцениваются условия распространения огня в лесах и кустарниках. Место и время возгорания не определяются.',
        'Пропуски пролётов, облачность и разрешение VIIRS ограничивают обнаружение тепловых аномалий.',
    ],
    'agri_fire': [
        'Оцениваются условия распространения огня на пашне. Дождь за 48 часов служит косвенным показателем влажности растительных остатков. Время проведения палов неизвестно.',
        'Тепловая аномалия VIIRS может иметь другие причины. Состояние посевов могло измениться с 2021 года.',
    ],
    'forest': [
        'Это оценка уязвимости на основе прошлых потерь древесного покрова. В статистику входят пожары и другие нарушения, а также рубки.',
        'Годовой архив не показывает оперативные работы и новые дороги. Горизонт влияет на индекс накопленного риска.',
    ],
}


class InvalidHorizon(ValueError):
    """The chosen end date or preset is outside the supported horizon."""


def prediction_window(category, days, until, now):
    """A calendar date includes the entire selected day in UTC."""
    start = now if category == 'forest' else now.replace(minute=0, second=0, microsecond=0)
    if until is None:
        if days not in PERIODS[category]:
            raise InvalidHorizon('Выберите доступный горизонт или укажите дату окончания.')
        return start, start + timedelta(days=days)
    if days is not None:
        raise InvalidHorizon('Выберите готовый горизонт или дату окончания.')

    earliest = now.date() + timedelta(days=90 if category == 'forest' else 0)
    latest = now.date() + timedelta(days=PERIODS[category][-1] - 1)
    if not earliest <= until <= latest:
        raise InvalidHorizon(f'Выберите дату с {earliest:%d.%m.%Y} по {latest:%d.%m.%Y} (UTC).')
    end = datetime.combine(until + timedelta(days=1), time.min, tzinfo=timezone.utc)
    return start, end


def _ramp(value, low, high):
    return np.clip((value - low) / (high - low), 0, 1)


def _target(bbox):
    w, s, e, n = bbox
    count = SECTORS * SAMPLES
    extra_x, extra_y = (e - w) / SECTORS, (n - s) / SECTORS
    # Keep the analysis and display grid aligned. Outside-range padding stays
    # empty rather than wrapping input rasters around the antimeridian.
    bounds = (w - extra_x, s - extra_y, e + extra_x, n + extra_y)
    size = count + 2 * PADDING
    mid_lat = (s + n) / 2
    dx = GEOD.inv(w, mid_lat, e, mid_lat)[2] / count
    dy = GEOD.inv(w, s, w, n)[2] / count
    return SimpleNamespace(bounds=bounds, shape=(size, size), crs='EPSG:4326',
                           transform=from_bounds(*bounds, size, size), spacing=(dy, dx))


def _slope(terrain, spacing):
    valid = np.isfinite(terrain)
    if not valid.any():
        return terrain.copy()
    indexes = ndimage.distance_transform_edt(~valid, return_distances=False, return_indices=True)
    filled = terrain[tuple(indexes)]
    gy, gx = np.gradient(filled, *spacing)
    return np.where(valid, np.degrees(np.arctan(np.hypot(gx, gy))), np.nan)


def _distance(mask, spacing):
    if not mask.any():
        return np.full(mask.shape, np.inf, dtype=np.float32)
    return ndimage.distance_transform_edt(~mask, sampling=spacing)


def _mean(values, mask):
    valid = mask & np.isfinite(values)
    return float(values[valid].mean()) if valid.any() else None


def _factor(label, value, unit=''):
    if value is None or not np.isfinite(value):
        return None
    return {'label': label, 'value': round(float(value), 1), 'unit': unit}


def _max_sum(values, hours):
    count = min(hours, len(values))
    return float(np.convolve(values, np.ones(count), mode='valid').max())


def _flood_context(layers, target):
    terrain = layers['terrain']
    slope = _slope(terrain, target.spacing)
    water = (layers['water'] >= 15) | np.isin(layers['land'], (80, 90))
    distance_km = _distance(water, target.spacing) / 1000
    radius = min(19, max(3, int(3000 / max(target.spacing)) * 2 + 1))
    valid = np.isfinite(terrain)
    weights = ndimage.uniform_filter(valid.astype(float), radius)
    surrounding = ndimage.uniform_filter(np.where(valid, terrain, 0).astype(float), radius)
    local_height = terrain - np.divide(surrounding, weights, out=np.zeros_like(terrain, dtype=float), where=weights > 0)
    lowland = 1 - _ramp(local_height, -12, 22)
    flat = 1 - _ramp(slope, 2, 14)
    near = 1 - _ramp(distance_km, .3, 5)
    susceptibility = (.5 * near + .5 * lowland) * (.4 + .6 * flat)
    return susceptibility, distance_km, slope


def _flood(region, context, meteorology, imerg, exposed):
    susceptibility, distance, slope = (grid[region] for grid in context)
    if meteorology is None:
        return np.full(exposed.shape, np.nan), []
    rain = np.maximum(meteorology['rain'], 0)
    intense = _max_sum(rain, 3)
    daily = _max_sum(rain, 24)
    prior = imerg if imerg is not None else float(meteorology['past_rain'][-72:].sum())
    trigger = max(_ramp(intense, 8, 50), _ramp(daily, 15, 85))
    wetness = _ramp(prior, 8, 70)
    score = trigger * (.48 + .47 * susceptibility) + .18 * wetness * susceptibility
    return score, [
        _factor(f'Наибольшая сумма дождя за {min(len(rain), 24)} ч', daily, 'мм'),
        _factor('Наибольшая сумма дождя за 3 ч', intense, 'мм') if len(rain) > 3 else None,
        _factor('Осадки за предыдущие три дня · IMERG' if imerg is not None
                else 'Осадки за предыдущие 72 часа · GFS', prior, 'мм'),
        _factor('Типичный уклон поверхности', _mean(slope, exposed), '°'),
        _factor('Среднее расстояние до воды или заболоченной местности', _mean(distance, exposed), 'км'),
    ]


def _wildfire_conditions(meteorology):
    rain = np.maximum(meteorology['rain'], 0)
    humidity = meteorology['relative_humidity_2m']
    temperature = meteorology['temperature_2m']
    wind = meteorology['wind_gusts_10m']
    antecedent = float(meteorology['past_rain'].sum())
    running_rain = np.convolve(np.r_[meteorology['past_rain'][-23:], rain], np.ones(24), mode='valid')
    dry_air = 1 - _ramp(humidity, 20, 78)
    heat = _ramp(temperature, 10, 38)
    gust = _ramp(wind, 15, 58)
    fuel_dry = 1 - _ramp(antecedent, 3, 43)
    weather = dry_air * .31 + heat * .22 + gust * .24
    weather += .23 * fuel_dry * (.3 + .7 * heat)
    weather *= 1 - .85 * _ramp(running_rain, 1, 15)
    return weather, running_rain


def _field_fire_conditions(meteorology):
    rain = np.maximum(meteorology['rain'], 0)
    running_rain = np.convolve(np.r_[meteorology['past_rain'][-47:], rain], np.ones(48), mode='valid')
    dry_air = 1 - _ramp(meteorology['relative_humidity_2m'], 26, 75)
    heat = _ramp(meteorology['temperature_2m'], 8, 34)
    gust = _ramp(meteorology['wind_gusts_10m'], 12, 55)
    spread = .18 * heat + .22 * dry_air + .34 * gust + .26 * dry_air * gust
    spread *= 1 - .85 * _ramp(running_rain, 2, 19)
    return spread, running_rain


def _fire(region, context, meteorology, exposed, agriculture):
    if meteorology is None:
        return np.full(exposed.shape, np.nan), []
    slope, thermal = (grid[region] for grid in context)
    hourly, running_rain = (_field_fire_conditions(meteorology) if agriculture else _wildfire_conditions(meteorology))
    strongest = int(np.argmax(hourly))
    weather = hourly[strongest]
    slope_factor = np.where(np.isfinite(slope), .92 + .13 * _ramp(slope, 5, 32), .98)
    score = weather * (1 if agriculture else slope_factor) + .15 * thermal
    factors = [
        _factor('Порывы ветра в час максимального риска', meteorology['wind_gusts_10m'][strongest], 'км/ч'),
        _factor('Относительная влажность в тот же час', meteorology['relative_humidity_2m'][strongest], '%'),
        _factor('Температура в тот же час', meteorology['temperature_2m'][strongest], '°C'),
        _factor('Дождь за 48 часов к этому часу' if agriculture else 'Дождь за предыдущие семь дней',
                running_rain[strongest] if agriculture else meteorology['past_rain'].sum(), 'мм'),
        _factor('Доля пашни в секторе' if agriculture else 'Доля леса и кустарника в секторе',
                100 * exposed.mean(), '%'),
    ]
    if not agriculture:
        factors.append(_factor('Типичный уклон поверхности', _mean(slope, exposed), '°'))
    if (thermal & exposed).any():
        factors.append({'label': 'Недавняя тепловая аномалия VIIRS в секторе или рядом', 'value': None, 'unit': ''})
    return score, factors


def _forest_context(layers, target):
    loss = layers['loss']
    slope = _slope(layers['terrain'], target.spacing)
    recent = loss >= data.HANSEN_LAST_YEAR - 2000 - 4
    cover = layers['land']
    historical_forest = np.isin(cover, (10, 95)) | recent
    # Rates use observed forest samples in a local moving window.
    odd_size = min(63, max(3, int(3500 / max(target.spacing)) * 2 + 1))
    numerator = ndimage.uniform_filter(recent.astype(float), odd_size)
    denominator = ndimage.uniform_filter((historical_forest & np.isfinite(loss)).astype(float), odd_size)
    proportion = np.divide(numerator, denominator, where=denominator >= .015, out=np.zeros_like(numerator))
    frontier = _distance(recent, target.spacing) / 1000
    use = _distance(np.isin(cover, (40, 50)), target.spacing) / 1000
    return proportion, frontier, use, slope


def _forest(region, context, days, exposed):
    fraction, frontier, use, slope = (grid[region] for grid in context)
    pressure = .72 * _ramp(fraction, .005, .18) + .28 * (1 - _ramp(frontier, .15, 5))
    accessibility = .6 * (1 - _ramp(use, .15, 6)) + .4 * (1 - _ramp(slope, 6, 32))
    horizon = np.interp(days, (90, 365), (.70, 1))
    return pressure * (.68 + .32 * accessibility) * horizon, [
        _factor('Потеря древесного покрова рядом за пять последних лет архива', _mean(fraction * 100, exposed), '%'),
        _factor('Среднее расстояние до зафиксированной потери покрова', _mean(frontier, exposed), 'км'),
        _factor('Среднее расстояние до пашни или застройки', _mean(use, exposed), 'км'),
        _factor('Типичный уклон поверхности', _mean(slope, exposed), '°'),
    ]


def _inputs(category, target, bbox, now, forecast_hours):
    west, south, east, north = bbox
    lat, lon = (south + north) / 2, (west + east) / 2
    points = [(round(south + y * (north - south), 4), round(west + x * (east - west), 4))
              for y in (.75, .25) for x in (.25, .75)]
    with ThreadPoolExecutor(max_workers=5) as pool:
        pending = {key: pool.submit(data.raster, key, target) for key in SOURCES[category]}
        weather = pool.submit(data.weather, points, now, forecast_hours) if category != 'forest' else None
        rain = pool.submit(data.satellite_rain, lat, lon, now) if category == 'water' else None
        thermal = pool.submit(data.thermal, target, now) if category in ('fire', 'agri_fire') else None
        layers, sources = {}, []
        for key, future in pending.items():
            layers[key], source = future.result()
            sources.append(source)
        forecasts, source = weather.result() if weather else ([None] * 4, None)
        if source:
            sources.append(source)
        imerg, source = rain.result() if rain else (None, None)
        if source:
            sources.append(source)
        anomalies, source = thermal.result() if thermal else (np.zeros(target.shape, dtype=bool), None)
        if source:
            sources.append(source)
    return layers, forecasts, imerg, anomalies, sources


def predict(bbox, category, days=None, now=None, until=None):
    now = now or datetime.now(timezone.utc)
    start, end = prediction_window(category, days, until, now)
    duration_hours = (end - start).total_seconds() / 3600
    duration_days = duration_hours / 24
    target = _target(bbox)
    layers, weather, imerg, anomalies, sources = _inputs(category, target, bbox, now, int(duration_hours))
    land = layers['land']
    coverage = np.isfinite(land)
    if category == 'water':
        # Wetland/river proximity can still be estimated from WorldCover
        # where the JRC occurrence layer has ocean or imagery gaps.
        applicable = ~np.isin(land, (70, 80, 100))
        context = _flood_context(layers, target)
    elif category == 'forest':
        # A 2021 tree-cover pixel lost after 2021 is not standing forest.
        applicable = np.isin(land, (10, 95)) & (layers['loss'] <= 21)
        coverage &= np.isfinite(layers['loss'])
        context = _forest_context(layers, target)
    else:
        applicable = land == 40 if category == 'agri_fire' else np.isin(land, (10, 20, 95))
        slope = _slope(layers['terrain'], target.spacing) if 'terrain' in layers else np.full(target.shape, np.nan)
        context = (slope, anomalies)
    applicable &= coverage

    west, south, east, north = bbox
    dx, dy = (east - west) / SECTORS, (north - south) / SECTORS
    zones = []
    counts = {level: 0 for level in ('high', 'medium', 'low', 'unavailable', 'not_applicable')}
    for row in range(SECTORS):
        for col in range(SECTORS):
            y, x = PADDING + row * SAMPLES, PADDING + col * SAMPLES
            region = np.s_[y:y+SAMPLES, x:x+SAMPLES]
            exposed = applicable[region]
            met = weather[(row >= SECTORS // 2) * 2 + (col >= SECTORS // 2)]
            factors, score = [], None
            if coverage[region].mean() < .70:
                level = 'unavailable'
            elif exposed.mean() < .05:
                level = 'not_applicable'
            else:
                if category == 'water':
                    values, factors = _flood(region, context, met, imerg, exposed)
                elif category == 'forest':
                    values, factors = _forest(region, context, duration_days, exposed)
                else:
                    values, factors = _fire(region, context, met, exposed, category == 'agri_fire')
                valid = exposed & np.isfinite(values)
                if valid.sum() < .7 * exposed.sum():
                    level = 'unavailable'
                else:
                    score = float(np.quantile(np.clip(values[valid], 0, 1), .80))
                    level = 'high' if score >= .65 else 'medium' if score >= .35 else 'low'
            counts[level] += 1
            zones.append({
                'id': row * SECTORS + col + 1, 'level': level,
                'bbox': [west + col * dx, north - (row + 1) * dy, west + (col + 1) * dx, north - row * dy],
                'index': round(score, 3) if score is not None else None,
                'factors': [f for f in factors if f is not None] if score is not None else [],
            })
    limits = list(LIMITS[category])
    if category == 'water' and imerg is None:
        limits.append('Свежие значения IMERG недоступны, для предшествующих осадков использована модель GFS.')
    evaluated = sum(counts[level] for level in ('high', 'medium', 'low'))
    return {
        'category': category, 'days': days if days is not None else round(duration_days, 3), 'method_version': '1.0',
        'until': until.isoformat() if until else None,
        'status': 'partial' if evaluated and counts['unavailable'] else 'available' if evaluated else 'unavailable',
        'updated_at': now.isoformat(), 'start': start.isoformat(), 'end': end.isoformat(),
        'zones': zones, 'counts': counts, 'sources': sources, 'limitations': limits,
    }
