"""Run a SARWatch Docker worker that pulls overflow from the public API host."""
import os
import tempfile
import threading
import time
from pathlib import Path

import requests

from .api import AnalysisRequest, calculate
from .worker_bundle import package_bundle


def run_job(base, credentials, job):
    url = f'{base}/internal/worker/{job["id"]}'
    headers = {**credentials, 'X-Worker-Lease': job['lease']}
    stopping = threading.Event()
    expired = threading.Event()
    completed_steps = 0

    def progress(completed, total):
        nonlocal completed_steps
        completed_steps = completed

    def renew():
        while not stopping.wait(25):
            try:
                response = requests.post(url+'/heartbeat', headers=headers, params={'completed': completed_steps}, timeout=12)
                if response.status_code in (401, 409):
                    expired.set()
                    return
            except requests.RequestException:
                continue

    thread = threading.Thread(target=renew, daemon=True)
    thread.start()
    try:
        with tempfile.TemporaryDirectory(prefix='sarwatch-') as temporary:
            root = Path(temporary)
            request = AnalysisRequest.model_validate(job['request'])
            calculate(request, job['catalog'], root/'output', progress)
            if not expired.is_set():
                archive = root/'result.zip'
                package_bundle(root/'output', archive)
                with archive.open('rb') as payload:
                    requests.post(url+'/result', headers=headers, data=payload, timeout=(10, 90)).raise_for_status()
    except Exception as exc:
        print(f'Job {job["id"]} returned for retry ({type(exc).__name__})', flush=True)
        if not expired.is_set():
            try:
                requests.post(url+'/retry', headers=headers, timeout=12)
            except requests.RequestException:
                pass  # the broker requeues automatically after lease expiry
    finally:
        stopping.set()
        thread.join()


def main():
    base = os.environ['SARWATCH_WORKER_API'].rstrip('/')
    token = os.environ['SARWATCH_WORKER_TOKEN']
    if len(token) < 32 or not base.startswith(('https://', 'http://127.0.0.1:')):
        raise SystemExit('Set an HTTPS worker API and a token of at least 32 characters')
    if not os.environ.get('EARTHDATA_TOKEN'):
        raise SystemExit('Set EARTHDATA_TOKEN on the satellite worker')
    headers = {'Authorization': f'Bearer {token}'}
    while True:
        try:
            response = requests.post(base+'/internal/worker/claim', headers=headers, timeout=20)
            if response.status_code == 401:
                raise SystemExit('The broker rejected the worker token')
            response.raise_for_status()
            if response.status_code == 200:
                run_job(base, headers, response.json())
                continue
        except requests.RequestException as exc:
            print(f'Cannot reach the broker ({type(exc).__name__})', flush=True)
        time.sleep(15)


if __name__ == '__main__':
    main()
