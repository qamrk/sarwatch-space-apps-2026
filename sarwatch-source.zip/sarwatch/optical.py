"""Small independent Sentinel-2 SCL windows from public Earth Search COGs."""
from pathlib import Path
from urllib.parse import urlparse
import numpy as np
import requests
import rasterio
from rasterio.warp import transform_bounds,reproject,Resampling
from rasterio.windows import from_bounds
from .limits import MAX_WINDOW_PIXELS,MAX_AUXILIARY_PIXELS

SEARCH='https://earth-search.aws.element84.com/v1/search'


def download_reference(item_id,bbox,target_path,output_path):
    from .gcov import validate_aoi
    validate_aoi(bbox)
    response=requests.post(SEARCH,json={'collections':['sentinel-2-l2a'],'ids':[item_id],'limit':1},timeout=30)
    response.raise_for_status();items=response.json()['features']
    if len(items)!=1 or items[0]['id']!=item_id:raise ValueError('Independent reference item is unavailable')
    item=items[0];url=item['assets']['scl']['href'];p=urlparse(url)
    if p.scheme!='https' or p.hostname!='sentinel-cogs.s3.us-west-2.amazonaws.com' or p.query:
        raise ValueError('Unsupported optical reference asset location')
    output_path=Path(output_path);output_path.parent.mkdir(parents=True,exist_ok=True)
    with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN='EMPTY_DIR',GDAL_HTTP_TIMEOUT='30',CPL_VSIL_CURL_CACHE_SIZE=2000000):
        with rasterio.open(target_path) as target,rasterio.open(url) as src:
            if target.width*target.height>MAX_WINDOW_PIXELS:raise ValueError('Reference pixel budget exceeded')
            bounds=transform_bounds(4326,src.crs,*bbox)
            window=from_bounds(*bounds,transform=src.transform).round_offsets().round_lengths()
            if window.width*window.height>MAX_AUXILIARY_PIXELS:raise ValueError('Reference read window too large')
            array=src.read(1,window=window)
            if not array.size:raise ValueError('Reference does not cover the AOI')
            dst=np.zeros(target.shape,dtype='uint8')
            reproject(array,dst,src_transform=src.window_transform(window),src_crs=src.crs,
                      dst_transform=target.transform,dst_crs=target.crs,
                      resampling=Resampling.nearest,src_nodata=0,dst_nodata=0,num_threads=1)
            profile=target.profile.copy();profile.update(dtype='uint8',nodata=0,count=1)
            with rasterio.open(output_path,'w',**profile) as out:
                out.write(dst,1);out.update_tags(reference_id=item_id,source_url=url,observed_at=item['properties']['datetime'])
    return {'id':item_id,'time':item['properties']['datetime'],'source_url':url,
            'clear_fraction':float(np.isin(dst,[4,5,6]).mean()),
            'attribution':'Contains modified Copernicus Sentinel-2 data (2026), Earth Search'}
