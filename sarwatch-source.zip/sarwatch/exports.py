"""Bilingual PNG exports with observation dates, AOI and real source identities."""
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont,ImageOps
from .case_assets import FONT


def render_preview(result,folder,output,lang='ru',prepared=False):
    tr=lambda a,b:a if lang=='ru' else b
    folder=Path(folder);canvas=Image.new('RGB',(1800,1210),'#102631');d=ImageDraw.Draw(canvas)
    font=lambda n:ImageFont.truetype(str(FONT),n)
    def text(x,y,value,size=19,color='#c0d5dc',width=1725):
        line=''
        for word in str(value).split():
            test=(line+' '+word).strip()
            if d.textlength(test,font=font(size))>width and line:
                d.text((x,y),line,font=font(size),fill=color);y+=size+8;line=word
            else:line=test
        if line:d.text((x,y),line,font=font(size),fill=color);y+=size+8
        return y
    title=result.get('title',{}).get(lang,tr('Сравнение наблюдений NISAR','NISAR observation comparison'))
    text(35,22,'SARWatch / '+title,30,'white')
    text(35,72,tr('Реальные спутниковые наблюдения. Экспериментальная оценка.','Real satellite observations. Experimental estimate.'),18)
    metrics=result.get('metrics',{}) if prepared else result.get('water',{})
    water=all(k in metrics for k in ('water_before_km2','water_after_km2'))
    root=folder if prepared else folder/'mapping';sources=result['sources']
    names=['before','after','water' if water else 'delta']
    labels=[tr('До / ','Before / ')+sources[0]['start'][:10],tr('После / ','After / ')+sources[1]['start'][:10],tr('Водный класс','Water class') if water else tr('Разность dB','Difference in dB')]
    for i,(name,label) in enumerate(zip(names,labels)):
        x=35+i*585;text(x,115,label,21,'white',550)
        with Image.open(root/f'{name}.png') as im:
            rgba=im.convert('RGBA');bg=Image.new('RGBA',rgba.size,'#253b46');bg.alpha_composite(rgba)
            panel=ImageOps.contain(bg.convert('RGB'),(550,570),Image.Resampling.NEAREST)
            canvas.paste(panel,(x+(550-panel.width)//2,160+(570-panel.height)//2))
    y=758
    if water:
        y=text(35,y,f"{tr('Вода в области','Water in area')}: {metrics['water_before_km2']:.3f} / {metrics['water_after_km2']:.3f} km²",24,'white')
        legend=[('#266fc0',tr('Вода в обе даты','Water on both dates')),('#2cdecf',tr('Появление водного класса','Water class gain')),('#f6a73d',tr('Исчезновение водного класса','Water class loss'))]
        for i,(color,label) in enumerate(legend):
            d.rectangle((35+585*i,y+3,52+585*i,y+20),fill=color);text(64+585*i,y,label,17,width=510)
        y+=40
    else:
        c=result.get('comparison',result.get('metrics',{}))
        y=text(35,y,f"{tr('Медианная разность','Median difference')}: {c['median_delta_db']:+.3f} dB · {tr('Сопоставимых пикселей','Comparable pixels')}: {c['comparable_pixels']}",23,'white')
        y=text(35,y,tr('Красный: рост; синий: снижение; белый: около нуля. Общая шкала двух серых панелей.','Red: increase; blue: decrease; white: near zero. The two grey panels share a scale.'),18)
    flood=result.get('flood',{})
    if flood.get('status')=='experimental':
        y=text(35,y,f"{tr('Возможное затопление после фильтров','Potential inundation after filters')}: {flood['candidate_area_km2']:.3f} km². "+tr('Не подтверждённое событие.','Not a confirmed event.'),18,'#f3c382')
    if result.get('bbox'):y=text(35,y,'WGS84 W/S/E/N: '+', '.join(f'{v:.5f}' for v in result['bbox'])+' · ↑ N',17)
    y=text(35,y,tr('Различия сигнала не устанавливают причину, ущерб или площадь пожара. Водный класс не подтверждает наводнение.','Signal differences do not establish a cause, damage or burned area. Water class does not confirm flooding.'),18,'#f3c382')
    for source in sources:y=text(35,y,source['id'],13)
    reviewed=result.get('validation_status')=='case_compared_with_optical_reference'
    text(35,y,tr('Сверка с Sentinel-2 относится только к этому примеру.','Sentinel-2 agreement applies only to this case.') if reviewed else tr('Радарная оценка без независимой проверки точности.','Radar estimate without an independent accuracy assessment.'),16)
    text(35,1166,'NASA/JPL/ASF NISAR · Copernicus Sentinel-2 · '+tr('Исследовательский прототип','Research prototype'),14)
    output=Path(output);output.parent.mkdir(parents=True,exist_ok=True);canvas.save(output);return output
