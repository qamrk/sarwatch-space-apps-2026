"""Inspect and crop a GCOV layer; no unverified flood classification is produced."""
import time
from pathlib import Path
import numpy as np
import h5py
from pyproj import CRS, Geod, Transformer
import rasterio
from rasterio.transform import from_origin
from .range_reader import RangeReader
from .limits import MAX_SIDE_KM,MAX_WINDOW_PIXELS


def validate_aoi(bbox):
    w,s,e,n = bbox
    if not (-180 <= w < e <= 180 and -80 <= s < n <= 84):
        raise ValueError('Invalid AOI or unsupported polar/antimeridian region')
    g = Geod(ellps='WGS84')
    widths = [abs(g.inv(w, lat, e, lat)[2]) for lat in (s,n)]
    height = abs(g.inv(w,s,w,n)[2])
    if max(*widths, height) > MAX_SIDE_KM*1000:
        raise ValueError(f'Each AOI side must be at most {MAX_SIDE_KM} km')


def inspect_window(url, token, bbox, output, channel='HHHH', budget=100_000_000, seconds=900):
    validate_aoi(bbox)
    if channel not in ('auto','HHHH','VVVV','HVHV','VHVH'):
        raise ValueError('Use a real diagonal power channel')
    started = time.monotonic()
    with RangeReader(url, token, budget=budget, seconds=seconds) as remote:
        with h5py.File(remote, 'r', rdcc_nbytes=1_048_576) as f:
            root = f['/science/LSAR/GCOV/grids/frequencyA']
            available = [k for k in ('HHHH','VVVV','HVHV','VHVH') if k in root]
            if channel=='auto':
                if not available:raise ValueError('No supported intensity channel in this product')
                channel=available[0]
            if channel not in available: raise ValueError(f'Channel absent; available: {available}')
            proj = root['projection']
            epsg = int(proj.attrs.get('epsg_code', proj[()]))
            crs = CRS.from_epsg(epsg)
            if not crs.is_projected or any(a.unit_name != 'metre' for a in crs.axis_info):
                raise ValueError('Expected a projected metric GCOV grid')
            x,y = root['xCoordinates'][:], root['yCoordinates'][:]
            dx,dy = float(root['xCoordinateSpacing'][()]), float(root['yCoordinateSpacing'][()])
            if dx <= 0 or dy >= 0 or len(x)<2 or len(y)<2:
                raise ValueError('Unsupported grid orientation')
            if not (np.allclose(np.diff(x),dx) and np.allclose(np.diff(y),dy)):
                raise ValueError('Nonuniform coordinate grid')
            left,bottom,right,top = Transformer.from_crs(4326, crs, always_xy=True).transform_bounds(*bbox, densify_pts=21)
            if left < x[0]-dx/2 or right > x[-1]+dx/2 or top > y[0]-dy/2 or bottom < y[-1]+dy/2:
                raise ValueError('The GCOV grid does not fully cover the AOI')
            cols=np.flatnonzero((x>=left-dx/2)&(x<=right+dx/2))
            rows=np.flatnonzero((y>=bottom+dy/2)&(y<=top-dy/2))
            if not len(cols) or not len(rows): raise ValueError('AOI contains no pixels')
            if len(cols)*len(rows)>MAX_WINDOW_PIXELS: raise ValueError('Pixel budget exceeded; choose a smaller AOI')
            rs,cs = slice(rows[0],rows[-1]+1),slice(cols[0],cols[-1]+1)
            power=np.asarray(root[channel][rs,cs],dtype='float32')
            if 'mask' not in root: raise ValueError('GCOV subswath mask is required')
            mask=root['mask'][rs,cs]
            if mask.dtype != np.dtype('uint8'): raise ValueError('Unexpected GCOV mask type')
            if int(root['mask'].attrs.get('_FillValue',255)) != 255:
                raise ValueError('Unsupported GCOV mask fill convention')
            xx,yy=np.meshgrid(x[cs],y[rs])
            lon,lat=Transformer.from_crs(crs,4326,always_xy=True).transform(xx,yy)
            in_aoi=(lon>=bbox[0])&(lon<=bbox[2])&(lat>=bbox[1])&(lat<=bbox[3])
            valid=np.isfinite(power)&(power>0)&(mask!=0)&(mask!=255)&in_aoi
            if not valid.any(): raise ValueError('No finite positive power samples in AOI')
            db=np.full(power.shape,np.nan,dtype='float32')
            db[valid]=10*np.log10(power[valid])
            transform=from_origin(float(x[cols[0]]-dx/2),float(y[rows[0]]-dy/2),dx,-dy)
            output=Path(output)
            output.parent.mkdir(parents=True,exist_ok=True)
            values, counts=np.unique(mask,return_counts=True)
            mask_info={str(v):int(c) for v,c in zip(values,counts)}
            with rasterio.open(output,'w',driver='GTiff',height=db.shape[0],width=db.shape[1],count=1,dtype='float32',crs=crs,transform=transform,nodata=np.nan,compress='deflate') as dst:
                dst.write(db,1)
                dst.update_tags(quality_mask_applied='true',channel=channel,source_url=url,
                                source_id=url.rsplit('/',1)[-1].removesuffix('.h5'),
                                mask_convention='GCOV subswath: exclude 0 and 255',quantity='gamma0_db')
            return dict(status='window_read_only_not_validated',output=str(output),source_url=url,bbox=bbox,epsg=epsg,
                        channel=channel,available_channels=available,shape=list(db.shape),
                        pixel_spacing_m=[dx,-dy],positive_finite_fraction=float(valid.mean()),
                        raw_mask_histogram=mask_info,quality_mask_applied=True,
                        source_bytes=remote.size,transferred_bytes=remote.transferred,
                        elapsed_seconds=round(time.monotonic()-started,3),
                        warning='Focused-sample mask applied. This does not mask terrain shadow or establish water/flood classification.')
