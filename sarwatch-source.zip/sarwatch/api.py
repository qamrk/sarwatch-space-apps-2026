"""Real-data API. Start with: uvicorn sarwatch.api:app --workers 1."""
import json
import os
import threading
import shutil
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from pathlib import Path
from uuid import uuid4
from contextlib import asynccontextmanager
from dotenv import load_dotenv
from fastapi import FastAPI,HTTPException,Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse,Response
from pydantic import BaseModel,ConfigDict,Field,field_validator,model_validator
from .limits import MAX_SIDE_KM,AREA_SIZES_KM,MAX_NETWORK_BYTES

load_dotenv(override=False)
ROOT=Path(os.environ.get('SARWATCH_DATA_DIR','data/jobs'))
CASE_ROOT=Path(os.environ.get('SARWATCH_CASES_DIR',str(Path(__file__).parent.parent/'cases')))
WEB_ROOT=Path(os.environ.get('SARWATCH_WEB_DIR',str(Path(__file__).parent.parent/'frontend/dist')))
BUSY=threading.Lock();GUARD=threading.Lock();POOL=None
SCENES={};JOBS={}


@asynccontextmanager
async def lifespan(app):
    global POOL
    POOL=ThreadPoolExecutor(max_workers=1)
    ROOT.mkdir(parents=True,exist_ok=True)
    restore_jobs()
    yield
    POOL.shutdown(wait=False,cancel_futures=True)


app=FastAPI(title='SARWatch',version='0.5.0',lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=[o.strip() for o in os.environ.get('CORS_ORIGINS','http://localhost:5173,http://127.0.0.1:5173').split(',') if o.strip()],
                   allow_methods=['GET','POST'],allow_headers=['Content-Type'])


class AnalysisRequest(BaseModel):
    model_config=ConfigDict(extra='forbid',allow_inf_nan=False)
    bbox:tuple[float,float,float,float]
    before_id:str=Field(min_length=20,max_length=200)
    after_id:str=Field(min_length=20,max_length=200)
    theme:str='water'
    channel:str='auto'
    side_km:float|None=Field(default=None,ge=1,le=MAX_SIDE_KM)

    @model_validator(mode='after')
    def check_requested_square(self):
        if self.side_km is not None:
            from pyproj import Geod
            w,s,e,n=self.bbox;g=Geod(ellps='WGS84')
            extent=max(abs(g.inv(w,s,e,s)[2]),abs(g.inv(w,n,e,n)[2]),abs(g.inv(w,s,w,n)[2]))/1000
            area=abs(g.polygon_area_perimeter([w,e,e,w],[s,s,n,n])[0])/1e6
            if not .98*self.side_km<=extent<=1.01*self.side_km or area<.85*self.side_km**2:
                raise ValueError('Requested side does not match the AOI square')
        return self

    @field_validator('bbox')
    @classmethod
    def check_bbox(cls,v):
        from .gcov import validate_aoi
        validate_aoi(v);return v

    @field_validator('theme')
    @classmethod
    def check_theme(cls,v):
        if v not in ('water','forest','fire','agri_fire'):raise ValueError('Unsupported theme')
        return v

    @field_validator('channel')
    @classmethod
    def check_channel(cls,v):
        if v not in ('auto','HHHH','HVHV','VVVV','VHVH'):raise ValueError('Unsupported channel')
        return v


@app.get('/api/health')
def health():
    return {'application':'sarwatch','version':app.version,'status':'ok','data_access_configured':bool(os.environ.get('EARTHDATA_TOKEN')),
            'analysis_busy':BUSY.locked(),'max_side_km':MAX_SIDE_KM,'area_sizes_km':AREA_SIZES_KM,'network_budget_mb':MAX_NETWORK_BYTES/1_000_000,
            'classification':'experimental','flood_classification_available':True}


def available_cases():
    result=[]
    for p in sorted(CASE_ROOT.glob('*/manifest.json')):
        try:case=json.loads(p.read_text(encoding='utf-8'))
        except (OSError,json.JSONDecodeError):continue
        if not case.get('ready_for_demo') or case.get('id')!=p.parent.name:continue
        case['preview_urls']={lang:f"/api/cases/{case['id']}/assets/{file}" for lang,file in case['previews'].items()}
        for layer in case['layers']:layer['url']=f"/api/cases/{case['id']}/assets/{layer['file']}"
        if (p.parent/'water.geojson').is_file():case['vector_url']=f"/api/cases/{case['id']}/assets/water.geojson"
        result.append(case)
    return sorted(result,key=lambda c:c.get('theme')!='water')


@app.get('/api/cases')
def cases():return {'cases':available_cases()}


@app.get('/presets/index.json')
@app.get('/api/presets')
def presets():
    path=Path(__file__).parent/'assets/presets.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {'presets':[]}


@app.get('/api/scenes/{scene_id}/browse.png')
def scene_browse(scene_id:str):
    with GUARD:scene=SCENES.get(scene_id)
    if not scene:raise HTTPException(404,'Refresh scene search before viewing browse')
    urls=[u for u in scene.get('browse_urls',[]) if not u.endswith('_thumbnail.png')]
    if not urls:raise HTTPException(404,'No ASF browse available')
    from .browse import preview_png
    try:return Response(preview_png(urls[0]),media_type='image/png',headers={'Cache-Control':'public, max-age=3600'})
    except Exception:raise HTTPException(502,'ASF browse is temporarily unavailable; scientific analysis remains separate') from None


@app.get('/api/cases/{case_id}/assets/{name}')
def case_asset(case_id:str,name:str):
    if name not in ('before.png','after.png','delta.png','water.png','potential_flood.png','water.geojson','preview-ru.png','preview-en.png','report-ru.pdf','report-en.pdf'):
        raise HTTPException(404,'Unknown asset')
    if not any(c['id']==case_id for c in available_cases()):raise HTTPException(404,'Case not found')
    p=CASE_ROOT/case_id/name
    if not p.is_file():raise HTTPException(404,'Asset not found')
    media='application/pdf' if name.endswith('.pdf') else 'application/geo+json' if name.endswith('.geojson') else 'image/png'
    return FileResponse(p,media_type=media)


@app.get('/api/scenes')
def scenes(bbox:str,start:date,end:date,maturity:str='PROVISIONAL',limit:int=Query(250,ge=1,le=250)):
    from .catalog import search
    from .gcov import validate_aoi
    try:
        coords=[float(x) for x in bbox.split(',')]
        if len(coords)!=4:raise ValueError('Expected west,south,east,north')
        validate_aoi(coords)
        if end<start or maturity not in ('BETA','PROVISIONAL','VALIDATED'):raise ValueError('Invalid dates or maturity')
        result=search(coords,start.isoformat()+'T00:00:00Z',end.isoformat()+'T23:59:59Z',maturity,limit)
        from shapely.geometry import shape,box
        full={s['id']:shape(s['geometry']).covers(box(*coords)) for s in result['scenes']}
        result['pairs']=[p for p in result['pairs'] if full[p['before']] and full[p['after']]]
        with GUARD:
            # Bounded in-memory catalogue; users refresh expired selections.
            if len(SCENES)>1500:SCENES.clear()
            SCENES.update({s['id']:s for s in result['scenes']})
        return result
    except ValueError as exc:raise HTTPException(422,str(exc)) from None
    except Exception:raise HTTPException(502,'Satellite catalogue is temporarily unavailable') from None


def result_assets(job_id,result):
    for layer in result['layers']:layer['url']=f"/api/analyses/{job_id}/assets/{layer['file']}"
    assets={'comparison':f'/api/analyses/{job_id}/map.png',
            'reports':{lang:f'/api/analyses/{job_id}/assets/report-{lang}.pdf' for lang in ('ru','en')}}
    if result['water']['status']=='experimental':
        assets.update(water=f'/api/analyses/{job_id}/assets/water.png',water_geojson=f'/api/analyses/{job_id}/assets/water.geojson')
    return assets


def restore_jobs():
    """Reload bounded completed results after restart; never resume partial calculations."""
    paths=sorted(ROOT.glob('*/result.json'),key=lambda p:p.stat().st_mtime)[-32:]
    for path in paths:
        if len(path.parent.name)!=32 or any(c not in '0123456789abcdef' for c in path.parent.name):continue
        try:
            result=json.loads(path.read_text());assets=result_assets(path.parent.name,result)
            if not all((path.parent/f'report-{lang}.pdf').is_file() for lang in ('ru','en')):continue
            JOBS[path.parent.name]={'id':path.parent.name,'status':'completed','result':result,'assets':assets}
        except (OSError,ValueError,KeyError,TypeError):continue


def execute(job_id,request,catalog):
    from .pipeline import run_analysis
    try:
        with GUARD:JOBS[job_id]['status']='processing'
        result=run_analysis(catalog,request.before_id,request.after_id,request.bbox,
                            os.environ.get('EARTHDATA_TOKEN',''),ROOT/job_id,request.theme,request.channel,request.side_km)
        assets=result_assets(job_id,result)
        with GUARD:JOBS[job_id].update(status='completed',result=result,assets=assets)
    except ValueError as exc:
        with GUARD:JOBS[job_id].update(status='failed',error=str(exc))
    except Exception:
        with GUARD:JOBS[job_id].update(status='failed',error='Unable to read or process satellite data; check service access and retry')
    finally:BUSY.release()


@app.post('/api/analyses',status_code=202)
def create_analysis(request:AnalysisRequest):
    if not os.environ.get('EARTHDATA_TOKEN'):raise HTTPException(503,'Satellite data access is not configured')
    with GUARD:
        if request.before_id not in SCENES or request.after_id not in SCENES:
            raise HTTPException(409,'Refresh scene search before analysis')
        catalog={'scenes':[SCENES[request.before_id],SCENES[request.after_id]]}
    if not BUSY.acquire(blocking=False):raise HTTPException(429,'One analysis is already running',headers={'Retry-After':'10'})
    job_id=uuid4().hex
    try:
        with GUARD:
            if len(JOBS)>=32:
                # Only evict completed records; files remain private and ephemeral.
                old=next((k for k,v in JOBS.items() if v['status'] in ('completed','failed')),None)
                if old:
                    JOBS.pop(old)
                    shutil.rmtree(ROOT/old,ignore_errors=True)
            JOBS[job_id]={'id':job_id,'status':'waiting'}
        POOL.submit(execute,job_id,request,catalog)
    except Exception:
        BUSY.release();raise
    return {'id':job_id,'status':'waiting','status_url':f'/api/analyses/{job_id}'}


@app.get('/api/analyses/{job_id}')
def analysis(job_id:str):
    with GUARD:
        if job_id not in JOBS:raise HTTPException(404,'Analysis not found or expired after server restart')
        return dict(JOBS[job_id])


def completed_dir(job_id):
    with GUARD:
        if job_id not in JOBS:raise HTTPException(404,'Analysis expired or not found')
        if JOBS[job_id]['status']!='completed':raise HTTPException(409,'Analysis is not complete')
    return ROOT/job_id


@app.get('/api/analyses/{job_id}/map.png')
def map_png(job_id:str,lang:str=Query('ru',pattern='^(ru|en)$')):
    folder=completed_dir(job_id);path=folder/f'preview-{lang}.png'
    if not path.is_file():path=folder/'comparison/comparison.png'
    if not path.is_file():raise HTTPException(404,'Image unavailable')
    return FileResponse(path,media_type='image/png',filename=f'sarwatch-{lang}.png')


@app.get('/api/analyses/{job_id}/report.pdf')
def report_pdf(job_id:str,lang:str=Query('ru',pattern='^(ru|en)$')):
    path=completed_dir(job_id)/f'report-{lang}.pdf'
    if not path.is_file():raise HTTPException(404,'Report unavailable')
    return FileResponse(path,media_type='application/pdf',filename=f'sarwatch-{lang}.pdf')


@app.get('/api/analyses/{job_id}/assets/{name}')
def asset(job_id:str,name:str):
    if name not in ('before.png','after.png','delta.png','water.png','potential_flood.png','water.geojson','report-ru.pdf','report-en.pdf'):raise HTTPException(404,'Unknown asset')
    folder=completed_dir(job_id)
    p=folder/name if name.endswith('.pdf') else folder/('water' if name.endswith('.geojson') else 'mapping')/name
    if not p.is_file():raise HTTPException(404,'Asset is unavailable for this analysis')
    media='application/pdf' if name.endswith('.pdf') else 'image/png' if name.endswith('.png') else 'application/geo+json'
    return FileResponse(p,media_type=media)


# One origin serves both the actual app and the API; opening an HTML file is not needed.
@app.get('/cases/index.json')
def public_case_index():return {'cases':available_cases()}


@app.get('/cases/{case_id}/{name}')
def public_case_asset(case_id:str,name:str):return case_asset(case_id,name)


@app.get('/assets/{name:path}')
def web_asset(name:str):
    root=(WEB_ROOT/'assets').resolve();path=(root/name).resolve()
    if not path.is_relative_to(root) or not path.is_file():raise HTTPException(404,'Web asset not found')
    return FileResponse(path)


@app.api_route('/',methods=['GET','HEAD'])
def frontend():
    path=WEB_ROOT/'index.html'
    if not path.is_file():raise HTTPException(503,'Frontend build missing; follow README installation steps')
    return FileResponse(path,media_type='text/html',headers={'Cache-Control':'no-cache'})
