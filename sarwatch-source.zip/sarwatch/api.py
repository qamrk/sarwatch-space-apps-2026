"""Real-data API. Start with: uvicorn sarwatch.api:app --workers 1."""
import json
import logging
import os
import threading
import shutil
import tempfile
from time import monotonic
from concurrent.futures import ThreadPoolExecutor
from datetime import date
from pathlib import Path
from typing import Annotated, Literal
from uuid import uuid4
from contextlib import asynccontextmanager
from dotenv import load_dotenv
from fastapi import FastAPI,Header,HTTPException,Query,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse,Response
from pydantic import BaseModel,ConfigDict,Field,field_validator,model_validator
from requests import RequestException
from .geocoding import search_places
from .limits import MAX_SIDE_KM,AREA_SIZES_KM,MAX_NETWORK_BYTES,LANDSAT_START,NISAR_START,automatic_sensor
from .series import MAX_DATES
from .worker_bundle import MAX_BUNDLE_BYTES, install_bundle

load_dotenv(override=False)
ROOT=Path(os.environ.get('SARWATCH_DATA_DIR','data/jobs'))
CASE_ROOT=Path(os.environ.get('SARWATCH_CASES_DIR',str(Path(__file__).parent.parent/'cases')))
WEB_ROOT=Path(os.environ.get('SARWATCH_WEB_DIR',str(Path(__file__).parent.parent/'frontend/dist')))
GUARD = threading.Lock()
POOL = None
OVERVIEW_POOL = None
HEAVY_WORKERS = max(1, int(os.environ.get('SARWATCH_HEAVY_WORKERS', '2')))
OVERVIEW_WORKERS = 2
QUEUE_LIMIT = max(1, int(os.environ.get('SARWATCH_QUEUE_LIMIT', '8')))
SCENES={};JOBS={}
PENDING = {}
LEASES = {}
LEASE_SECONDS = 120
PREDICTION_SLOTS = threading.BoundedSemaphore(2)
LOG = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app):
    global POOL, OVERVIEW_POOL
    POOL = ThreadPoolExecutor(max_workers=HEAVY_WORKERS)
    OVERVIEW_POOL = ThreadPoolExecutor(max_workers=OVERVIEW_WORKERS)
    ROOT.mkdir(parents=True,exist_ok=True)
    restore_jobs()
    try:
        yield
    finally:
        POOL.shutdown(wait=False,cancel_futures=True)
        OVERVIEW_POOL.shutdown(wait=False,cancel_futures=True)


app=FastAPI(title='SARWatch',version='0.10.0',lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=[o.strip() for o in os.environ.get('CORS_ORIGINS','http://localhost:5173,http://127.0.0.1:5173').split(',') if o.strip()],
                   allow_methods=['GET','POST'],allow_headers=['Content-Type'])


class AnalysisRequest(BaseModel):
    model_config=ConfigDict(extra='forbid',allow_inf_nan=False)
    bbox:tuple[float,float,float,float]
    before_id:str|None=Field(default=None,min_length=20,max_length=220)
    after_id:str|None=Field(default=None,min_length=20,max_length=220)
    scene_ids:list[Annotated[str, Field(min_length=20,max_length=220)]]|None=Field(default=None,min_length=3,max_length=MAX_DATES)
    sensor:Literal['nisar','landsat','modis']='nisar'
    theme:str='water'
    channel:str='auto'
    side_km:float|None=Field(default=None,ge=1,le=MAX_SIDE_KM)

    @model_validator(mode='after')
    def check_requested_square(self):
        if self.scene_ids is None:
            if not self.before_id or not self.after_id or self.before_id == self.after_id:
                raise ValueError('Select two distinct observations')
        elif self.before_id or self.after_id or len(set(self.scene_ids)) != len(self.scene_ids):
            raise ValueError('Select a series of distinct observations')
        if self.side_km is not None:
            from pyproj import Geod
            w,s,e,n=self.bbox;g=Geod(ellps='WGS84')
            extent=max(abs(g.inv(w,s,e,s)[2]),abs(g.inv(w,n,e,n)[2]),abs(g.inv(w,s,w,n)[2]))/1000
            area=abs(g.polygon_area_perimeter([w,e,e,w],[s,s,n,n])[0])/1e6
            if not .98*self.side_km<=extent<=1.01*self.side_km or area<.85*self.side_km**2:
                raise ValueError('Requested side does not match the AOI square')
        return self

    @field_validator('bbox')
    @classmethod
    def check_bbox(cls,v):
        from .gcov import validate_aoi
        validate_aoi(v);return v

    @field_validator('theme')
    @classmethod
    def check_theme(cls,v):
        if v not in ('water','forest','fire','agri_fire'):raise ValueError('Unsupported theme')
        return v

    @field_validator('channel')
    @classmethod
    def check_channel(cls,v):
        if v not in ('auto','HHHH','HVHV','VVVV','VHVH'):raise ValueError('Unsupported channel')
        return v


@app.get('/api/health')
def health():
    from .weather import configured_provider

    provider = configured_provider()
    with GUARD:
        recover_expired_workers()
        active = sum(j['status'] == 'processing' for j in JOBS.values())
        waiting = sum(j['status'] == 'waiting' for j in JOBS.values())
    return {'application':'sarwatch','version':app.version,'status':'ok','data_access_configured':bool(os.environ.get('EARTHDATA_TOKEN')),
            'ai_configured':bool(provider),'ai_provider':provider,
            'external_worker_enabled':len(os.environ.get('SARWATCH_WORKER_TOKEN', '')) >= 32,
            'analysis_busy':bool(active),'analysis_running':active,'analysis_waiting':waiting,'max_dates':MAX_DATES,
            'max_side_km':MAX_SIDE_KM,'area_sizes_km':AREA_SIZES_KM,'network_budget_mb':MAX_NETWORK_BYTES/1_000_000,
            'classification':'experimental','flood_classification_available':True,
            'landsat_start':LANDSAT_START,'nisar_start':NISAR_START}


def available_cases():
    result=[]
    for p in sorted(CASE_ROOT.glob('*/manifest.json')):
        try:case=json.loads(p.read_text(encoding='utf-8'))
        except (OSError,json.JSONDecodeError):continue
        if not case.get('ready_for_demo') or case.get('id')!=p.parent.name:continue
        case['preview_urls']={lang:f"/api/cases/{case['id']}/assets/{file}" for lang,file in case['previews'].items()}
        for layer in case['layers']:layer['url']=f"/api/cases/{case['id']}/assets/{layer['file']}"
        if (p.parent/'water.geojson').is_file():case['vector_url']=f"/api/cases/{case['id']}/assets/water.geojson"
        result.append(case)
    return sorted(result,key=lambda c:c.get('theme')!='water')


@app.get('/api/cases')
def cases():return {'cases':available_cases()}


@app.get('/api/map-region')
def map_region(request: Request, response: Response):
    country = request.headers.get('CF-IPCountry', '').upper()
    response.headers['Cache-Control'] = 'private, no-store'
    if len(country) != 2 or not country.isascii() or not country.isalpha() or country in ('XX', 'T1'):
        country = None
    return {'country': country}


@app.get('/api/places')
def places(q: Annotated[str, Query(min_length=2, max_length=160)], lang: Literal['en', 'ru', 'kk'] = 'en'):
    query = q.strip()
    if len(query) < 2:
        raise HTTPException(status_code=422, detail='Enter at least two characters')
    try:
        return {'places': search_places(query, lang)}
    except (RequestException, ValueError) as exc:
        raise HTTPException(status_code=502, detail='Place search is temporarily unavailable') from exc


@app.get('/presets/index.json')
@app.get('/api/presets')
def presets():
    path=Path(__file__).parent/'assets/presets.json'
    return json.loads(path.read_text(encoding='utf-8')) if path.is_file() else {'presets':[]}


@app.get('/api/scenes/{scene_id}/browse.png')
def scene_browse(scene_id:str):
    with GUARD:scene=SCENES.get(scene_id)
    if not scene:
        scene=next((s for case in available_cases() for s in case.get('sources',[]) if s['id']==scene_id),None)
    if not scene:raise HTTPException(404,'Refresh scene search before viewing browse')
    urls=[u for u in scene.get('browse_urls',scene.get('browse',[])) if not u.endswith('_thumbnail.png')]
    if not urls:raise HTTPException(404,'No ASF browse available')
    from .browse import preview_png
    try:return Response(preview_png(urls[0]),media_type='image/png',headers={'Cache-Control':'public, max-age=3600'})
    except Exception:raise HTTPException(502,'ASF browse is temporarily unavailable; scientific analysis remains separate') from None


@app.get('/api/cases/{case_id}/assets/{name}')
def case_asset(case_id:str,name:str):
    if name not in ('before.png','after.png','delta.png','water.png','potential_flood.png','water.geojson','preview-ru.png','preview-en.png','preview-kk.png','report-ru.pdf','report-en.pdf','report-kk.pdf'):
        raise HTTPException(404,'Unknown asset')
    if not any(c['id']==case_id for c in available_cases()):raise HTTPException(404,'Case not found')
    p=CASE_ROOT/case_id/name
    if not p.is_file():raise HTTPException(404,'Asset not found')
    media='application/pdf' if name.endswith('.pdf') else 'application/geo+json' if name.endswith('.geojson') else 'image/png'
    return FileResponse(p,media_type=media)


@app.get('/api/scenes')
def scenes(bbox:str,start:date,end:date,maturity:str='PROVISIONAL',limit:int=Query(250,ge=1,le=250),
           sensor:Literal['auto','nisar','landsat','modis']='nisar',theme:Literal['water','forest','fire','agri_fire']='water'):
    from .catalog import search
    from .gcov import validate_aoi
    try:
        coords=[float(x) for x in bbox.split(',')]
        if len(coords)!=4:raise ValueError('Expected west,south,east,north')
        validate_aoi(coords)
        if end<start or maturity not in ('AUTO','BETA','PROVISIONAL','VALIDATED'):raise ValueError('Invalid dates or maturity')
        requested_sensor = sensor
        if sensor == 'nisar' and start.isoformat() < NISAR_START:
            sensor = 'auto'
        sensor = automatic_sensor(sensor, start)
        result = {'scenes': [], 'pairs': [], 'sensor': 'modis' if sensor == 'modis' else 'nisar'}
        if sensor == 'nisar':
            if requested_sensor == 'nisar' and maturity != 'AUTO':
                result = search(coords, f'{start}T00:00:00Z', f'{end}T23:59:59Z', maturity, limit)
                from shapely.geometry import shape, box
                aoi = box(*coords)
                full = {s['id'] for s in result['scenes'] if shape(s['geometry']).covers(aoi)}
                result['pairs'] = [p for p in result['pairs'] if p['before'] in full and p['after'] in full]
            else:
                from .catalog import search_near_dates
                result = search_near_dates(coords, start, end, limit, maturity)
            result['sensor'] = 'nisar'
        if sensor == 'landsat' or (sensor == 'auto' and not result['pairs']):
            if start.isoformat() < LANDSAT_START:
                raise ValueError(f'Landsat Collection 2 Level-2 starts on {LANDSAT_START}')
            from .landsat import public_scene, search_epochs
            try:
                result = search_epochs(coords, start, end)
            except Exception:
                if sensor == 'landsat' or start.year < 2000:
                    raise
        if sensor == 'modis' or (sensor == 'auto' and not result['pairs'] and start.year >= 2000):
            from .modis import START, search_comparison
            if start >= START:
                result = search_comparison(coords, start, end)
        result['sensor'] = result.get('sensor', sensor)
        with GUARD:
            # Bounded in-memory catalogue; users refresh expired selections.
            if len(SCENES)>1500:SCENES.clear()
            SCENES.update({s['id']:s for s in result['scenes']})
        if result['sensor'] == 'landsat':
            result['scenes'] = [public_scene(s) for s in result['scenes']]
        return result
    except ValueError as exc:raise HTTPException(422,str(exc)) from None
    except Exception:raise HTTPException(502,'Satellite catalogue is temporarily unavailable') from None


@app.get('/api/series')
def series(bbox: str, dates: Annotated[list[date], Query(min_length=3, max_length=MAX_DATES)],
           sensor: Literal['auto','nisar','landsat','modis'] = 'auto',
           maturity: Literal['AUTO','BETA','PROVISIONAL','VALIDATED'] = 'PROVISIONAL'):
    from .gcov import validate_aoi
    from .landsat import public_scene
    from .series import search_series

    try:
        coords = tuple(map(float, bbox.split(',')))
        validate_aoi(coords)
        if dates != sorted(set(dates)) or dates[-1] > date.today() or dates[0].isoformat() < LANDSAT_START:
            raise ValueError('Select distinct dates in chronological order within the archive')
        source, observations = search_series(coords, dates, sensor, maturity)
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    except Exception:
        raise HTTPException(502, 'Satellite catalogue is temporarily unavailable') from None
    with GUARD:
        if len(SCENES) > 1500:
            SCENES.clear()
        SCENES.update({scene['id']: scene for scene in observations})
    return {'sensor': source, 'scenes': [public_scene(scene) for scene in observations],
            'series': [scene['id'] for scene in observations], 'pairs': []}


@app.get('/api/nisar/dates')
def nisar_dates(bbox: str, dates: Annotated[list[date], Query(min_length=2, max_length=MAX_DATES)]):
    from .catalog import recommend_dates
    from .gcov import validate_aoi

    try:
        coords = tuple(map(float, bbox.split(',')))
        validate_aoi(coords)
        if dates != sorted(set(dates)) or dates[-1] > date.today() or dates[0].isoformat() < NISAR_START:
            raise ValueError('Select distinct dates in chronological order within the NISAR archive')
    except ValueError as exc:
        raise HTTPException(422, str(exc)) from None
    try:
        return recommend_dates(coords, dates)
    except Exception:
        raise HTTPException(502, 'NISAR catalogue is temporarily unavailable') from None


@app.get('/api/predictions')
def environmental_prediction(
    bbox: Annotated[str, Query(max_length=140)],
    category: Literal['water', 'fire', 'agri_fire', 'forest'],
    days: Annotated[int, Query(ge=1, le=365)],
):
    from .gcov import validate_aoi
    from .prediction import PERIODS, predict

    try:
        coords = tuple(map(float, bbox.split(',')))
        validate_aoi(coords)
    except ValueError:
        raise HTTPException(422, 'Выберите область размером до 100 × 100 км в поддерживаемых широтах.') from None
    if days not in PERIODS[category]:
        raise HTTPException(422, 'Период недоступен для выбранной категории.')
    if not PREDICTION_SLOTS.acquire(blocking=False):
        raise HTTPException(429, 'Сервис прогноза занят. Повторите запрос через несколько секунд.',
                            headers={'Retry-After': '10'})
    try:
        return predict(coords, category, days)
    except Exception:
        LOG.exception('Environmental risk estimation failed')
        raise HTTPException(502, 'Не удалось рассчитать риск. Попробуйте позже.') from None
    finally:
        PREDICTION_SLOTS.release()


LANGUAGES = ('en', 'ru', 'kk')
Language = Literal['en', 'ru', 'kk']


def result_assets(job_id, result, step=None):
    base = f'/api/analyses/{job_id}' + (f'/steps/{step}' if step is not None else '')
    for layer in result['layers']:
        layer['url'] = f"{base}/assets/{layer['file']}"
    assets = {'comparison': f'{base}/map.png',
              'reports': {lang: f'{base}/report.pdf?lang={lang}' for lang in LANGUAGES}}
    if result['water']['status']=='experimental':
        assets.update(water=f'{base}/assets/water.png',water_geojson=f'{base}/assets/water.geojson')
    return assets


def restore_jobs():
    """Reload bounded completed results after restart; never resume partial calculations."""
    paths=sorted(ROOT.glob('*/result.json'),key=lambda p:p.stat().st_mtime)[-32:]
    for path in paths:
        if len(path.parent.name)!=32 or any(c not in '0123456789abcdef' for c in path.parent.name):continue
        try:
            result=json.loads(path.read_text(encoding='utf-8'))
            if 'steps' in result:
                publish_series(path.parent.name, result)
                continue
            assets=result_assets(path.parent.name,result)
            if not all((path.parent/f'report-{lang}.pdf').is_file() for lang in ('ru','en')):continue
            JOBS[path.parent.name]={'id':path.parent.name,'status':'completed','result':result,'assets':assets}
        except (OSError,ValueError,KeyError,TypeError):continue


def run_pair(request, catalog, before, after, folder):
    if request.sensor == 'nisar':
        from .pipeline import run_analysis
        return run_analysis(catalog, before, after, request.bbox, os.environ.get('EARTHDATA_TOKEN', ''),
                            folder, request.theme, request.channel, request.side_km)
    from .exports import render_preview
    from .report import create_report
    if request.sensor == 'landsat':
        from .landsat import run_comparison
        result = run_comparison(catalog, before, after, request.bbox, folder, request.side_km, request.theme)
    else:
        from .modis import run_comparison
        result = run_comparison(catalog, before, after, request.bbox, folder, request.theme, request.side_km)
    for lang in LANGUAGES:
        render_preview(result, folder, folder/f'preview-{lang}.png', lang)
        create_report(result, folder, folder/f'report-{lang}.pdf', lang)
    (folder/'result.json').write_text(json.dumps(result), encoding='utf-8')
    return result


def publish_series(job_id, sequence):
    for i, step in enumerate(sequence['steps']):
        step['assets'] = result_assets(job_id, step['result'], i)
    JOBS.setdefault(job_id, {'id': job_id}).update(status='completed', sequence=sequence)


def calculate(request, catalog, folder, on_progress=lambda completed, total: None):
    if not request.scene_ids:
        return run_pair(request, catalog, request.before_id, request.after_id, folder)
    steps = []
    for i, (before, after) in enumerate(zip(request.scene_ids, request.scene_ids[1:])):
        on_progress(i, len(request.scene_ids)-1)
        pair_catalog = {'scenes': catalog['scenes'][i:i+2]}
        result = run_pair(request, pair_catalog, before, after, folder/'steps'/str(i))
        steps.append({'result': result})
    sequence = {'steps': steps}
    temporary = folder/'result.tmp'
    temporary.write_text(json.dumps(sequence), encoding='utf-8')
    temporary.replace(folder/'result.json')
    return sequence


def complete_job(job_id, result):
    if 'steps' in result:
        publish_series(job_id, result)
    else:
        assets = result_assets(job_id, result)
        JOBS[job_id].update(status='completed',result=result,assets=assets)
    JOBS[job_id].pop('progress', None)
    PENDING.pop(job_id, None)
    LEASES.pop(job_id, None)


def execute(job_id,request,catalog):
    def progress(completed, total):
        with GUARD:
            JOBS[job_id]['progress'] = {'completed': completed, 'total': total}

    try:
        with GUARD:
            job = JOBS.get(job_id)
            if not job or job['status'] != 'waiting':
                return
            job.update(status='processing', executor='render')
            PENDING.pop(job_id, None)
        result = calculate(request, catalog, ROOT/job_id, progress)
        with GUARD:
            complete_job(job_id, result)
    except ValueError as exc:
        from .landsat import CloudCoverageError

        with GUARD:
            job = JOBS[job_id]
            job.update(status='failed', error=str(exc))
            if isinstance(exc, CloudCoverageError):
                job['error_code'] = 'landsat_clouds'
    except Exception:
        with GUARD:JOBS[job_id].update(status='failed',error='Unable to read or process satellite data; check service access and retry')


def recover_expired_workers():
    """Requeue abandoned work while holding GUARD."""
    for job_id in [key for key, (_, expires) in LEASES.items() if expires <= monotonic()]:
        return_to_render(job_id)


def return_to_render(job_id):
    request, catalog = PENDING.pop(job_id)
    LEASES.pop(job_id, None)
    job = JOBS[job_id]
    job.pop('executor', None)
    job.pop('progress', None)
    job['status'] = 'waiting'
    POOL.submit(execute, job_id, request, catalog)


def authorize_worker(authorization):
    from hmac import compare_digest
    token = os.environ.get('SARWATCH_WORKER_TOKEN', '')
    if len(token) < 32 or not compare_digest((authorization or '').encode(), f'Bearer {token}'.encode()):
        raise HTTPException(401, 'Worker authorization required')


def check_lease(job_id, lease):
    active = LEASES.get(job_id)
    if not active or active[0] != lease or active[1] <= monotonic():
        raise HTTPException(409, 'Worker lease expired')


@app.post('/internal/worker/claim')
def claim_work(authorization: Annotated[str | None, Header()] = None):
    authorize_worker(authorization)
    with GUARD:
        recover_expired_workers()
        for job_id, (request, catalog) in PENDING.items():
            if JOBS[job_id]['status'] == 'waiting':
                lease = uuid4().hex
                LEASES[job_id] = (lease, monotonic() + LEASE_SECONDS)
                JOBS[job_id].update(status='processing', executor='external')
                if request.scene_ids:
                    JOBS[job_id]['progress'] = {'completed': 0, 'total': len(request.scene_ids)-1}
                return {'id': job_id, 'lease': lease, 'request': request.model_dump(mode='json'), 'catalog': catalog}
    return Response(status_code=204)


@app.post('/internal/worker/{job_id}/heartbeat', status_code=204)
def worker_heartbeat(job_id: str, lease: Annotated[str, Header(alias='X-Worker-Lease')], completed: int | None = None,
                     authorization: Annotated[str | None, Header()] = None):
    authorize_worker(authorization)
    with GUARD:
        check_lease(job_id, lease)
        LEASES[job_id] = (lease, monotonic() + LEASE_SECONDS)
        progress = JOBS[job_id].get('progress')
        if progress and completed is not None and progress['completed'] <= completed < progress['total']:
            JOBS[job_id]['progress'] = {**progress, 'completed': completed}


@app.post('/internal/worker/{job_id}/retry', status_code=204)
def worker_retry(job_id: str, lease: Annotated[str, Header(alias='X-Worker-Lease')],
                 authorization: Annotated[str | None, Header()] = None):
    authorize_worker(authorization)
    with GUARD:
        check_lease(job_id, lease)
        return_to_render(job_id)


@app.post('/internal/worker/{job_id}/result', status_code=204)
async def worker_result(job_id: str, request: Request, lease: Annotated[str, Header(alias='X-Worker-Lease')],
                        authorization: Annotated[str | None, Header()] = None):
    from starlette.concurrency import run_in_threadpool

    authorize_worker(authorization)
    with GUARD:
        check_lease(job_id, lease)
    with tempfile.TemporaryDirectory(dir=ROOT) as temporary:
        staging = Path(temporary)
        size = 0
        with (staging/'result.zip').open('wb') as archive:
            async for chunk in request.stream():
                size += len(chunk)
                if size > MAX_BUNDLE_BYTES:
                    raise HTTPException(413, 'Worker result exceeds upload limit')
                archive.write(chunk)
        try:
            result = await run_in_threadpool(install_bundle, staging/'result.zip', staging/'files')
        except (ValueError, OSError) as exc:
            raise HTTPException(422, 'Invalid worker result') from exc
        with GUARD:
            check_lease(job_id, lease)
            (staging/'files').rename(ROOT/job_id)
            complete_job(job_id, result)


@app.post('/api/analyses',status_code=202)
def create_analysis(request:AnalysisRequest):
    if request.sensor == 'nisar' and not os.environ.get('EARTHDATA_TOKEN'):
        raise HTTPException(503,'Satellite data access is not configured')
    lane = 'overview' if request.sensor == 'modis' else 'analysis'
    pool, workers = (OVERVIEW_POOL, OVERVIEW_WORKERS) if lane == 'overview' else (POOL, HEAVY_WORKERS)
    job_id = uuid4().hex
    old = None
    with GUARD:
        recover_expired_workers()
        selected = request.scene_ids or [request.before_id, request.after_id]
        if any(scene_id not in SCENES for scene_id in selected):
            raise HTTPException(409,'Refresh scene search before analysis')
        catalog={'scenes':[SCENES[scene_id] for scene_id in selected]}
        if any(scene.get('sensor', 'nisar') != request.sensor for scene in catalog['scenes']):
            raise HTTPException(422,'Choose two observations from the same source')
        if request.scene_ids:
            days = [scene['start'][:10] for scene in catalog['scenes']]
            if days != sorted(set(days)):
                raise HTTPException(422, 'Select observations in chronological order')
        active = [job for job in JOBS.values() if job.get('lane') == lane
                  and job['status'] in ('waiting', 'processing')]
        if len(active) >= workers + QUEUE_LIMIT:
            raise HTTPException(429, 'The analysis queue is full. Try again shortly.', headers={'Retry-After':'30'})
        JOBS[job_id] = {'id': job_id, 'status': 'waiting', 'lane': lane}
        if lane == 'analysis' and len(os.environ.get('SARWATCH_WORKER_TOKEN', '')) >= 32:
            PENDING[job_id] = (request, catalog)
        try:
            pool.submit(execute, job_id, request, catalog)
        except Exception:
            JOBS.pop(job_id)
            PENDING.pop(job_id, None)
            raise
        if len(JOBS) > 32:
            old = next((key for key, job in JOBS.items() if job['status'] in ('completed','failed')), None)
            if old:
                JOBS.pop(old)
    if old:
        shutil.rmtree(ROOT/old, ignore_errors=True)
    return {'id':job_id,'status':'waiting','status_url':f'/api/analyses/{job_id}'}


@app.get('/api/analyses/{job_id}')
def analysis(job_id:str):
    with GUARD:
        recover_expired_workers()
        if job_id not in JOBS:raise HTTPException(404,'Analysis not found or expired after server restart')
        current = dict(JOBS[job_id])
        if current['status'] == 'waiting':
            waiting = [key for key, job in JOBS.items() if job.get('lane') == current['lane']
                       and job['status'] == 'waiting']
            current['queue_position'] = waiting.index(job_id) + 1
        return current


def weather_context(result, lang, steps=(), image_paths=()):
    from .weather import atmosphere, configured_provider, explain_with_ai
    w, s, e, n = result['bbox']
    sources = [result['sources'][0], *(step['sources'][1] for step in steps)] if steps else result['sources'][:2]
    first, *middle, last = [date.fromisoformat(source['start'][:10]) for source in sources]
    event = result.get('event_context')
    event_day = date.fromisoformat(event['date']) if event and event.get('date') else None
    context = atmosphere(round((n+s)/2, 3), round((w+e)/2, 3), first, last, event_day, middle)
    theme = result.get('theme', 'water')
    sensor = result.get('sensor', 'nisar')
    water_fields = ('status', 'water_before_km2', 'water_after_km2', 'water_gain_km2', 'water_loss_km2', 'comparable_area_km2')
    radar_fields = ('median_delta_db', 'finite_overlap_fraction', 'comparable_pixels')
    metrics = [{
        'dates': [source['start'][:10] for source in step['sources']],
        'water': {key: value for key, value in (step.get('water') or step.get('metrics') or {}).items() if key in water_fields},
        'comparison': {key: value for key, value in (step.get('comparison') or step.get('metrics') or {}).items() if key in radar_fields},
    } for step in (steps or [result])]
    provider = configured_provider()
    explanation = explain_with_ai(context, theme, sensor, metrics, event, lang, image_paths)
    return {**context, 'event': event, 'ai_provider': provider,
            'ai_status': 'ready' if explanation else 'unavailable' if provider else 'not_configured',
            'ai_explanation': explanation}


@app.get('/api/cases/{case_id}/weather')
def case_weather(case_id: str, lang: Language = 'ru'):
    case = next((case for case in available_cases() if case['id'] == case_id), None)
    if not case or not case.get('bbox') or len(case.get('sources', [])) < 2:
        raise HTTPException(404, 'Case weather is unavailable')
    folder = CASE_ROOT/case['id']
    return weather_context(case, lang, image_paths=(folder/'before.png', folder/'after.png'))


@app.get('/api/analyses/{job_id}/weather')
def analysis_weather(job_id: str, lang: Language = 'ru'):
    job = analysis(job_id)
    if job['status'] != 'completed':
        raise HTTPException(409, 'Analysis is not complete')
    if 'sequence' in job:
        steps = [step['result'] for step in job['sequence']['steps']]
        before = ROOT/job_id/'steps'/'0'/'mapping'/'before.png'
        after = ROOT/job_id/'steps'/str(len(steps)-1)/'mapping'/'after.png'
        return weather_context(steps[0], lang, steps, (before, after))
    folder = ROOT/job_id/'mapping'
    return weather_context(job['result'], lang, image_paths=(folder/'before.png', folder/'after.png'))


def completed_dir(job_id, step=None):
    with GUARD:
        if job_id not in JOBS:raise HTTPException(404,'Analysis expired or not found')
        if JOBS[job_id]['status']!='completed':raise HTTPException(409,'Analysis is not complete')
        if step is not None:
            if not 0 <= step < len(JOBS[job_id].get('sequence', {}).get('steps', [])):
                raise HTTPException(404, 'Observation interval not found')
            return ROOT/job_id/'steps'/str(step)
    return ROOT/job_id


@app.get('/api/analyses/{job_id}/map.png')
@app.get('/api/analyses/{job_id}/steps/{step}/map.png')
def map_png(job_id:str,lang:Language='ru',step:int|None=None):
    folder=completed_dir(job_id, step);path=folder/f'preview-{lang}.png'
    if lang == 'kk' and not path.is_file():path=folder/'preview-en.png'
    if not path.is_file():path=folder/'comparison/comparison.png'
    if not path.is_file():raise HTTPException(404,'Image unavailable')
    return FileResponse(path,media_type='image/png',filename=f'sarwatch-{lang}.png')


@app.get('/api/analyses/{job_id}/report.pdf')
@app.get('/api/analyses/{job_id}/steps/{step}/report.pdf')
def report_pdf(job_id:str,lang:Language='ru',step:int|None=None):
    folder=completed_dir(job_id, step)
    path=folder/f'report-{lang}.pdf'
    if lang == 'kk' and not path.is_file():path=folder/'report-en.pdf'
    if not path.is_file():raise HTTPException(404,'Report unavailable')
    return FileResponse(path,media_type='application/pdf',filename=f'sarwatch-{lang}.pdf')


@app.get('/api/analyses/{job_id}/assets/{name}')
@app.get('/api/analyses/{job_id}/steps/{step}/assets/{name}')
def asset(job_id:str,name:str,step:int|None=None):
    if name not in ('before.png','after.png','delta.png','water.png','potential_flood.png','water.geojson','report-ru.pdf','report-en.pdf','report-kk.pdf'):raise HTTPException(404,'Unknown asset')
    folder=completed_dir(job_id, step)
    p=folder/name if name.endswith('.pdf') else folder/('water' if name.endswith('.geojson') else 'mapping')/name
    if not p.is_file():raise HTTPException(404,'Asset is unavailable for this analysis')
    media='application/pdf' if name.endswith('.pdf') else 'image/png' if name.endswith('.png') else 'application/geo+json'
    return FileResponse(p,media_type=media)


# One origin serves both the actual app and the API; opening an HTML file is not needed.
@app.get('/cases/index.json')
def public_case_index():return {'cases':available_cases()}


@app.get('/cases/{case_id}/{name}')
def public_case_asset(case_id:str,name:str):return case_asset(case_id,name)


@app.get('/assets/{name:path}')
def web_asset(name:str):
    root=(WEB_ROOT/'assets').resolve();path=(root/name).resolve()
    if not path.is_relative_to(root) or not path.is_file():raise HTTPException(404,'Web asset not found')
    return FileResponse(path)


@app.get('/favicon.png', include_in_schema=False)
def favicon():
    icon = WEB_ROOT/'favicon.png'
    if not icon.is_file():
        raise HTTPException(404, 'Icon not found')
    return FileResponse(icon, media_type='image/png')


@app.api_route('/',methods=['GET','HEAD'])
def frontend():
    path=WEB_ROOT/'index.html'
    if not path.is_file():raise HTTPException(503,'Frontend build missing; follow README installation steps')
    return FileResponse(path,media_type='text/html',headers={'Cache-Control':'no-cache'})
