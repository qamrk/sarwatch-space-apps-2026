"""Two-page reports from computed results; never include credentials or signed URLs."""
from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape

from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak

FONT = Path(__file__).parent / 'assets/fonts/NotoSans-Regular.ttf'
INK = colors.HexColor('#18313d')
TEAL = colors.HexColor('#087e77')
MUTED = colors.HexColor('#526872')


def create_report(result, folder, output, lang='ru', prepared=False):
    """Render a whitelist of derived metrics and public scene identities, in RU/EN."""
    if lang not in ('ru', 'en'):
        raise ValueError('Unsupported report language')
    folder, output = Path(folder), Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    if 'SARWatch' not in pdfmetrics.getRegisteredFontNames():
        pdfmetrics.registerFont(TTFont('SARWatch', str(FONT)))
    ru = lang == 'ru'
    tr = lambda a, b: a if ru else b
    styles = {
        'title': ParagraphStyle('title', fontName='SARWatch', fontSize=23, leading=29, textColor=INK, spaceAfter=12),
        'h': ParagraphStyle('h', fontName='SARWatch', fontSize=13, leading=18, textColor=TEAL, spaceBefore=12, spaceAfter=8),
        'body': ParagraphStyle('body', fontName='SARWatch', fontSize=9, leading=14, textColor=INK, spaceAfter=7),
        'small': ParagraphStyle('small', fontName='SARWatch', fontSize=7.5, leading=11, textColor=MUTED, spaceAfter=5, splitLongWords=True),
        'id': ParagraphStyle('id', fontName='SARWatch', fontSize=7, leading=10, textColor=MUTED, wordWrap='CJK', spaceAfter=5),
    }
    def p(value, style='body'):
        return Paragraph(escape(str(value)), styles[style])
    def table(rows, widths, header=True):
        t = Table([[p(v, 'small') for v in row] for row in rows], colWidths=widths, hAlign='LEFT')
        t.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#e8f3f0') if header else colors.white),
            ('LINEBELOW', (0, 0), (-1, -1), .4, colors.HexColor('#dce5e8')),
            ('LEFTPADDING', (0, 0), (-1, -1), 8), ('RIGHTPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 7), ('BOTTOMPADDING', (0, 0), (-1, -1), 7),
        ]))
        return t
    metrics = result.get('metrics') if prepared else result.get('water', {})
    metrics = metrics or {}
    water_available = all(k in metrics for k in ('water_before_km2','water_after_km2','water_gain_km2','water_loss_km2'))
    sources = result.get('sources', [])
    channel = metrics.get('channel') or next((o.get('channel') for o in result.get('observations', []) if o.get('channel')), '?')
    title = result.get('title', {}).get(lang) if prepared else tr('Сравнение наблюдений NISAR', 'NISAR observation comparison')
    checked = prepared and result.get('validation_status') == 'case_compared_with_optical_reference'
    status = tr('Пример сверён с Sentinel-2 SCL', 'Case compared with Sentinel-2 SCL') if checked else tr('Радарное сравнение, контекст примера проверен', 'Radar comparison with a reviewed case context') if prepared else tr('Предварительный результат без независимой сверки', 'Preliminary result without an independent reference check')
    story = [p('SARWatch / ' + tr('ОТЧЁТ НАБЛЮДЕНИЙ', 'OBSERVATION REPORT'), 'small'), p(title, 'title'), p(status)]
    story.append(p(tr('Экспериментальная оценка. Не является картой подтверждённого затопления.', 'Experimental estimate. Not a map of confirmed flooding.')))
    dates = [s.get('start', '?') for s in sources]
    story.append(p('NISAR GCOV · ' + channel + ' · ' + ' / '.join(dates), 'small'))
    # These are processed raster panels, without a third-party basemap.
    names = ['before.png', 'after.png', 'water.png' if water_available else 'delta.png']
    base = folder if prepared else folder/'mapping'
    labels = [tr('Первая дата', 'First date'), tr('Вторая дата', 'Second date'), tr('Водный класс', 'Water class') if water_available else tr('Разность dB', 'Difference in dB')]
    images = []
    for name in names:
        image_path = base/name
        with PILImage.open(image_path) as im:
            # Composite transparent NoData onto a consistent neutral background.
            rgba = im.convert('RGBA')
            bg = PILImage.new('RGBA', rgba.size, '#edf1f3')
            bg.alpha_composite(rgba)
            stream = BytesIO(); bg.convert('RGB').save(stream, format='PNG'); stream.seek(0)
            w, h = im.size
        scale = min(155/w, 220/h)
        images.append(Image(stream, width=w*scale, height=h*scale))
    panels = Table([[p(v, 'small') for v in labels], images], colWidths=[171]*3, hAlign='LEFT')
    panels.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('ALIGN',(0,0),(-1,-1),'CENTER'),('BOTTOMPADDING',(0,0),(-1,-1),10)]))
    story.extend([Spacer(1, 12), panels])
    if water_available:
        story.append(p(tr('Площадь водного класса в области, км²', 'Water class area in the selected area, km²'), 'h'))
        keys = ['water_before_km2', 'water_after_km2', 'water_gain_km2', 'water_loss_km2']
        labels = [tr('До', 'Before'), tr('После', 'After'), tr('Появление', 'Gain'), tr('Исчезновение', 'Loss')]
        story.append(table([labels, [f'{metrics[k]:.3f}' for k in keys]], [128.25]*4))
        story.append(p(tr('Синий: вода в обе даты; бирюзовый: появление; оранжевый: исчезновение. Серый фон: нет данных или нет водного класса.', 'Blue: water on both dates; turquoise: gain; orange: loss. Grey background: no data or no water class.'), 'small'))
    else:
        story.append(p(tr('Серые панели: обратное рассеяние в dB с общей шкалой. Разность: красный - рост, синий - снижение, белый - около нуля. Площадь пожара, ущерб и причины изменений не определяются.', 'Grey panels: backscatter in dB with a shared scale. Difference: red - increase, blue - decrease, white - near zero. Burned area, damage and causes of change are not inferred.')))
        reason = metrics.get('reason')
        if reason:
            story.append(p(tr('Вода не выделена: ', 'Water was not separated: ') + reason, 'small'))
    interpretation = result.get('interpretation', {}).get(lang) if prepared else None
    if interpretation:
        story.append(p(interpretation))
    flood=result.get('flood',{})
    if flood.get('status')=='experimental':
        story.append(p(f"{tr('Возможное затопление после вспомогательных фильтров','Potential inundation after auxiliary screening')}: {flood['candidate_area_km2']:.3f} km². "+tr('Предварительный кандидат, не подтверждённое событие.','Preliminary candidate, not a confirmed event.')))
    story.append(p(tr('Малые изменения границы могут отражать шум и смешанные пиксели. Тёмная суша, ветер, влажная почва и радиолокационная тень могут мешать выделению воды.', 'Small boundary changes may reflect noise and mixed pixels. Dark land, wind, wet soil and radar shadow can affect water separation.')))
    story.extend([PageBreak(), p(tr('Источники и метод', 'Sources and method'), 'title')])
    for i, s in enumerate(sources):
        story.append(p(tr('Первая дата', 'First date') if i == 0 else tr('Вторая дата', 'Second date'), 'h'))
        story.append(p(s.get('id', '?'), 'id'))
        story.append(p(f"UTC {s.get('start', '?')} · {s.get('maturity', '?')} · CRID {s.get('crid', '?')} · track {s.get('track', '?')} / frame {s.get('frame', '?')}", 'small'))
    bbox = result.get('bbox')
    if bbox:
        story.append(p('WGS84 west, south, east, north: ' + ', '.join(f'{v:.6f}' for v in bbox), 'small'))
    story.append(p(tr('Обработка', 'Processing'), 'h'))
    story.append(p(tr('Фрагменты GCOV читаются через HTTP Range. Невалидные пиксели маски качества исключены. Вторая дата совмещается с первой в линейной мощности, после чего вычисляется разность в dB.', 'GCOV windows are read through HTTP Range. Invalid quality-mask pixels are excluded. The second date is aligned with the first in linear power before computing the difference in dB.')))
    if water_available:
        story.append(p(tr('Вода: медиана 3 × 3 в линейной мощности, общий порог Otsu, проверка разделения классов и удаление компонент меньше 9 пикселей. Площадь считается на исходной метрической сетке, не по веб-карте.', 'Water: 3 × 3 median in linear power, pooled Otsu threshold, histogram separation gate and removal of components smaller than 9 pixels. Areas use the native metric grid, not the web map.')))
        story.append(p(f"{tr('Порог', 'Threshold')}: {metrics.get('threshold_db', 0):.2f} dB · {tr('Площадь пикселя', 'Pixel area')}: {metrics.get('pixel_area_m2', '?')} m²", 'small'))
    if checked:
        story.append(p(tr('Независимая оптическая сверка', 'Independent optical comparison'), 'h'))
        rows = [[tr('Эпоха', 'Epoch'), 'Sentinel-2 SCL / UTC', 'IoU', tr('Ясная доля', 'Clear fraction')]]
        for epoch, c in result['reference_checks'].items():
            rows.append([tr('До', 'Before') if epoch == 'before' else tr('После', 'After'), f"{c['reference_id']} / {c['reference_time'][:10]}", f"{c['iou_vs_reference']:.4f}", f"{c['clear_reference_fraction']:.1%}"])
        story.append(table(rows, [50, 285, 65, 113]))
        story.append(p(tr('SCL: ясные классы 4, 5, 6; вода - класс 6. Автоматическая оптическая классификация не является полевой истиной. Согласие относится к этому примеру и не устанавливает общую точность.', 'SCL: clear classes 4, 5, 6; water - class 6. Automatic optical classification is not field ground truth. Agreement applies to this case and does not establish general accuracy.'), 'small'))
    else:
        story.append(p(tr('Независимая сверка этого расчёта не выполнена. Статистики согласия подготовленного примера к нему не относятся.', 'This analysis has not been independently checked. Agreement statistics from the prepared case do not apply.'), 'small'))
    story.append(p(tr('Ограничения и атрибуция', 'Limitations and attribution'), 'h'))
    if flood.get('status')=='experimental':
        story.append(p(tr('Слой возможного затопления: исключены вода первой даты и историческая вода JRC v1.5 с встречаемостью от 90%, с буфером 60 м. По Copernicus DEM GLO-30 исключены уклоны более 5°. Эти эвристики не являются гидрологической моделью или подтверждением события.', 'Potential inundation layer: excludes first-date water and JRC v1.5 historical water occurrence of at least 90%, with a 60 m buffer. Copernicus DEM GLO-30 excludes slopes above 5°. These heuristics are not a hydraulic model or event confirmation.')))
        story.append(p('Source: EC JRC/Google; Copernicus DEM / ESA / Sinergise.', 'small'))
    else:
        story.append(p(tr('Маска качества не исключает все радиолокационные тени. Фильтры постоянной воды и рельефа для этого результата не применены. Появление водного класса не означает наводнение.', 'The quality mask does not exclude all radar shadows. Permanent-water and terrain filters are not applied to this result. Water-class gain does not establish a flood.')))
    context=result.get('context',{})
    if context.get('id'):story.append(p('Sentinel-2 RGB: '+context['id']+' / '+context['time'][:10], 'small'))
    for source in result.get('event_sources',[]):story.append(p(source.get('title','')+' '+source.get('url',''), 'id'))
    story.append(p('NASA/JPL/ASF NISAR ' + ', '.join(sorted({s.get('maturity', '?') for s in sources})), 'small'))
    if checked:
        story.append(p('Contains modified Copernicus Sentinel-2 data (2026), accessed via Element 84 Earth Search.', 'small'))
    story.append(p('GCOV: https://nisar-docs.asf.alaska.edu/gcov/', 'small'))
    def footer(canvas, doc):
        canvas.setFont('SARWatch', 8); canvas.setFillColor(MUTED)
        canvas.drawString(41, 25, 'SARWatch · ' + tr('Исследовательский прототип', 'Research prototype'))
        canvas.drawRightString(A4[0]-41, 25, str(doc.page))
    SimpleDocTemplate(str(output), pagesize=A4, rightMargin=41, leftMargin=41, topMargin=35, bottomMargin=43,
                      title='SARWatch / '+str(title), author='SARWatch').build(story, onFirstPage=footer, onLaterPages=footer)
    return output
