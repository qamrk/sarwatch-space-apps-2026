"""Geospatial intensity comparison; no causal or flood classification."""
from pathlib import Path
import json
import numpy as np
import rasterio
from rasterio.warp import reproject, Resampling
from PIL import Image, ImageDraw, ImageOps


def compare(before_path, after_path, output_dir):
    output_dir=Path(output_dir); output_dir.mkdir(parents=True,exist_ok=True)
    with rasterio.open(before_path) as before, rasterio.open(after_path) as after:
        if before.crs is None or after.crs is None:
            raise ValueError('Both rasters need a CRS')
        if before.tags().get('channel')!=after.tags().get('channel'):
            raise ValueError('Cannot compare different polarization channels')
        a=before.read(1,masked=True).filled(np.nan).astype('float32')
        b=after.read(1,masked=True).filled(np.nan).astype('float32')
        # Interpolate linear power, not logarithmic intensity.
        aligned=np.full(a.shape,np.nan,dtype='float32')
        reproject(np.power(10,b/10),aligned,src_transform=after.transform,src_crs=after.crs,
                  dst_transform=before.transform,dst_crs=before.crs,src_nodata=np.nan,
                  dst_nodata=np.nan,resampling=Resampling.bilinear,num_threads=1,warp_mem_limit=16)
        valid=np.isfinite(a)&np.isfinite(aligned)&(aligned>0)
        if not valid.any(): raise ValueError('No shared finite pixels')
        aligned_db=np.full(a.shape,np.nan,dtype='float32')
        aligned_db[valid]=10*np.log10(aligned[valid])
        delta=np.where(valid,aligned_db-a,np.nan).astype('float32')
        profile=before.profile.copy(); profile.update(dtype='float32',nodata=np.nan,count=1,compress='deflate')
        with rasterio.open(output_dir/'delta_db.tif','w',**profile) as dst: dst.write(delta,1)
        stats=dict(status='intensity_comparison_not_validated',comparable_pixels=int(valid.sum()),
                   finite_overlap_fraction=float(valid.mean()),median_delta_db=float(np.median(delta[valid])),
                   mean_delta_db=float(np.mean(delta[valid])),p95_absolute_delta_db=float(np.percentile(np.abs(delta[valid]),95)),
                   quality_mask_applied=all(s.tags().get('quality_mask_applied')=='true' for s in (before,after)),water_classification=False,
                   warning='Differences in radar intensity do not establish flooding, fire or damage.')
        values=np.concatenate([a[valid],aligned_db[valid]])
        lo,hi=np.percentile(values,[2,98]); hi=max(hi,lo+1)
        panels=[]
        for array in (a,aligned_db):
            grey=(np.nan_to_num(np.clip((array-lo)/(hi-lo),0,1),nan=0)*255).astype('uint8')
            panels.append(Image.fromarray(grey).convert('RGB'))
        scale=max(float(np.percentile(np.abs(delta[valid]),98)),1.)
        signed=np.nan_to_num(np.clip(delta/scale,-1,1),nan=0)
        rgb=np.ones((*a.shape,3),dtype='float32')
        rgb[:,:,0]-=np.maximum(-signed,0); rgb[:,:,1]-=np.abs(signed); rgb[:,:,2]-=np.maximum(signed,0)
        rgb[~valid]=0
        panels.append(Image.fromarray((rgb*255).astype('uint8')))
        canvas=Image.new('RGB',(1500,690),'#0c1721'); draw=ImageDraw.Draw(canvas)
        draw.text((28,20),'SARWATCH / NISAR REAL-DATA PREFLIGHT',fill='white',font_size=25)
        for i,(label,panel) in enumerate(zip(('BEFORE / gamma-0 dB','AFTER / same display scale','DELTA / red increase, blue decrease'),panels)):
            draw.text((28+492*i,78),label,fill='white',font_size=18)
            panel=ImageOps.contain(panel,(460,498),method=Image.Resampling.NEAREST)
            canvas.paste(panel,(28+492*i+(460-panel.width)//2,112+(498-panel.height)//2))
        draw.text((28,628),f'Intensity range: {lo:.1f} .. {hi:.1f} dB | Delta range: +/-{scale:.1f} dB',fill='white',font_size=17)
        draw.text((28,656),'Unvalidated radar intensity. This is not a flood, water or burned-area map.',fill='#f0bf74',font_size=17)
        canvas.save(output_dir/'comparison.png')
        (output_dir/'comparison.json').write_text(json.dumps(stats,indent=2)+'\n')
        return stats
