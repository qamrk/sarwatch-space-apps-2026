"""Bounded scientific processing; browser images never determine areas."""
MAX_SIDE_KM = 75
AREA_SIZES_KM = (10, 30, 50, 75)
MAX_NETWORK_BYTES = 600_000_000
MAX_OUTPUT_SIDE = 640
# Large native windows are reduced tile by tile in linear power.
MAX_WINDOW_PIXELS = 600_000
MAX_AUXILIARY_PIXELS = 1_600_000
