"""Shared processing limits for the 10 km analysis window."""
MAX_SIDE_KM = 10
# Allow padding/rotation around a 10 km GCOV window without unbounded allocations.
MAX_WINDOW_PIXELS = 600_000
MAX_AUXILIARY_PIXELS = 1_600_000
