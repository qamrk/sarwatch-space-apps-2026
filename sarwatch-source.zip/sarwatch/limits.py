"""Bounded scientific processing; browser images never determine areas."""
MAX_SIDE_KM = 100
AREA_SIZES_KM = (10, 30, 50, 75, 100)
LANDSAT_START = '1982-08-22'
NISAR_START = '2025-10-01'  # earliest published GCOV observations
NISAR_SEARCH_DAYS = (24, 48)
MAX_NETWORK_BYTES = 600_000_000
MAX_OUTPUT_SIDE = 640
# Large native windows are reduced tile by tile in linear power.
MAX_WINDOW_PIXELS = 600_000
MAX_AUXILIARY_PIXELS = 1_600_000


def automatic_sensor(sensor, first_date):
    if sensor == 'auto' and first_date.isoformat() >= NISAR_START:
        return 'nisar'
    return sensor
