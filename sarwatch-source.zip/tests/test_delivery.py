"""Delivery contracts use isolated temporary files and never contact satellite services."""
from contextlib import nullcontext
from io import BytesIO
import json
from pathlib import Path

from fastapi.testclient import TestClient
from PIL import Image
import pytest

from sarwatch import api, serve


@pytest.fixture
def delivery_env(tmp_path, monkeypatch):
    root = tmp_path/'jobs'
    web = tmp_path/'web'
    cases = tmp_path/'cases'
    (web/'assets').mkdir(parents=True)
    root.mkdir()
    cases.mkdir()
    (web/'index.html').write_text('<!doctype html><html><body>SARWatch delivery fixture<script src="/assets/app.js"></script></body></html>')
    (web/'assets/app.js').write_text('/* explicit delivery test fixture */')
    (tmp_path/'.env').write_text('EARTHDATA_TOKEN=delivery-test-secret')
    monkeypatch.setattr(api, 'ROOT', root)
    monkeypatch.setattr(api, 'WEB_ROOT', web)
    monkeypatch.setattr(api, 'CASE_ROOT', cases)
    # StaticFiles captures its directory at construction; isolate that state too.
    for route in api.app.routes:
        static = getattr(route, 'app', None)
        if getattr(route, 'name', None) == 'web-assets' and hasattr(static, 'directory'):
            monkeypatch.setattr(static, 'directory', str(web/'assets'))
            monkeypatch.setattr(static, 'all_directories', [str(web/'assets')])
            monkeypatch.setattr(static, 'config_checked', False)
    api.SCENES.clear()
    api.JOBS.clear()
    yield {'root': root, 'web': web, 'cases': cases}
    api.SCENES.clear()
    api.JOBS.clear()


def seed_case(folder):
    case = folder/'delivery-fixture'
    case.mkdir()
    for filename in ('before.png', 'preview-ru.png', 'preview-en.png'):
        Image.new('RGB', (2, 2), 'white').save(case/filename)
    manifest = {
        'id': case.name, 'ready_for_demo': True,
        'previews': {'ru': 'preview-ru.png', 'en': 'preview-en.png'},
        'layers': [{'id': 'before', 'file': 'before.png', 'bounds': [70, 53, 70.01, 53.01]}],
    }
    (case/'manifest.json').write_text(json.dumps(manifest))
    return case


def seed_result(root, job_id='a'*32, reports=True):
    folder = root/job_id
    folder.mkdir()
    (folder/'result.json').write_text(json.dumps({
        'layers': [{'id': 'before', 'file': 'before.png', 'bounds': [70, 53, 70.01, 53.01]}],
        'water': {'status': 'not_requested'},
    }))
    if reports:
        # These bytes only test transport and language selection, not PDF rendering.
        for lang in ('ru', 'en'):
            (folder/f'report-{lang}.pdf').write_bytes(b'%PDF-1.4\n'+lang.encode())
    return folder


def test_built_frontend_and_assets_share_api_origin(delivery_env):
    with TestClient(api.app) as client:
        home = client.get('/')
        assert home.status_code == 200
        assert 'text/html' in home.headers['content-type']
        assert '/assets/app.js' in home.text
        assert 'no-cache' in home.headers.get('cache-control', '')
        script = client.get('/assets/app.js')
        assert script.status_code == 200
        assert script.text == '/* explicit delivery test fixture */'
        assert client.get('/api/health').json()['application'] == 'sarwatch'


def test_public_case_index_and_assets_work_without_separate_static_server(delivery_env):
    seed_case(delivery_env['cases'])
    with TestClient(api.app) as client:
        case = client.get('/cases/index.json').json()['cases'][0]
        assert case['id'] == 'delivery-fixture'
        source = client.get(case['layers'][0]['url'])
        public_alias = client.get('/cases/delivery-fixture/before.png')
        assert source.status_code == public_alias.status_code == 200
        assert public_alias.content == source.content
        assert public_alias.content.startswith(b'\x89PNG')
        assert client.get(case['preview_urls']['ru']).status_code == 200


def test_completed_job_is_restored_after_in_memory_state_is_lost(delivery_env):
    folder = seed_result(delivery_env['root'])
    (folder/'mapping').mkdir()
    Image.new('RGB', (2, 2), 'white').save(folder/'mapping/before.png')
    with TestClient(api.app) as client:
        result = client.get('/api/analyses/'+'a'*32)
        assert result.status_code == 200
        body = result.json()
        assert body['status'] == 'completed'
        assert client.get(body['result']['layers'][0]['url']).status_code == 200
        for lang in ('ru', 'en'):
            response = client.get(body['assets']['reports'][lang])
            assert response.status_code == 200
            assert response.headers['content-type'] == 'application/pdf'
            assert response.content.endswith(lang.encode())


def test_partial_job_is_not_restored_as_completed(delivery_env):
    seed_result(delivery_env['root'], reports=False)
    with TestClient(api.app) as client:
        assert client.get('/api/analyses/'+'a'*32).status_code == 404


def test_localized_png_falls_back_to_existing_comparison(delivery_env):
    folder = seed_result(delivery_env['root'])
    (folder/'comparison').mkdir()
    Image.new('RGB', (3, 2), 'navy').save(folder/'comparison/comparison.png')
    with TestClient(api.app) as client:
        response = client.get('/api/analyses/'+'a'*32+'/map.png?lang=en')
        assert response.status_code == 200
        assert response.content == (folder/'comparison/comparison.png').read_bytes()


def test_missing_png_is_a_clear_not_found_response(delivery_env):
    seed_result(delivery_env['root'])
    with TestClient(api.app, raise_server_exceptions=False) as client:
        assert client.get('/api/analyses/'+'a'*32+'/map.png').status_code == 404


def test_report_alias_selects_language_and_rejects_invalid_language(delivery_env):
    seed_result(delivery_env['root'])
    with TestClient(api.app) as client:
        for lang in ('ru', 'en'):
            response = client.get('/api/analyses/'+'a'*32+f'/report.pdf?lang={lang}')
            assert response.status_code == 200
            assert response.content.endswith(lang.encode())
        for route in ('report.pdf', 'map.png'):
            assert client.get('/api/analyses/'+'a'*32+f'/{route}?lang=de').status_code == 422


def test_missing_frontend_or_asset_directory_does_not_crash(delivery_env):
    (delivery_env['web']/'index.html').unlink()
    (delivery_env['web']/'assets/app.js').unlink()
    (delivery_env['web']/'assets').rmdir()
    with TestClient(api.app, raise_server_exceptions=False) as client:
        assert client.get('/').status_code == 503
        assert client.get('/assets/app.js').status_code in (404, 503)


def test_private_files_and_path_traversal_are_not_served(delivery_env):
    seed_case(delivery_env['cases'])
    folder = seed_result(delivery_env['root'])
    (folder/'private.txt').write_text('delivery-test-secret')
    with TestClient(api.app) as client:
        for path in (
            '/.env', '/sarwatch/api.py', '/README.md',
            '/assets/%2e%2e/.env', '/assets/%2e%2e/%2e%2e/.env',
            '/cases/delivery-fixture/.env',
            '/api/cases/delivery-fixture/assets/manifest.json',
            '/data/jobs/'+'a'*32+'/result.json',
            '/api/analyses/'+'a'*32+'/assets/private.txt',
        ):
            response = client.get(path)
            assert response.status_code == 404, path
            assert 'delivery-test-secret' not in response.text


def test_render_head_probe_receives_success_and_no_body(delivery_env):
    with TestClient(api.app) as client:
        response=client.head('/')
        assert response.status_code==200 and response.content==b''


def test_launcher_reuses_existing_sarwatch_without_starting_another_server(monkeypatch, capsys):
    monkeypatch.setenv('SARWATCH_NO_BROWSER', '1')
    monkeypatch.setattr(serve.socket, 'create_connection', lambda *a, **k: nullcontext())
    monkeypatch.setattr(serve, 'urlopen', lambda *a, **k: BytesIO(b'{"application":"sarwatch"}'))
    monkeypatch.setattr(serve.uvicorn, 'run', lambda *a, **k: pytest.fail('A duplicate server was started'))
    serve.main()
    assert 'already running' in capsys.readouterr().out


def test_launcher_does_not_treat_another_service_as_sarwatch(monkeypatch):
    monkeypatch.setenv('SARWATCH_NO_BROWSER', '1')
    monkeypatch.setattr(serve.socket, 'create_connection', lambda *a, **k: nullcontext())
    monkeypatch.setattr(serve, 'urlopen', lambda *a, **k: BytesIO(b'{"application":"another-service"}'))
    monkeypatch.setattr(serve.uvicorn, 'run', lambda *a, **k: pytest.fail('An occupied port was taken over'))
    with pytest.raises(RuntimeError, match='occupied'):
        serve.main()
