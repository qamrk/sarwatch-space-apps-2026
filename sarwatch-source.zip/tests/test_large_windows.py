"""Bounded scientific aggregation and display/science separation contracts."""
import numpy as np
import pytest
from pyproj import Transformer,CRS
from sarwatch.gcov import reduce_window
from sarwatch.browse import preview_png
from sarwatch import api


def test_reduction_averages_power_not_decibels_and_keeps_metric_grid():
    power=np.tile(np.array([1,1,100],dtype='float32'),(24,8))
    mask=np.ones(power.shape,dtype='uint8')
    x=500000+np.arange(24)*20.;y=5100000-np.arange(24)*20.
    bbox=Transformer.from_crs(32643,4326,always_xy=True).transform_bounds(499990,5099530,500470,5100010)
    data,factor,hist,fraction=reduce_window(power,mask,np.arange(24),np.arange(24),x,y,20,-20,CRS(32643),bbox,max_side=8)
    assert factor==3 and data.shape==(8,8)
    np.testing.assert_allclose(data,10*np.log10(34),rtol=1e-6)
    assert hist=={'1':576} and fraction==1
    assert np.count_nonzero(np.isfinite(data))*(20*factor)**2==24*24*20**2


def test_reduction_never_requests_full_native_aoi_and_excludes_invalid_blocks():
    class Lazy:
        largest=0
        def __init__(self,is_mask=False):self.is_mask=is_mask
        def __getitem__(self,key):
            rs,cs=key;h,w=rs.stop-rs.start,cs.stop-cs.start
            self.largest=max(self.largest,h*w)
            return np.full((h,w),255 if self.is_mask else 10,dtype='uint8' if self.is_mask else 'float32')
    power,mask=Lazy(),Lazy(True);n=4000
    x=500000+np.arange(n)*20.;y=5100000-np.arange(n)*20.
    bbox=Transformer.from_crs(32643,4326,always_xy=True).transform_bounds(499990,5020010,579990,5100010)
    data,factor,_,fraction=reduce_window(power,mask,np.arange(n),np.arange(n),x,y,20,-20,CRS(32643),bbox)
    assert max(data.shape)<=640 and factor==7
    assert power.largest<=512**2 and mask.largest<=512**2
    assert np.isnan(data).all() and fraction==0


@pytest.mark.parametrize('url',['https://example.com/BROWSE/test.png','https://nisar.asf.earthdatacloud.nasa.gov/NISAR/private.h5','http://nisar.asf.earthdatacloud.nasa.gov/BROWSE/test.png'])
def test_browse_rejects_nonpublic_or_nonofficial_assets_before_network(url):
    with pytest.raises(ValueError):preview_png(url)


def test_browse_public_cdn_is_bounded_and_resized_without_credentials(monkeypatch):
    from io import BytesIO
    from PIL import Image
    image=BytesIO();Image.new('RGB',(2000,1800),'white').save(image,format='PNG')
    class Response:
        def __init__(self,status,location=None):self.status_code=status;self.headers={'Location':location} if location else {}
        def __enter__(self):return self
        def __exit__(self,*args):pass
        def raise_for_status(self):pass
        def iter_content(self,size):yield image.getvalue()
    calls=[]
    def get(url,**kwargs):
        calls.append((url,kwargs))
        assert 'headers' not in kwargs and 'auth' not in kwargs and kwargs['allow_redirects'] is False
        return Response(303,'https://d1mv8zhcvry6x4.cloudfront.net/public.png?signature=test') if len(calls)==1 else Response(200)
    monkeypatch.setattr('sarwatch.browse.requests.get',get)
    output=preview_png('https://nisar.asf.earthdatacloud.nasa.gov/BROWSE/test.png')
    with Image.open(BytesIO(output)) as result:assert result.size==(1024,922)
    assert len(calls)==2


def test_supported_area_sizes_and_beta_search(tmp_path,monkeypatch):
    from fastapi.testclient import TestClient
    monkeypatch.setattr(api,'ROOT',tmp_path/'jobs')
    with TestClient(api.app) as c:
        assert c.get('/api/health').json()['area_sizes_km']==[10,30,50,75,100]
        assert c.get('/api/scenes/untrusted/browse.png').status_code==404
        for side in (30,50,75,100):
            import math
            dy=side*1000/112000/2;dx=dy/math.cos(math.radians(46-dy))
            r=c.post('/api/analyses',json={'bbox':[74-dx,46-dy,74+dx,46+dy],'side_km':side,'before_id':'controlled-before-scene-01','after_id':'controlled-after-scene-002'})
            assert r.status_code in (409,503)
        r=c.post('/api/analyses',json={'bbox':[74,46,74.01,46.01],'side_km':75,'before_id':'controlled-before-scene-01','after_id':'controlled-after-scene-002'})
        assert r.status_code==422
