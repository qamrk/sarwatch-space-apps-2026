"""Risk checks use controlled inputs and verify that missing data never means low risk."""
from datetime import datetime, timezone

import numpy as np
import pytest
from fastapi.testclient import TestClient
from PIL import Image

from sarwatch import api, prediction
from sarwatch.prediction_data import _decode_loss, _urls


AREA = (60.85, 46.41, 61.20, 46.66)
NOW = datetime(2026, 11, 15, 5, 31, tzinfo=timezone.utc)


def weather(days, rain=0, prior=0, temperature=38, humidity=23, gust=60):
    return {
        'rain': np.full(days * 24, rain), 'past_rain': np.full(7 * 24, prior),
        'temperature_2m': np.full(days * 24, temperature),
        'relative_humidity_2m': np.full(days * 24, humidity),
        'wind_gusts_10m': np.full(days * 24, gust),
    }


def install_inputs(monkeypatch, *, cover=10, rain=0, dry=True, complete=True, loss=False):
    def inputs(category, target, bbox, now, days):
        shape = target.shape
        terrain = np.full(shape, 240, dtype=float)
        history = np.zeros(shape)
        if loss:
            history[:, 50:58] = 24
        water = np.zeros(shape)
        water[:, :19] = 70
        land = np.full(shape, cover, dtype=float)
        if not complete:
            terrain.fill(np.nan)
        met = weather(days, rain, prior=0 if dry else 3)
        return {'land': land, 'terrain': terrain, 'water': water, 'loss': history}, [met] * 4, None, np.zeros(shape, bool), []
    monkeypatch.setattr(prediction, '_inputs', inputs)


def test_flood_responds_to_rain_and_varies_with_proximity(monkeypatch):
    install_inputs(monkeypatch, rain=0)
    calm = prediction.predict(AREA, 'water', 1, NOW)
    assert calm['counts']['low'] == 36
    install_inputs(monkeypatch, rain=14)
    wet = prediction.predict(AREA, 'water', 3, NOW)
    assert wet['counts']['high'] > 0
    assert wet['zones'][0]['index'] > wet['zones'][5]['index']
    assert wet['updated_at'] == NOW.isoformat()
    assert wet['start'] == '2026-11-15T05:00:00+00:00'
    assert wet['end'] == '2026-11-18T05:00:00+00:00'
    assert wet['zones'][0]['bbox'][:1] == [AREA[0]]
    assert wet['zones'][-1]['bbox'][2] == pytest.approx(AREA[2])


@pytest.mark.parametrize(('category', 'cover'), [('fire', 10), ('agri_fire', 40)])
def test_fire_weather_uses_the_right_fuel_and_wet_conditions_lower_the_risk(monkeypatch, category, cover):
    install_inputs(monkeypatch, cover=cover)
    dry = prediction.predict(AREA, category, 1, NOW)
    assert dry['counts']['high'] == 36
    install_inputs(monkeypatch, cover=cover, rain=12, dry=False)
    wet = prediction.predict(AREA, category, 1, NOW)
    assert wet['counts']['low'] == 36
    install_inputs(monkeypatch, cover=50)
    built = prediction.predict(AREA, category, 1, NOW)
    assert built['counts']['not_applicable'] == 36


def test_recent_forest_loss_and_length_of_horizon_increase_index(monkeypatch):
    install_inputs(monkeypatch, loss=True)
    short = prediction.predict(AREA, 'forest', 90, NOW)
    yearly = prediction.predict(AREA, 'forest', 365, NOW)
    assert yearly['zones'][4]['index'] > short['zones'][4]['index'] > 0
    assert yearly['zones'][4]['index'] > yearly['zones'][0]['index']
    assert any('покрова' in factor['label'] for factor in yearly['zones'][4]['factors'])


def test_missing_terrain_does_not_receive_a_flood_rating(monkeypatch):
    install_inputs(monkeypatch, complete=False)
    result = prediction.predict(AREA, 'water', 1, NOW)
    assert result['status'] == 'unavailable'
    assert result['counts']['unavailable'] == 36
    assert all(zone['index'] is None for zone in result['zones'])


def test_public_endpoint_validates_area_and_period_before_fetching(monkeypatch):
    calls = []
    monkeypatch.setattr(prediction, 'predict', lambda coords, category, days: calls.append((coords, category, days)) or {'status': 'available'})
    client = TestClient(api.app)
    bbox = ','.join(map(str, AREA))
    assert client.get('/api/predictions', params={'bbox': bbox, 'category': 'forest', 'days': 3}).status_code == 422
    assert client.get('/api/predictions', params={'bbox': '60,46,62,48', 'category': 'water', 'days': 1}).status_code == 422
    assert client.get('/api/predictions', params={'bbox': 'nan,46,61,47', 'category': 'water', 'days': 1}).status_code == 422
    assert client.get('/api/predictions', params={'bbox': bbox, 'category': 'forest', 'days': 90}).json() == {'status':'available'}
    assert calls == [(AREA, 'forest', 90)]


def test_surface_water_tiles_mosaic_across_equator_and_prime_meridian():
    urls = [url.rsplit('/', 1)[1] for url in _urls('water', (-.1, -.1, .1, .1))]
    assert urls == ['occurrence_10W_0N_v1_5_2024.tif', 'occurrence_0E_0N_v1_5_2024.tif',
                    'occurrence_10W_10N_v1_5_2024.tif', 'occurrence_0E_10N_v1_5_2024.tif']


def test_gfw_tile_reads_loss_year_from_blue_and_ignores_nonloss():
    rgba = np.array([[[255, 0, 25, 255], [80, 0, 22, 0], [220, 0, 0, 255], [200, 0, 20, 255]]], dtype=np.uint8)
    assert _decode_loss(Image.fromarray(rgba)).tolist() == [[25, 0, 0, 20]]
