import numpy as np
import pytest
from sarwatch.water import classify_pair,otsu_threshold,filtered_power_db


def test_water_areas_and_gain_on_known_metric_grid():
    a=np.full((80,80),-5.,dtype='float32');a[:,:30]=-25
    b=np.full((80,80),-5.,dtype='float32');b[:,:40]=-25
    classes,stats=classify_pair(a,b,400)
    assert np.isclose(stats['water_before_km2'],.96)
    assert np.isclose(stats['water_after_km2'],1.28)
    assert np.isclose(stats['water_gain_km2'],.32)
    assert stats['water_loss_km2']==0
    assert np.count_nonzero(classes==2)==800
    assert stats['potential_flood_available'] is False


def test_unchanged_water_does_not_create_gain():
    a=np.full((60,60),-5.,dtype='float32');a[:,:20]=-25
    a[0,0]=np.nan
    classes,stats=classify_pair(a,a,400)
    assert classes[0,0]==255
    assert stats['water_gain_km2']==stats['water_loss_km2']==0


def test_unimodal_dark_land_is_rejected():
    a=np.random.default_rng(9).normal(-18,1,10000)
    with pytest.raises(ValueError,match='reliably'): otsu_threshold(a)


def test_missing_pixels_are_not_filled():
    a=np.full((20,20),-20.,dtype='float32'); a[7:10,7:10]=np.nan
    b=filtered_power_db(a)
    assert np.isnan(b[7:10,7:10]).all()
