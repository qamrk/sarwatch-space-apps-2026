"""API checks use explicit fixtures; they never simulate real observations in the app."""
import pytest
from fastapi.testclient import TestClient
from sarwatch import api


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(api,'ROOT',tmp_path/'jobs')
    monkeypatch.setattr(api,'CASE_ROOT',tmp_path/'cases')
    api.SCENES.clear();api.JOBS.clear()
    with TestClient(api.app) as c:yield c


def test_health_never_exposes_secret(client,monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    r=client.get('/api/health')
    assert r.status_code==200
    assert r.json()['data_access_configured'] is True
    assert 'unit-test-secret' not in r.text


def test_missing_access_is_explicit(client,monkeypatch):
    monkeypatch.delenv('EARTHDATA_TOKEN',raising=False)
    r=client.post('/api/analyses',json={'bbox':[74,46,74.01,46.01],
                  'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'})
    assert r.status_code==503


def test_large_aoi_rejected_before_network(client):
    r=client.post('/api/analyses',json={'bbox':[74,46,75,47.1],
                  'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'})
    assert r.status_code==422


def test_unknown_scene_cannot_supply_a_download_url(client,monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    r=client.post('/api/analyses',json={'bbox':[74,46,74.01,46.01],
                  'before_id':'https://example.com/before.h5','after_id':'https://example.com/after.h5'})
    assert r.status_code==409


def test_busy_worker_returns_retry_after(client,monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    a='fixture-scene-before-0001';b='fixture-scene-after-00002'
    api.SCENES.update({a:{'id':a},b:{'id':b}})
    api.BUSY.acquire()
    try:
        r=client.post('/api/analyses',json={'bbox':[74,46,74.01,46.01],'before_id':a,'after_id':b})
        assert r.status_code==429 and r.headers['Retry-After']=='10'
    finally:api.BUSY.release()


def test_internal_files_are_not_downloadable(client):
    assert client.get('/api/analyses/unknown/assets/.env').status_code==404
    assert client.get('/api/analyses/unknown').status_code==404



def test_empty_prepared_cases_keep_the_endpoint(client):
    assert client.get('/api/cases').json()=={'cases':[]}
    assert client.get('/cases/index.json').json()=={'cases':[]}
    for case in ('burabay-july-2026','burabay-forest-2026','maikol-fields-2026'):
        assert client.get(f'/cases/{case}/before.png').status_code==404
        assert client.get(f'/api/cases/{case}/assets/report-ru.pdf').status_code==404


def test_hundred_km_limit_is_advertised_and_larger_windows_rejected(client,monkeypatch):
    assert client.get('/api/health').json()['max_side_km']==100
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    request={'bbox':[75,46,75.12,46.08],'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'}
    assert client.post('/api/analyses',json=request).status_code==409
    request['bbox']=[75,46,77,47]
    assert client.post('/api/analyses',json=request).status_code==422


def test_scene_search_accepts_area_larger_than_five_km_without_network(client,monkeypatch):
    calls=[]
    def search(*args):
        calls.append(args);return {'scenes':[],'pairs':[]}
    monkeypatch.setattr('sarwatch.catalog.search',search)
    response=client.get('/api/scenes',params={'bbox':'75,46,75.12,46.08','start':'2026-07-01','end':'2026-07-31'})
    assert response.status_code==200 and len(calls)==1


def test_auto_routes_a_long_comparison_to_landsat_and_keeps_assets_private(client, monkeypatch):
    from datetime import date

    first = {'id': 'LT05_L2SP_169034_19840903_02_T1', 'sensor': 'landsat', '_items': ['private metadata']}
    second = {'id': 'LC09_L2SP_169034_20260923_02_T1', 'sensor': 'landsat', '_items': []}
    pair = {'before': first['id'], 'after': second['id']}

    def historical(bbox, start, end):
        assert start == date(1984, 9, 3) and end == date(2026, 9, 23)
        return {'sensor': 'landsat', 'scenes': [first, second], 'pairs': [pair]}

    def unexpected_radar(*_):
        pytest.fail('A historical date reached NISAR')

    monkeypatch.setattr('sarwatch.catalog.search', unexpected_radar)
    monkeypatch.setattr('sarwatch.landsat.search_epochs', historical)
    monkeypatch.delenv('EARTHDATA_TOKEN', raising=False)
    response = client.get('/api/scenes', params={'bbox': '44.9,37.5,45.15,37.7', 'sensor': 'auto',
                                                 'start': '1984-09-03', 'end': '2026-09-23'})
    assert response.status_code == 200
    assert response.json()['pairs'] == [pair]
    assert '_items' not in response.text
    submitted = []
    monkeypatch.setattr(api.POOL, 'submit', lambda *args: submitted.append(args))
    try:
        job = client.post('/api/analyses', json={'bbox': [44.9, 37.5, 45.15, 37.7],
                                                'before_id': first['id'], 'after_id': second['id'],
                                                'sensor': 'landsat'})
        assert job.status_code == 202 and len(submitted) == 1
    finally:
        if submitted:
            api.BUSY.release()
