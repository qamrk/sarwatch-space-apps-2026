"""API checks use explicit fixtures; they never simulate real observations in the app."""
import pytest
from fastapi.testclient import TestClient
from sarwatch import api


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(api,'ROOT',tmp_path/'jobs')
    monkeypatch.setattr(api,'CASE_ROOT',tmp_path/'cases')
    api.SCENES.clear();api.JOBS.clear()
    with TestClient(api.app) as c:yield c


def test_health_never_exposes_secret(client,monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    r=client.get('/api/health')
    assert r.status_code==200
    assert r.json()['data_access_configured'] is True
    assert 'unit-test-secret' not in r.text


def test_missing_access_is_explicit(client,monkeypatch):
    monkeypatch.delenv('EARTHDATA_TOKEN',raising=False)
    r=client.post('/api/analyses',json={'bbox':[74,46,74.01,46.01],
                  'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'})
    assert r.status_code==503


def test_large_aoi_rejected_before_network(client):
    r=client.post('/api/analyses',json={'bbox':[74,46,75,47.1],
                  'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'})
    assert r.status_code==422


def test_unknown_scene_cannot_supply_a_download_url(client,monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    r=client.post('/api/analyses',json={'bbox':[74,46,74.01,46.01],
                  'before_id':'https://example.com/before.h5','after_id':'https://example.com/after.h5'})
    assert r.status_code==409


def test_jobs_from_multiple_clients_are_queued(client, monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    monkeypatch.setattr(api, 'QUEUE_LIMIT', 1)
    monkeypatch.setattr(api, 'HEAVY_WORKERS', 1)
    heavy, overview = [], []
    monkeypatch.setattr(api.POOL, 'submit', lambda *args: heavy.append(args))
    monkeypatch.setattr(api.OVERVIEW_POOL, 'submit', lambda *args: overview.append(args))
    def submit(sensor):
        a, b = f'{sensor}-fixture-scene-before-0001', f'{sensor}-fixture-scene-after-0002'
        api.SCENES.update({key: {'id': key, 'sensor': sensor} for key in (a, b)})
        return client.post('/api/analyses', json={'bbox': [74, 46, 74.01, 46.01], 'before_id': a,
                                                  'after_id': b, 'sensor': sensor})

    first = submit('nisar')
    assert first.status_code == 202
    api.JOBS[first.json()['id']]['status'] = 'processing'
    second = submit('nisar')
    assert second.status_code == 202
    assert client.get(second.json()['status_url']).json()['queue_position'] == 1
    full = submit('nisar')
    assert full.status_code == 429 and full.headers['Retry-After'] == '30'
    assert submit('modis').status_code == 202
    assert len(heavy) == 2 and len(overview) == 1


def test_series_compares_consecutive_dates_and_exposes_interval_assets(client, monkeypatch):
    import threading

    bbox = [44.9, 37.5, 45.0, 37.58]
    days = ['2014-09-22', '2020-09-06', '2023-09-07']
    observations = [{'id': f'landsat-synthetic-{day}', 'start': day, 'sensor': 'landsat'} for day in days]
    ids = [scene['id'] for scene in observations]
    monkeypatch.setattr('sarwatch.series.search_series', lambda *_: ('landsat', observations))
    request = [('bbox', ','.join(map(str, bbox))), *[('dates', day) for day in days]]
    assert client.get('/api/series', params=request).json()['series'] == ids

    calls = []
    settled = threading.Event()
    publish = api.publish_series
    def finish(*args):
        publish(*args)
        settled.set()
    def compare(config, catalog, before, after, folder):
        calls.append((before, after))
        mapping = folder/'mapping'
        mapping.mkdir(parents=True)
        (mapping/'before.png').write_bytes(b'fixture')
        return {'layers': [{'id': 'before', 'file': 'before.png'}], 'water': {'status': 'not_requested'},
                'sources': catalog['scenes'], 'bbox': bbox}

    monkeypatch.setattr(api, 'publish_series', finish)
    monkeypatch.setattr(api, 'run_pair', compare)
    response = client.post('/api/analyses', json={'bbox': bbox, 'scene_ids': ids, 'sensor': 'landsat'})
    assert response.status_code == 202 and settled.wait(5)
    job = client.get(response.json()['status_url']).json()
    assert calls == [(ids[0], ids[1]), (ids[1], ids[2])]
    assert job['status'] == 'completed' and len(job['sequence']['steps']) == 2
    layer = job['sequence']['steps'][1]['result']['layers'][0]
    assert client.get(layer['url']).content == b'fixture'
    assert client.get(response.json()['status_url']+'/steps/2/assets/before.png').status_code == 404


def test_series_path_can_follow_a_second_ranked_compatible_scene():
    from sarwatch.series import find_chain
    links = {(1, 2), (1, 3), (3, 4)}
    assert find_chain([[1], [2, 3], [4]], lambda a, b: (a, b) in links) == [1, 3, 4]


def test_internal_files_are_not_downloadable(client):
    assert client.get('/api/analyses/unknown/assets/.env').status_code==404
    assert client.get('/api/analyses/unknown').status_code==404



def test_empty_prepared_cases_keep_the_endpoint(client):
    assert client.get('/api/cases').json()=={'cases':[]}
    assert client.get('/cases/index.json').json()=={'cases':[]}
    for case in ('burabay-july-2026','burabay-forest-2026','maikol-fields-2026'):
        assert client.get(f'/cases/{case}/before.png').status_code==404
        assert client.get(f'/api/cases/{case}/assets/report-ru.pdf').status_code==404


def test_hundred_km_limit_is_advertised_and_larger_windows_rejected(client,monkeypatch):
    assert client.get('/api/health').json()['max_side_km']==100
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    request={'bbox':[75,46,75.12,46.08],'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'}
    assert client.post('/api/analyses',json=request).status_code==409
    request['bbox']=[75,46,77,47]
    assert client.post('/api/analyses',json=request).status_code==422


def test_scene_search_accepts_area_larger_than_five_km_without_network(client,monkeypatch):
    calls=[]
    def search(*args):
        calls.append(args);return {'scenes':[],'pairs':[]}
    monkeypatch.setattr('sarwatch.catalog.search',search)
    response=client.get('/api/scenes',params={'bbox':'75,46,75.12,46.08','start':'2026-07-01','end':'2026-07-31'})
    assert response.status_code==200 and len(calls)==1


def test_auto_routes_a_long_comparison_to_landsat_and_keeps_assets_private(client, monkeypatch):
    from datetime import date

    first = {'id': 'LT05_L2SP_169034_19840903_02_T1', 'sensor': 'landsat', '_items': ['private metadata']}
    second = {'id': 'LC09_L2SP_169034_20260923_02_T1', 'sensor': 'landsat', '_items': []}
    pair = {'before': first['id'], 'after': second['id']}

    def historical(bbox, start, end):
        assert start == date(1984, 9, 3) and end == date(2026, 9, 23)
        return {'sensor': 'landsat', 'scenes': [first, second], 'pairs': [pair]}

    def unexpected_radar(*_):
        pytest.fail('A historical date reached NISAR')

    monkeypatch.setattr('sarwatch.catalog.search', unexpected_radar)
    monkeypatch.setattr('sarwatch.landsat.search_epochs', historical)
    monkeypatch.delenv('EARTHDATA_TOKEN', raising=False)
    response = client.get('/api/scenes', params={'bbox': '44.9,37.5,45.15,37.7', 'sensor': 'auto',
                                                 'start': '1984-09-03', 'end': '2026-09-23'})
    assert response.status_code == 200
    assert response.json()['pairs'] == [pair]
    assert '_items' not in response.text
    submitted = []
    monkeypatch.setattr(api.POOL, 'submit', lambda *args: submitted.append(args))
    job = client.post('/api/analyses', json={'bbox': [44.9, 37.5, 45.15, 37.7],
                                            'before_id': first['id'], 'after_id': second['id'],
                                            'sensor': 'landsat'})
    assert job.status_code == 202 and len(submitted) == 1
