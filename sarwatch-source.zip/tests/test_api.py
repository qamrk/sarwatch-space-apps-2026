"""API checks use explicit fixtures; they never simulate real observations in the app."""
import pytest
from fastapi.testclient import TestClient
from sarwatch import api


@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(api,'ROOT',tmp_path/'jobs')
    monkeypatch.setattr(api,'CASE_ROOT',tmp_path/'cases')
    api.SCENES.clear();api.JOBS.clear();api.PENDING.clear();api.LEASES.clear()
    with TestClient(api.app) as c:yield c


def test_health_never_exposes_secret(client,monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    monkeypatch.setenv('GEMINI_API_KEY','unit-test-gemini-key')
    r=client.get('/api/health')
    assert r.status_code==200
    assert r.json()['data_access_configured'] is True
    assert r.json()['ai_configured'] is True
    assert 'unit-test-secret' not in r.text
    assert 'unit-test-gemini-key' not in r.text


def test_missing_access_is_explicit(client,monkeypatch):
    monkeypatch.delenv('EARTHDATA_TOKEN',raising=False)
    r=client.post('/api/analyses',json={'bbox':[74,46,74.01,46.01],
                  'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'})
    assert r.status_code==503


def test_large_aoi_rejected_before_network(client):
    r=client.post('/api/analyses',json={'bbox':[74,46,75,47.1],
                  'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'})
    assert r.status_code==422


def test_unknown_scene_cannot_supply_a_download_url(client,monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    r=client.post('/api/analyses',json={'bbox':[74,46,74.01,46.01],
                  'before_id':'https://example.com/before.h5','after_id':'https://example.com/after.h5'})
    assert r.status_code==409


def test_jobs_from_multiple_clients_are_queued(client, monkeypatch):
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    monkeypatch.setattr(api, 'QUEUE_LIMIT', 1)
    monkeypatch.setattr(api, 'HEAVY_WORKERS', 1)
    heavy, overview = [], []
    monkeypatch.setattr(api.POOL, 'submit', lambda *args: heavy.append(args))
    monkeypatch.setattr(api.OVERVIEW_POOL, 'submit', lambda *args: overview.append(args))
    def submit(sensor):
        a, b = f'{sensor}-fixture-scene-before-0001', f'{sensor}-fixture-scene-after-0002'
        api.SCENES.update({key: {'id': key, 'sensor': sensor} for key in (a, b)})
        return client.post('/api/analyses', json={'bbox': [74, 46, 74.01, 46.01], 'before_id': a,
                                                  'after_id': b, 'sensor': sensor})

    first = submit('nisar')
    assert first.status_code == 202
    api.JOBS[first.json()['id']]['status'] = 'processing'
    second = submit('nisar')
    assert second.status_code == 202
    assert client.get(second.json()['status_url']).json()['queue_position'] == 1
    full = submit('nisar')
    assert full.status_code == 429 and full.headers['Retry-After'] == '30'
    assert submit('modis').status_code == 202
    assert len(heavy) == 2 and len(overview) == 1


def test_series_compares_consecutive_dates_and_exposes_interval_assets(client, monkeypatch):
    import threading

    bbox = [44.9, 37.5, 45.0, 37.58]
    days = ['2014-09-22', '2020-09-06', '2023-09-07']
    observations = [{'id': f'landsat-synthetic-{day}', 'start': day, 'sensor': 'landsat'} for day in days]
    ids = [scene['id'] for scene in observations]
    monkeypatch.setattr('sarwatch.series.search_series', lambda *_: ('landsat', observations))
    request = [('bbox', ','.join(map(str, bbox))), *[('dates', day) for day in days]]
    assert client.get('/api/series', params=request).json()['series'] == ids

    calls = []
    settled = threading.Event()
    publish = api.publish_series
    def finish(*args):
        publish(*args)
        settled.set()
    def compare(config, catalog, before, after, folder):
        calls.append((before, after))
        mapping = folder/'mapping'
        mapping.mkdir(parents=True)
        (mapping/'before.png').write_bytes(b'fixture')
        return {'layers': [{'id': 'before', 'file': 'before.png'}], 'water': {'status': 'not_requested'},
                'sources': catalog['scenes'], 'bbox': bbox}

    monkeypatch.setattr(api, 'publish_series', finish)
    monkeypatch.setattr(api, 'run_pair', compare)
    response = client.post('/api/analyses', json={'bbox': bbox, 'scene_ids': ids, 'sensor': 'landsat'})
    assert response.status_code == 202 and settled.wait(5)
    job = client.get(response.json()['status_url']).json()
    assert calls == [(ids[0], ids[1]), (ids[1], ids[2])]
    assert job['status'] == 'completed' and len(job['sequence']['steps']) == 2
    layer = job['sequence']['steps'][1]['result']['layers'][0]
    assert client.get(layer['url']).content == b'fixture'
    assert client.get(response.json()['status_url']+'/steps/2/assets/before.png').status_code == 404


def test_series_path_can_follow_a_second_ranked_compatible_scene():
    from sarwatch.series import find_chain
    links = {(1, 2), (1, 3), (3, 4)}
    assert find_chain([[1], [2, 3], [4]], lambda a, b: (a, b) in links) == [1, 3, 4]


def test_external_worker_claims_queued_job_and_publishes_assets(client, monkeypatch, tmp_path):
    import json
    from sarwatch.worker_bundle import package_bundle

    token = 'test-worker-' + 'x'*32
    monkeypatch.setenv('SARWATCH_WORKER_TOKEN', token)
    headers = {'Authorization': f'Bearer {token}'}
    submitted = []
    monkeypatch.setattr(api.POOL, 'submit', lambda *args: submitted.append(args))
    sources = [{'id': f'landsat-fixture-2026-03-0{i}', 'sensor': 'landsat', 'start': f'2026-03-0{i}'} for i in (1, 2)]
    api.SCENES.update({source['id']:source for source in sources})
    response = client.post('/api/analyses', json={'bbox':[74,46,74.01,46.01], 'before_id':sources[0]['id'],
                                                'after_id':sources[1]['id'], 'sensor':'landsat'})
    assert response.status_code == 202
    job_id = response.json()['id']
    assert client.post('/internal/worker/claim').status_code == 401
    claim = client.post('/internal/worker/claim', headers=headers).json()
    assert claim['id'] == job_id and 'EARTHDATA_TOKEN' not in claim
    assert client.post('/internal/worker/claim', headers=headers).status_code == 204
    submitted[0][0](*submitted[0][1:])  # the local slot may free up after the claim
    assert client.get(response.json()['status_url']).json()['executor'] == 'external'
    headers['X-Worker-Lease'] = claim['lease']
    folder = tmp_path/'worker-output'
    (folder/'mapping').mkdir(parents=True)
    for name in ('before', 'after'):
        (folder/'mapping'/f'{name}.png').write_bytes(b'fixture image')
    for lang in api.LANGUAGES:
        (folder/f'report-{lang}.pdf').write_bytes(b'fixture report')
    result = {'layers':[{'id':'before','file':'before.png'}], 'sources':sources, 'water':{'status':'not_requested'}}
    (folder/'result.json').write_text(json.dumps(result), encoding='utf-8')
    bundle = tmp_path/'bundle.zip'
    package_bundle(folder, bundle)
    endpoint = f'/internal/worker/{job_id}'
    assert client.post(endpoint+'/heartbeat', headers=headers).status_code == 204
    assert client.post(endpoint+'/result', headers=headers, content=bundle.read_bytes()).status_code == 204
    status = client.get(response.json()['status_url']).json()
    assert status['status'] == 'completed' and client.get(status['result']['layers'][0]['url']).content == b'fixture image'
    assert client.post(endpoint+'/retry', headers=headers).status_code == 409


def test_expired_worker_lease_returns_task_to_render(client, monkeypatch):
    token = 'test-worker-' + 'x'*32
    monkeypatch.setenv('SARWATCH_WORKER_TOKEN', token)
    clock = iter([10, 10 + api.LEASE_SECONDS + 1])
    monkeypatch.setattr(api, 'monotonic', lambda: next(clock))
    submissions = []
    monkeypatch.setattr(api.POOL, 'submit', lambda *args: submissions.append(args))
    ids = [f'landsat-fixture-2026-03-0{i}' for i in (1, 2)]
    api.SCENES.update({key:{'id':key, 'sensor':'landsat'} for key in ids})
    job = client.post('/api/analyses', json={'bbox':[74,46,74.01,46.01], 'before_id':ids[0],
                                           'after_id':ids[1], 'sensor':'landsat'}).json()
    claim = client.post('/internal/worker/claim', headers={'Authorization':f'Bearer {token}'}).json()
    assert claim['id'] == job['id']
    status = client.get(job['status_url']).json()
    assert status['status'] == 'waiting' and 'executor' not in status
    assert len(submissions) == 2


def test_internal_files_are_not_downloadable(client):
    assert client.get('/api/analyses/unknown/assets/.env').status_code==404
    assert client.get('/api/analyses/unknown').status_code==404



def test_empty_prepared_cases_keep_the_endpoint(client):
    assert client.get('/api/cases').json()=={'cases':[]}
    assert client.get('/cases/index.json').json()=={'cases':[]}
    for case in ('burabay-july-2026','burabay-forest-2026','maikol-fields-2026'):
        assert client.get(f'/cases/{case}/before.png').status_code==404
        assert client.get(f'/api/cases/{case}/assets/report-ru.pdf').status_code==404


def test_hundred_km_limit_is_advertised_and_larger_windows_rejected(client,monkeypatch):
    assert client.get('/api/health').json()['max_side_km']==100
    monkeypatch.setenv('EARTHDATA_TOKEN','unit-test-secret')
    request={'bbox':[75,46,75.12,46.08],'before_id':'fixture-scene-before-0001','after_id':'fixture-scene-after-00002'}
    assert client.post('/api/analyses',json=request).status_code==409
    request['bbox']=[75,46,77,47]
    assert client.post('/api/analyses',json=request).status_code==422


def test_scene_search_accepts_area_larger_than_five_km_without_network(client,monkeypatch):
    calls=[]
    def search(*args):
        calls.append(args);return {'scenes':[],'pairs':[]}
    monkeypatch.setattr('sarwatch.catalog.search',search)
    response=client.get('/api/scenes',params={'bbox':'75,46,75.12,46.08','start':'2026-07-01','end':'2026-07-31'})
    assert response.status_code==200 and len(calls)==1


def test_auto_routes_a_long_comparison_to_landsat_and_keeps_assets_private(client, monkeypatch):
    from datetime import date

    first = {'id': 'LT05_L2SP_169034_19840903_02_T1', 'sensor': 'landsat', '_items': ['private metadata']}
    second = {'id': 'LC09_L2SP_169034_20260923_02_T1', 'sensor': 'landsat', '_items': []}
    pair = {'before': first['id'], 'after': second['id']}

    def historical(bbox, start, end):
        assert start == date(1984, 9, 3) and end == date(2026, 9, 23)
        return {'sensor': 'landsat', 'scenes': [first, second], 'pairs': [pair]}

    def unexpected_radar(*_):
        pytest.fail('A historical date reached NISAR')

    monkeypatch.setattr('sarwatch.catalog.search', unexpected_radar)
    monkeypatch.setattr('sarwatch.landsat.search_epochs', historical)
    monkeypatch.delenv('EARTHDATA_TOKEN', raising=False)
    response = client.get('/api/scenes', params={'bbox': '44.9,37.5,45.15,37.7', 'sensor': 'auto',
                                                 'start': '1984-09-03', 'end': '2026-09-23'})
    assert response.status_code == 200
    assert response.json()['pairs'] == [pair]
    assert '_items' not in response.text
    submitted = []
    monkeypatch.setattr(api.POOL, 'submit', lambda *args: submitted.append(args))
    job = client.post('/api/analyses', json={'bbox': [44.9, 37.5, 45.15, 37.7],
                                            'before_id': first['id'], 'after_id': second['id'],
                                            'sensor': 'landsat'})
    assert job.status_code == 202 and len(submitted) == 1


def test_modern_automatic_search_never_replaces_missing_nisar_with_optical(client, monkeypatch):
    monkeypatch.setattr('sarwatch.catalog.search', lambda *_: {'scenes': [], 'pairs': []})

    def forbidden(*_):
        pytest.fail('A modern automatic search unexpectedly reached an optical catalogue')

    monkeypatch.setattr('sarwatch.landsat.search_epochs', forbidden)
    monkeypatch.setattr('sarwatch.landsat.epoch_options', forbidden)
    monkeypatch.setattr('sarwatch.modis.search_comparison', forbidden)
    monkeypatch.setattr('sarwatch.modis.nearby_scene', forbidden)
    common = [('bbox', '60.82,46.43,61.19,46.65'), ('sensor', 'auto')]
    two = client.get('/api/scenes', params=[*common, ('start', '2026-06-21'), ('end', '2026-10-07')])
    three = client.get('/api/series', params=[*common, ('dates', '2026-06-21'), ('dates', '2026-08-08'), ('dates', '2026-10-07')])
    assert two.status_code == three.status_code == 200
    assert two.json()['sensor'] == three.json()['sensor'] == 'nisar'
    assert two.json()['pairs'] == three.json()['series'] == []


def test_radar_auto_can_find_a_compatible_pass_outside_initial_window(monkeypatch):
    from datetime import date
    from shapely.geometry import box, mapping
    from sarwatch import catalog

    footprint = mapping(box(66, 47, 68, 49))
    def scene(day):
        return {'id': day, 'start': day+'T03:00:00Z', 'geometry': footprint, 'maturity': 'PROVISIONAL',
                'track': '078', 'direction': 'D', 'frame': '065', 'mode': '2005',
                'polarization_mode': 'DHDH', 'configuration': 'A', 'crid': 'P05023'}

    def lookup(bbox, start, end, maturity, limit):
        observations = [scene(day) for day in ('2026-06-19', '2026-10-17')
                        if start[:10] <= day <= end[:10] and maturity == 'PROVISIONAL']
        return {'scenes': observations}

    monkeypatch.setattr(catalog, 'search', lookup)
    found = catalog.search_near_dates([66.9, 47.94, 67.1, 48.06], date(2026, 6, 17), date(2026, 11, 14), 250, 'PROVISIONAL')
    assert [(pair['before'], pair['after']) for pair in found['pairs']] == [('2026-06-19', '2026-10-17')]
