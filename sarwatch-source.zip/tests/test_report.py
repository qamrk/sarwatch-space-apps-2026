"""Controlled export fixtures are test-only and never published as prepared cases."""
import copy
from PIL import Image
from pypdf import PdfReader
import pytest
from sarwatch.report import create_report


@pytest.fixture
def report_fixture(tmp_path):
    for name in ['before','after','water']:
        Image.new('RGBA',(12,12),(100,120,140,255)).save(tmp_path/f'{name}.png')
    sources=[{'id':'CONTROLLED_TEST_BEFORE','start':'2026-01-01T00:00:00Z','maturity':'TEST','crid':'FIXTURE','track':'000','frame':'000'},
             {'id':'CONTROLLED_TEST_AFTER','start':'2026-01-13T00:00:00Z','maturity':'TEST','crid':'FIXTURE','track':'000','frame':'000'}]
    checks={epoch:{'reference_id':'CONTROLLED_SCL_'+epoch.upper(),'reference_time':'2026-01-01T00:00:00Z',
                   'iou_vs_reference':.8,'clear_reference_fraction':1.,'gate_passed':True} for epoch in ['before','after']}
    manifest={'title':{'ru':'Контрольный тест','en':'Controlled test'},'sources':sources,
              'validation_status':'case_compared_with_optical_reference','reference_checks':checks,
              'metrics':{'water_before_km2':1.234,'water_after_km2':1.233,'water_gain_km2':.005,'water_loss_km2':.006,
                         'channel':'HHHH','threshold_db':-12,'pixel_area_m2':400}}
    return tmp_path,manifest


@pytest.mark.parametrize('lang',['ru','en'])
def test_report_has_sources_and_two_pages_without_secret_urls(report_fixture,lang):
    folder,manifest=report_fixture
    manifest['sources'][0]['url']='https://example.invalid/?token=do-not-export'
    output=create_report(manifest,folder,folder/f'report-{lang}.pdf',lang,prepared=True)
    reader=PdfReader(output);text='\n'.join(p.extract_text() for p in reader.pages)
    assert len(reader.pages)==2
    assert '1.234' in text and '0.8000' in text
    assert 'CONTROLLED_TEST_BEFORE' in text and 'CONTROLLED_SCL_BEFORE' in text
    assert 'do-not-export' not in text
    assert reader.pages[0].images


def test_unverified_signal_report_does_not_borrow_case_accuracy(report_fixture):
    folder,case=report_fixture;mapping=folder/'mapping';mapping.mkdir()
    for name in ['before','after','delta']:
        Image.new('RGBA',(12,12),(200,200,200,255)).save(mapping/f'{name}.png')
    result={'sources':copy.deepcopy(case['sources']),'theme':'forest','water':{'status':'not_requested'},
            'observations':[{'channel':'HHHH'}],'reference_checks':case['reference_checks']}
    report=create_report(result,folder,folder/'signal.pdf','en')
    reader=PdfReader(report);text='\n'.join(p.extract_text() for p in reader.pages)
    assert len(reader.pages)==2
    assert 'Difference in dB' in text and 'has not been independently checked' in text
    assert '0.8000' not in text and 'Water class area' not in text
