"""Synthetic controlled masks test false-positive exclusion, not real accuracy."""
import time
import numpy as np
import pytest
from sarwatch.flood import screen,auxiliary_urls,PublicRasterReader
from sarwatch.range_reader import AccessError
from test_preflight import Session


def test_screen_removes_permanent_water_slopes_and_shoreline_noise():
    classes=np.zeros((45,45),dtype='uint8');classes[18:27,18:27]=2
    occurrence=np.zeros(classes.shape,dtype='float32');dem=np.zeros_like(occurrence)
    out,stats=screen(classes,occurrence,dem,(20,20),400)
    assert (out==1).sum()==81 and stats['candidate_area_km2']==pytest.approx(.0324)
    occurrence[18:27,18:27]=95
    out,_=screen(classes,occurrence,dem,(20,20),400)
    assert not (out==1).any()
    occurrence[:]=0;classes[18:27,15:18]=1
    out,_=screen(classes,occurrence,dem,(20,20),400)
    assert (out==1).sum()<81
    dem=np.indices(classes.shape)[1].astype('float32')*20
    out,_=screen(classes,occurrence,dem,(20,20),400)
    assert not (out==1).any()


def test_missing_auxiliary_coverage_never_means_zero_flood():
    classes=np.zeros((20,20),dtype='uint8');missing=np.full(classes.shape,np.nan)
    with pytest.raises(ValueError,match='coverage'):
        screen(classes,missing,missing,(20,20),400)


def test_shoreline_buffer_uses_metric_distance_including_diagonals():
    classes=np.zeros((45,45),dtype='uint8');classes[10,10]=1;classes[12:24,12:24]=2
    occurrence=np.zeros(classes.shape,dtype='float32');dem=np.zeros_like(occurrence)
    out,_=screen(classes,occurrence,dem,(20,20),400)
    assert out[12,12]==0  # 56.6 m diagonally from known water must be excluded.
    assert out[14,14]==1  # 113.1 m remains a preliminary candidate.


def test_auxiliary_reader_has_no_bearer_and_shares_budget(monkeypatch):
    class PublicSession(Session):
        def get(self,url,headers,**kwargs):
            assert 'Authorization' not in headers
            return super().get(url,headers,**kwargs)
    monkeypatch.setattr('sarwatch.range_reader.requests.Session',lambda:PublicSession(b'x'*200000))
    ledger={'remaining':100000,'deadline':time.monotonic()+10}
    url=auxiliary_urls([70.26,53.06,70.30,53.09])[0]
    with PublicRasterReader(url,ledger) as reader:
        assert ledger['remaining']==34464
        reader.seek(65536)
        with pytest.raises(AccessError,match='budget'):reader.read(1)
    with pytest.raises(AccessError):PublicRasterReader('https://example.com/arbitrary.tif',ledger)


def test_tile_coordinates_include_negative_hemispheres_and_boundary_refusal():
    water,dem=auxiliary_urls([-5.2,-3.2,-5.18,-3.18])
    assert '10W_0N' in water and 'S04_00_W006' in dem[0]
    with pytest.raises(ValueError,match='boundary'):auxiliary_urls([69.99,53,70.01,53.01])
