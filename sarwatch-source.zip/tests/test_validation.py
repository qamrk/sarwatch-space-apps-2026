import numpy as np
from sarwatch.validation import reference_agreement
from sarwatch.validation import evaluate_reference
import rasterio
from rasterio.transform import from_origin


def test_clouds_are_excluded_and_false_water_rejected():
    ref=np.full((40,40),5,dtype='uint8');ref[:10]=6;ref[10:15]=9
    prediction=np.ones((40,40),dtype='uint8')
    result=reference_agreement(prediction,ref)
    assert result['assessed_pixels']==1400
    assert result['true_positive']==400
    assert result['false_positive']==1000
    assert result['spatial_agreement_gate'] is False


def test_reference_with_no_water_cannot_validate_model():
    result=reference_agreement(np.zeros((40,40),dtype='uint8'),np.full((40,40),5,dtype='uint8'))
    assert result['sufficient_reference'] is False
    assert result['spatial_agreement_gate'] is False


def test_before_epoch_counts_water_loss_as_previous_water(tmp_path):
    classes=np.zeros((40,40),dtype='uint8');classes[:20]=3
    reference=np.full((40,40),5,dtype='uint8');reference[:20]=6
    for name,values in [('water',classes),('ref',reference)]:
        with rasterio.open(tmp_path/f'{name}.tif','w',driver='GTiff',width=40,height=40,count=1,
                           dtype='uint8',crs='EPSG:32643',transform=from_origin(500000,5100000,20,20)) as dst:
            dst.write(values,1)
    r=evaluate_reference(tmp_path/'water.tif',tmp_path/'ref.tif','fixture',
                         '2026-07-01T00:00:00Z','2026-07-01T06:00:00Z',tmp_path/'report.json',epoch='before')
    assert r['gate_passed'] is True
    assert r['iou_vs_reference']==1
