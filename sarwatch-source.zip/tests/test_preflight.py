"""Controlled fixtures only: these are not satellite observations."""
import io
import re
import numpy as np
import pytest
import h5py
from pyproj import Transformer,Geod
import rasterio
from sarwatch.catalog import scene_identity, compatible_pairs
from sarwatch.range_reader import RangeReader, AccessError
from sarwatch.gcov import validate_aoi, inspect_window

URL='https://nisar.asf.earthdatacloud.nasa.gov/NISAR/test.h5'
NAME='NISAR_L2_PR_GCOV_033_127_A_025_2005_DHDH_A_20261021T000101_20261021T000136_P05023_N_F_J_001'


class Raw(io.BytesIO):
    bytes_read=0
    def read(self, n=-1, decode_content=False):
        data=super().read(n); self.bytes_read+=len(data)
        return data


class Response:
    def __enter__(self): return self
    def __exit__(self,*args): self.raw.close()


class Session:
    def __init__(self, data, status=206, bad_range=False):
        self.data,self.status,self.bad_range=data,status,bad_range
        self.calls=0

    def get(self,url,headers,**kwargs):
        self.calls+=1
        start,end=map(int,re.findall(r'\d+',headers['Range']))
        end=min(end,len(self.data)-1)
        r=Response(); r.url=url; r.status_code=self.status
        r.headers={'Content-Range':f'bytes {start+int(self.bad_range)}-{end}/{len(self.data)}'}
        r.raw=Raw(self.data[start:end+1]); self.last=r
        return r

    def close(self): pass


def test_reader_seek_cache_and_eof():
    data=bytes(range(256))*4
    s=Session(data)
    with RangeReader(URL,'test-token',block_size=32,session=s) as r:
        assert r.read(50)==data[:50]
        r.seek(3); assert r.read(8)==data[3:11]
        assert s.calls==2
        r.seek(-5,2); assert r.read()==data[-5:]
        assert r.read(3)==b''
        assert r.transferred==96


@pytest.mark.parametrize('status',[200,401,403,302])
def test_reader_refuses_full_download_and_auth_failures(status):
    s=Session(b'x'*100,status=status)
    with pytest.raises(AccessError): RangeReader(URL,'test-token',session=s)
    assert s.last.raw.bytes_read==0


def test_official_cdn_redirect_does_not_receive_bearer():
    class RedirectSession(Session):
        def get(self,url,headers,**kwargs):
            if url==URL:
                assert headers['Authorization']=='Bearer test-token'
                r=Response(); r.url=url; r.status_code=303; r.raw=Raw(b'')
                r.headers={'Location':'https://d1mv8zhcvry6x4.cloudfront.net/test.h5?Signature=fixture'}
                return r
            assert 'Authorization' not in headers
            return super().get(url,headers,**kwargs)
    with RangeReader(URL,'test-token',session=RedirectSession(b'hello')) as reader:
        assert reader.read()==b'hello'


def test_reader_refuses_invalid_content_range():
    with pytest.raises(AccessError,match='Inconsistent'):
        RangeReader(URL,'test-token',session=Session(b'x'*100,bad_range=True))


def test_network_budget_stops_before_second_request():
    s=Session(b'x'*1024)
    with RangeReader(URL,'test-token',budget=32,block_size=32,session=s) as r:
        with pytest.raises(AccessError,match='budget'): r.read(33)
        assert s.calls==1


def test_no_token_no_request():
    s=Session(b'x')
    with pytest.raises(AccessError,match='missing'): RangeReader(URL,'',session=s)
    assert s.calls==0


def test_unknown_host_rejected():
    with pytest.raises(AccessError): RangeReader('https://example.org/test.h5','test-token')


def test_pairing_rejects_processing_changes():
    a=scene_identity('https://example.org/'+NAME+'.h5','PROVISIONAL')
    b=scene_identity('https://example.org/'+NAME.replace('033','032',1).replace('20261021','20261009')+'.h5','PROVISIONAL')
    assert len(compatible_pairs([a,b,a]))==1
    for field in ('crid','maturity','direction','frame','mode','polarization_mode'):
        altered=dict(b); altered[field]='DIFFERENT'
        assert compatible_pairs([a,altered])==[]


def test_aoi_limit_and_invalid_bounds():
    validate_aoi([74,46,74.01,46.01])
    for box in ([74,46,75,47],[75,46,74,47],[179,46,-179,47]):
        with pytest.raises(ValueError): validate_aoi(box)



def test_aoi_ten_km_boundary_and_larger_rejection():
    g=Geod(ellps='WGS84')
    for lat in (-60,0,46,75):
        south=g.fwd(75,lat,180,4975)[1];north=g.fwd(75,lat,0,4975)[1]
        west=g.fwd(75,lat,270,4975)[0];east=g.fwd(75,lat,90,4975)[0]
        validate_aoi([west,south,east,north])
    north=g.fwd(75,46,0,10001)[1]
    with pytest.raises(ValueError,match='10 km'):validate_aoi([74.999,46,75.001,north])


def test_hdf5_window_georeferencing_and_nodata(tmp_path,monkeypatch):
    buf=io.BytesIO()
    with h5py.File(buf,'w') as f:
        g=f.create_group('/science/LSAR/GCOV/grids/frequencyA')
        g['projection']=32643
        g['xCoordinates']=500000+np.arange(10)*10.
        g['yCoordinates']=5100000-np.arange(10)*10.
        g['xCoordinateSpacing']=10.
        g['yCoordinateSpacing']=-10.
        power=np.ones((10,10),dtype='float32'); power[2,2]=0
        g['HHHH']=power
        mask=np.ones((10,10),dtype='uint8'); mask[3,3]=0; mask[4,4]=255
        g['mask']=mask
    session=Session(buf.getvalue())
    monkeypatch.setattr('sarwatch.gcov.RangeReader',lambda url,token,**kw:RangeReader(url,token,session=session,**kw))
    bbox=Transformer.from_crs(32643,4326,always_xy=True).transform_bounds(500015,5099955,500045,5099985)
    p=tmp_path/'window.tif'
    result=inspect_window(URL,'test-token',bbox,p)
    assert result['quality_mask_applied'] is True
    assert result['transferred_bytes']<100_000_000
    assert result['raw_mask_histogram'] is not None
    with rasterio.open(p) as src:
        arr=src.read(1)
        assert src.crs.to_epsg()==32643
        assert src.res==(10.,10.)
        assert np.nanmax(arr)==0
        assert np.isnan(arr).any()
        assert np.isnan(arr).sum()>=2
