import numpy as np
import rasterio
from rasterio.transform import from_origin
from PIL import Image
from sarwatch.comparison import compare
from sarwatch.map_layers import render_layers


def test_layers_have_real_geographic_bounds_and_transparency(tmp_path):
    data=np.zeros((20,20),dtype='float32');data[0,0]=np.nan
    for name in ['before','after']:
        with rasterio.open(tmp_path/f'{name}.tif','w',driver='GTiff',width=20,height=20,count=1,
                           dtype='float32',crs='EPSG:32643',transform=from_origin(500000,5100000,20,20),nodata=np.nan) as dst:
            dst.write(data,1)
    compare(tmp_path/'before.tif',tmp_path/'after.tif',tmp_path/'comparison')
    layers=render_layers(tmp_path)
    assert {l['id'] for l in layers}=={'before','after','delta'}
    for layer in layers:
        west,south,east,north=layer['bounds']
        assert 74<west<east<76 and 45<south<north<47
        image=Image.open(tmp_path/'mapping'/layer['file'])
        assert image.mode=='RGBA'
        assert np.array(image)[:,:,3].min()==0
