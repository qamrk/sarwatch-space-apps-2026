import json
import numpy as np
import rasterio
from rasterio.transform import from_origin
from sarwatch.comparison import compare


def raster(path,data,x=500000):
    with rasterio.open(path,'w',driver='GTiff',width=data.shape[1],height=data.shape[0],
                       count=1,dtype='float32',crs='EPSG:32643',
                       transform=from_origin(x,5100000,20,20),nodata=np.nan) as dst:
        dst.write(data.astype('float32'),1)


def test_known_difference_and_nodata(tmp_path):
    a=np.zeros((3,3),dtype='float32'); a[0,0]=np.nan
    b=np.full((3,3),10.,dtype='float32')
    raster(tmp_path/'a.tif',a); raster(tmp_path/'b.tif',b)
    stats=compare(tmp_path/'a.tif',tmp_path/'b.tif',tmp_path/'out')
    assert stats['comparable_pixels']==8
    assert np.isclose(stats['median_delta_db'],10)
    assert stats['water_classification'] is False
    with rasterio.open(tmp_path/'out/delta_db.tif') as src:
        assert np.isnan(src.read(1)[0,0])
    assert json.loads((tmp_path/'out/comparison.json').read_text())['quality_mask_applied'] is False


def test_alignment_interpolates_linear_power(tmp_path):
    raster(tmp_path/'a.tif',np.zeros((3,3)))
    raster(tmp_path/'b.tif',np.tile([0.,10.,10.],(3,1)),x=500010)
    compare(tmp_path/'a.tif',tmp_path/'b.tif',tmp_path/'out')
    with rasterio.open(tmp_path/'out/delta_db.tif') as src:
        assert np.isclose(src.read(1)[1,1],10*np.log10(5.5),atol=1e-4)
