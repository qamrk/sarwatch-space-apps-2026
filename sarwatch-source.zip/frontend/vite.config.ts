import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { cpSync, mkdirSync, readdirSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { resolve } from 'node:path';

// Only reviewed, public case assets are bundled. Never copy .env, work or raw data.
const publicCases=resolve('public/cases');
// Reconcile the generated directory so removed examples cannot survive a rebuild.
rmSync(publicCases,{recursive:true,force:true}); mkdirSync(publicCases,{recursive:true});
mkdirSync(resolve('public/presets'),{recursive:true});
const presetSource=resolve('../sarwatch/assets/presets.json');
if(existsSync(presetSource))cpSync(presetSource,resolve('public/presets/index.json'));
const source=resolve('../cases'); const manifests:Record<string,unknown>[]=[];
if(existsSync(source)) for(const dir of readdirSync(source)) {
  const path=resolve(source,dir,'manifest.json'); if(!existsSync(path)) continue;
  const m=JSON.parse(readFileSync(path,'utf8')); if(!m.ready_for_demo||m.id!==dir) continue;
  mkdirSync(resolve(publicCases,dir),{recursive:true});
  const files=new Set<string>(['manifest.json','preview-ru.png','preview-en.png','report-ru.pdf','report-en.pdf',...m.layers.map((l:{file:string})=>l.file)]);
  for(const optional of ['water.geojson','reference.png','preview-kk.png','report-kk.pdf']) if(existsSync(resolve(source,dir,optional)))files.add(optional);
  for(const file of files) {
    if(!/^[a-z0-9_-]+\.(png|pdf|json|geojson)$/.test(file))throw Error('Invalid public case asset');
    cpSync(resolve(source,dir,file),resolve(publicCases,dir,file));
  }
  manifests.push(m);
}
manifests.sort((a,b)=>Number(b.theme==='water')-Number(a.theme==='water'));
await import('node:fs').then(fs=>fs.writeFileSync(resolve(publicCases,'index.json'),JSON.stringify({cases:manifests})));
export default defineConfig({plugins:[react()],server:{port:5173,strictPort:true,proxy:{'/api':'http://127.0.0.1:8000'}},preview:{port:5173,strictPort:true}});
