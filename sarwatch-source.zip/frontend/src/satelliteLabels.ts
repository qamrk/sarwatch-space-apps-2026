import { maplibreGL } from '@maplibre/maplibre-gl-leaflet';
import { setWorkerUrl } from 'maplibre-gl';
import MapWorker from 'maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url';
import 'maplibre-gl/dist/maplibre-gl.css';

setWorkerUrl(MapWorker);

export function satelliteLabels(pane: string) {
  const options = {
    pane,
    style: 'https://www.arcgis.com/sharing/rest/content/items/6d6ccd4eea864226a352874655bd75c6/resources/styles/root.json',
    attributionControl: false as const,
  };
  return maplibreGL(options);
}
