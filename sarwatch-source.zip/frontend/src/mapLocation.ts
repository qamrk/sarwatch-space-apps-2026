import views from './countryViews.json';

export type BBox = [number, number, number, number];
export type MapRegion = {country: string; bounds: BBox};
export const WORLD_VIEW: BBox = [-158, -56, 158, 76];

// Approximate viewports from Natural Earth and IANA zone.tab, both public domain.
const countryBounds: Record<string, number[] | undefined> = views.bounds;
const timeZones: Record<string, string | undefined> = views.zones;

export function countryRegion(country?: string | null, zone?: string): MapRegion | null {
  for (const code of [country, zone && timeZones[zone]]) {
    if (!code || !Object.hasOwn(countryBounds, code)) continue;
    const coordinates = countryBounds[code];
    if (coordinates?.length === 4) return {country: code, bounds: coordinates as BBox};
  }
  return null;
}

export function browserPosition(): Promise<[number, number] | null> {
  return new Promise(resolve => {
    if (!navigator.geolocation || !window.isSecureContext) { resolve(null); return; }
    navigator.geolocation.getCurrentPosition(
      ({coords}) => resolve([coords.latitude, coords.longitude]),
      () => resolve(null),
      {maximumAge: 120000, timeout: 8000},
    );
  });
}
