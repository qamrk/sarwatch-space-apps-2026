import React, { useEffect, useState } from 'react';
import { ChevronRight } from 'lucide-react';

type Language = 'ru' | 'en' | 'kk';
type Atmosphere = {
  start: string;
  end: string;
  days_with_rain_data: number;
  rain_mm?: number;
  normal_rain_mm?: number;
  temperature_c?: number;
  humidity_pct?: number;
  wind_ms?: number;
};
type Context = {
  latitude: number;
  longitude: number;
  windows: Record<string, Atmosphere>;
  baseline?: string;
  daily_urls: string[];
  climatology_url: string;
  event?: { cause: Record<Language, string>; source: string; url: string };
  ai_explanation?: string | null;
  ai_provider?: 'gemini' | 'openai' | null;
  ai_status?: 'ready' | 'unavailable' | 'not_configured';
};

const copy = {
  ru: {
    title: 'Погода и причины изменений', before: 'До первого снимка', after: 'До второго снимка', event: 'К дате события',
    period: '14 дней до даты включительно. Погода по ячейке NASA POWER в центре участка.',
    date: 'Период, UTC', rain: 'Осадки, мм', normal: 'Сезонный ориентир, мм', temperature: 'Температура, °C',
    humidity: 'Влажность, %', wind: 'Ветер, м/с', loading: 'Загружаем данные NASA POWER…',
    failed: 'Данные о погоде сейчас недоступны.', retry: 'Повторить', model: 'Интерпретация ИИ',
    aiUnavailable: 'ИИ не вернул объяснение. Попробуйте ещё раз.', aiNotConfigured: 'ИИ-объяснение ещё не подключено.',
    weather: 'Суточные данные NASA POWER', climate: 'Месячная климатология NASA POWER',
    baseline: 'Ориентир получен из средних суточных осадков для месяцев, попавших в период.',
    limits: 'Погода описывает условия съёмки и события. Для установления причины также нужны независимые данные.',
    water: 'Для изменений воды проверьте осадки выше по течению, приток и данные об уровне водоёма.',
    fire: 'Влажность и ветер описывают условия распространения огня. Источник возгорания устанавливают по отчётам о пожаре.',
    forest: 'Сезонность растительности и сырость могут влиять на снимки. Для определения причины нужны дополнительные наблюдения.',
    above: 'Осадков было больше сезонного ориентира.', below: 'Осадков было меньше сезонного ориентира.',
    typical: 'Сумма осадков близка к сезонному ориентиру.',
    epoch: 'К снимку',
  },
  en: {
    title: 'Weather and possible causes', before: 'Before the first image', after: 'Before the second image', event: 'Leading up to the event',
    period: '14 days up to and including each date. NASA POWER weather at the centre of the area.',
    date: 'Period, UTC', rain: 'Rain, mm', normal: 'Seasonal baseline, mm', temperature: 'Temperature, °C',
    humidity: 'Humidity, %', wind: 'Wind, m/s', loading: 'Loading NASA POWER data…',
    failed: 'Weather data are currently unavailable.', retry: 'Retry', model: 'AI interpretation',
    aiUnavailable: 'The AI service did not return an explanation. Try again.', aiNotConfigured: 'AI explanations are not configured yet.',
    weather: 'NASA POWER daily data', climate: 'NASA POWER monthly climatology',
    baseline: 'The baseline uses average daily rainfall for the months covered by each period.',
    limits: 'Weather provides context for the observations and event. Establishing a cause also requires independent evidence.',
    water: 'Upstream rainfall, inflow and water levels can help explain changes in water extent.',
    fire: 'Humidity and wind describe conditions for fire spread. Incident reports establish the ignition source.',
    forest: 'Seasonal vegetation and surface moisture can affect the imagery. Additional observations are needed to identify a cause.',
    above: 'Rainfall was above the seasonal baseline.', below: 'Rainfall was below the seasonal baseline.',
    typical: 'Rainfall was close to the seasonal baseline.',
    epoch: 'Leading up to image',
  },
  kk: {
    title: 'Ауа райы және өзгеріс себептері', before: 'Бірінші суретке дейін', after: 'Екінші суретке дейін', event: 'Оқиға күніне дейін',
    period: 'Әр күнді қоса есептегенде 14 күн. NASA POWER аумақ ортасындағы тор ұяшығының ауа райын бағалайды.',
    date: 'Кезең, UTC', rain: 'Жауын-шашын, мм', normal: 'Маусымдық бағдар, мм', temperature: 'Температура, °C',
    humidity: 'Ылғалдылық, %', wind: 'Жел, м/с', loading: 'NASA POWER деректері жүктелуде…',
    failed: 'Ауа райы деректері қазір қолжетімсіз.', retry: 'Қайталау', model: 'ЖИ түсіндірмесі',
    aiUnavailable: 'ЖИ түсіндірме бермеді. Қайта көріңіз.', aiNotConfigured: 'ЖИ түсіндірмесі әлі қосылмаған.',
    weather: 'NASA POWER күндік деректері', climate: 'NASA POWER айлық климатологиясы',
    baseline: 'Маусымдық бағдар сол кезеңге кіретін айлардың орташа күндік жауын-шашынымен есептеледі.',
    limits: 'Ауа райы түсірілім мен оқиғаның жағдайын сипаттайды. Себепті анықтау үшін тәуелсіз деректер қажет.',
    water: 'Су ауданының өзгеруін түсіндіруге өзеннің жоғарғы ағысындағы жауын-шашын, су ағыны мен деңгейі көмектеседі.',
    fire: 'Ылғалдылық пен жел өрттің таралу жағдайын сипаттайды. Тұтану себебі өрт туралы есептерден анықталады.',
    forest: 'Өсімдіктің маусымдық өзгерісі мен жердің ылғалы суретке әсер етуі мүмкін. Себепті анықтау үшін қосымша бақылау қажет.',
    above: 'Жауын-шашын маусымдық бағдардан көп болды.', below: 'Жауын-шашын маусымдық бағдардан аз болды.',
    typical: 'Жауын-шашын мөлшері маусымдық бағдарға жақын.', epoch: 'Суретке дейін',
  },
};

export function WeatherContext({ url, lang, theme }: { url: string; lang: Language; theme: string }) {
  const [open, setOpen] = useState(false);
  const [retry, setRetry] = useState(0);
  const [data, setData] = useState<Context | null>(null);
  const [failed, setFailed] = useState(false);
  const t = copy[lang];

  useEffect(() => {
    if (!open) return;
    const controller = new AbortController();
    let active = true;
    const timeout = window.setTimeout(() => controller.abort(), 50000);
    setData(null);
    setFailed(false);
    fetch(url + '?lang=' + lang, { signal: controller.signal })
      .then(response => {
        if (!response.ok) throw new Error('Weather unavailable');
        return response.json() as Promise<Context>;
      })
      .then(result => { if (active) setData(result); })
      .catch(() => { if (active) setFailed(true); })
      .finally(() => window.clearTimeout(timeout));
    return () => { active = false; controller.abort(); window.clearTimeout(timeout); };
  }, [open, url, lang, retry]);

  const windows = data ? Object.entries(data.windows) : [];
  const format = (number?: number) => number == null ? '—' : number.toLocaleString(lang, { maximumFractionDigits: 1 });
  const focus = data?.windows.event ?? windows[windows.length-1]?.[1];
  const rain = focus?.rain_mm, normal = focus?.normal_rain_mm;
  const seasonal = rain != null && normal != null
    ? Math.abs(rain - normal) <= Math.max(.25 * normal, 5) ? t.typical : rain > normal ? t.above : t.below
    : null;

  return <details className="weather-context" onToggle={event => setOpen(event.currentTarget.open)}>
    <summary>{t.title}<ChevronRight size={15} /></summary>
    {open && !data && <p role="status">{failed ? t.failed : t.loading}
      {failed && <button type="button" className="secondary" onClick={() => setRetry(n => n + 1)}>{t.retry}</button>}</p>}
    {data && <>
      {data.event && <p>{data.event.cause[lang]} <a href={data.event.url} target="_blank" rel="noreferrer">{data.event.source} ↗</a></p>}
      {!data.event && <p>{theme === 'water' ? t.water : theme === 'forest' ? t.forest : t.fire}</p>}
      <p>{t.period}</p>
      <div className="weather-table"><table>
        <thead><tr><th scope="col">{t.date}</th><th scope="col">{t.rain}</th><th scope="col">{t.normal}</th><th scope="col">{t.temperature}</th><th scope="col">{t.humidity}</th><th scope="col">{t.wind}</th></tr></thead>
        <tbody>{windows.map(([key, weather]) => <tr key={key}><th scope="row">{key === 'before' || key === 'after' || key === 'event' ? t[key] : `${t.epoch} ${Number(key.split('-')[1])+1}`}<small>{weather.start} – {weather.end}</small></th>
          <td>{format(weather.rain_mm)}</td><td>{format(weather.normal_rain_mm)}</td><td>{format(weather.temperature_c)}</td>
          <td>{format(weather.humidity_pct)}</td><td>{format(weather.wind_ms)}</td></tr>)}</tbody>
      </table></div>
      {windows.every(([, weather]) => !weather.days_with_rain_data) && <p>{t.failed} <button type="button" className="secondary" onClick={() => setRetry(n => n + 1)}>{t.retry}</button></p>}
      {seasonal && <p>{focus?.start} – {focus?.end}. {seasonal}</p>}
      {data.ai_explanation && <><strong>{t.model}{data.ai_provider === 'gemini' ? ' · Gemini' : ''}</strong><p>{data.ai_explanation}</p></>}
      {data.ai_status === 'unavailable' && <p>{t.aiUnavailable} <button type="button" className="secondary" onClick={() => setRetry(n => n + 1)}>{t.retry}</button></p>}
      {data.ai_status === 'not_configured' && <p>{t.aiNotConfigured}</p>}
      <p>{t.baseline} {t.limits}</p>
      <div className="scene-links">{data.daily_urls.map((href, i) => <a key={href} href={href} target="_blank" rel="noreferrer">{t.weather} {data.daily_urls.length > 1 ? i + 1 : ''} ↗</a>)}
        <a href={data.climatology_url} target="_blank" rel="noreferrer">{t.climate} ↗</a></div>
    </>}
  </details>;
}
