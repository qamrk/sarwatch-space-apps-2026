import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { Activity, Droplets, Flame, Layers, LoaderCircle, Trees, Wheat } from 'lucide-react';
import type { BBox } from './mapLocation';

const categories = {
  water: { label: 'Наводнения', icon: Droplets, days: [1, 3, 7] },
  fire: { label: 'Лесные пожары', icon: Flame, days: [1, 3, 7] },
  agri_fire: { label: 'Пожары на полях', icon: Wheat, days: [1, 3, 7] },
  forest: { label: 'Потеря леса и вырубка', icon: Trees, days: [90, 365] },
} as const;

type Category = keyof typeof categories;
type Level = 'high' | 'medium' | 'low' | 'unavailable' | 'not_applicable';
const periodLabels: Record<number, string> = { 1: '24 часа', 3: '3 дня', 7: '7 дней', 90: '90 дней', 365: '1 год' };
export const riskStyles: Record<Level, { label: string; color: string }> = {
  low: { label: 'Низкий риск', color: '#16834e' },
  medium: { label: 'Средний риск', color: '#be8404' },
  high: { label: 'Высокий риск', color: '#cb3f42' },
  unavailable: { label: 'Недостаточно данных', color: '#617385' },
  not_applicable: { label: 'Категория неприменима', color: '#94a2aa' },
};
export type RiskZone = {
  id: number; level: Level; bbox: BBox;
  factors: { label: string; value: number | null; unit: string }[];
};
type Source = {
  id: string; name: string; description: string; edition: string | null; url: string;
  status: 'available' | 'partial' | 'unavailable' | 'unconfirmed';
};
type RiskResult = {
  category: Category; days: number; status: 'available' | 'partial' | 'unavailable';
  updated_at: string; start: string; end: string; zones: RiskZone[];
  counts: Record<Level, number>; sources: Source[]; limitations: string[];
};
const sourceStatus: Record<Source['status'], string> = {
  available: 'Доступен', partial: 'Неполное покрытие', unavailable: 'Недоступен',
  unconfirmed: 'Тепловые аномалии не подтверждены',
};
const timestamp = new Intl.DateTimeFormat('ru-RU', { dateStyle: 'short', timeStyle: 'short', timeZone: 'UTC' });
const formatTime = (iso: string) => timestamp.format(new Date(iso));
const formatNumber = (value: number) => value.toLocaleString('ru-RU', { maximumFractionDigits: 1 });
const severity = ['high', 'medium', 'low', 'unavailable', 'not_applicable'] as const;
const riskFactors: Record<Category, string> = {
  water: 'Сильный дождь повышает риск прежде всего на пологих низких участках и рядом с водой.',
  fire: 'Жара, сухой воздух и ветер повышают риск распространения огня в лесах и кустарниках.',
  agri_fire: 'Сухая погода и сильные порывы повышают риск распространения огня по пашне.',
  forest: 'Риск выше рядом с недавними потерями древесного покрова, особенно в доступных местах.',
};

export function usePrediction(area: BBox | null, apiBase: string) {
  const [category, setCategory] = useState<Category>('water');
  const [days, setDays] = useState(1);
  const [result, setResult] = useState<RiskResult | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const request = useRef<AbortController | null>(null);
  const bbox = area?.join(',');

  useEffect(() => {
    setResult(null);
    setSelected(null);
    setError('');
    setLoading(false);
    return () => {
      request.current?.abort();
      request.current = null;
    };
  }, [bbox, category, days]);

  function changeCategory(value: Category) {
    setCategory(value);
    const available: readonly number[] = categories[value].days;
    if (!available.includes(days)) setDays(available[0]);
  }

  async function calculate() {
    if (!bbox || loading) return;
    const controller = new AbortController();
    request.current = controller;
    setResult(null);
    setSelected(null);
    setLoading(true);
    setError('');
    const timeout = window.setTimeout(() => controller.abort(), 75000);
    try {
      const params = new URLSearchParams({ bbox, category, days: String(days) });
      const response = await fetch(`${apiBase}/api/predictions?${params}`, { signal: controller.signal });
      const payload = await response.json().catch(() => null);
      if (request.current !== controller) return;
      if (!response.ok) {
        setError(typeof payload?.detail === 'string' ? payload.detail : 'Сервис прогноза временно недоступен.');
        return;
      }
      if (!Array.isArray(payload?.zones) || !payload.zones.length) {
        setError('Сервис вернул неполные данные.');
        return;
      }
      const next = payload as RiskResult;
      setResult(next);
      const priority = severity.find(level => next.counts[level] > 0);
      const zone = next.zones.find(item => item.level === priority);
      setSelected(zone?.id ?? null);
    } catch {
      if (request.current !== controller) return;
      setError(controller.signal.aborted ? 'Истекло время ожидания. Попробуйте повторить расчёт.'
        : 'Не удалось связаться с сервисом прогноза.');
    } finally {
      window.clearTimeout(timeout);
      if (request.current === controller) {
        request.current = null;
        setLoading(false);
      }
    }
  }

  return { category, days, changeCategory, setDays, result, selected, setSelected, loading, error, calculate };
}

type PredictionState = ReturnType<typeof usePrediction>;

export function PredictionControls({ state, areaSizes, side, area, resize }: {
  state: PredictionState; areaSizes: number[]; side: number; area: BBox | null; resize: (side: number) => void;
}) {
  const { category, days, changeCategory, setDays, loading, error, calculate } = state;
  return <div className="prediction-controls">
    <h2>Категория риска</h2>
    <div className="prediction-categories">{(Object.entries(categories) as [Category, typeof categories[Category]][])
      .map(([key, { label, icon: Icon }]) => <button key={key} className={category === key ? 'active' : ''}
        aria-pressed={category === key} onClick={() => changeCategory(key)}><Icon size={17} aria-hidden="true" />{label}</button>)}</div>
    <h2>Территория</h2>
    <p className="hint">Найдите место или нажмите на карту, чтобы выбрать центр области.</p>
    <div className="area-sizes prediction-sizes">{areaSizes.map(size => <button key={size}
      className={side === size ? 'active' : ''} aria-pressed={side === size} onClick={() => resize(size)}>{size} × {size}</button>)}</div>
    {!!area && <p className="hint">Область {side} × {side} км. Центр {((area[1]+area[3])/2).toFixed(4)}°, {((area[0]+area[2])/2).toFixed(4)}°.</p>}
    <label className="prediction-period">Горизонт оценки
      <select value={days} onChange={event => setDays(Number(event.target.value))}>
        {categories[category].days.map(period => <option key={period} value={period}>{periodLabels[period]}</option>)}
      </select>
    </label>
    {category === 'forest' && <p className="hint small-hint">Оценка по многолетней истории потери древесного покрова.</p>}
    <button className="primary full" disabled={!area || loading} onClick={() => void calculate()}>
      {loading ? <LoaderCircle className="spin" size={17} aria-hidden="true" /> : <Activity size={17} aria-hidden="true" />}
      {loading ? 'Выполняем расчёт…' : 'Рассчитать риск'}
    </button>
    {loading && <p className="hint" role="status">Получаем погоду и спутниковые данные. Это может занять до минуты.</p>}
    {error && <p className="error" role="alert">{error}</p>}
  </div>;
}

export function PredictionLegend() {
  return <div className="prediction-legend" aria-label="Легенда риска">
    {Object.entries(riskStyles).map(([level, { color, label }]) => <span key={level}>
      <i className={level === 'not_applicable' ? 'outline' : ''} style={{ '--risk-color': color } as CSSProperties} />{label}
    </span>)}
  </div>;
}

export function PredictionResults({ state }: { state: PredictionState }) {
  const { result, selected, setSelected } = state;
  const zone = result?.zones.find(item => item.id === selected);
  const highest = result && severity.slice(0, 3).find(level => result.counts[level] > 0);
  return <section className="results prediction-results" lang="ru" aria-live="polite">
    <div className="section-label">ЭКСПЕРИМЕНТАЛЬНАЯ ОЦЕНКА</div>
    <h2>{result ? categories[result.category].label : 'Карта экологических рисков'}</h2>
    {!result && <p>Уровни показывают относительный риск. Точность пока не подтверждена на независимых событиях.</p>}
    {result && <>
      <p className="prediction-timestamp">{formatTime(result.start)} → {formatTime(result.end)} UTC
        <span>Расчёт обновлён {formatTime(result.updated_at)} UTC</span></p>
      {highest ? <p className="prediction-summary" role="status">Максимальный уровень среди оценённых секторов
        <strong style={{ color: riskStyles[highest].color }}>{riskStyles[highest].label}</strong></p>
        : <p className="prediction-summary">{result.counts.unavailable ? 'Данных недостаточно для оценки.' : 'В выбранной области категория неприменима.'}</p>}
      {highest && <p className="prediction-coverage">Оценено {result.counts.high + result.counts.medium + result.counts.low} из {result.zones.length} секторов.</p>}
      {result.status === 'partial' && <p>Часть секторов не оценена из-за пропусков в данных.</p>}
      <label className="prediction-zone-select">Участок на карте
        <select value={selected ?? ''} onChange={event => setSelected(Number(event.target.value))}>
          <option value="" disabled>Выберите сектор</option>
          {result.zones.map(item => <option key={item.id} value={item.id}>Сектор {item.id} · {riskStyles[item.level].label}</option>)}
        </select>
      </label>
      {zone && <div className="prediction-zone">
        <h3>Сектор {zone.id} <span style={{ color: riskStyles[zone.level].color }}>{riskStyles[zone.level].label}</span></h3>
        {zone.factors.length > 0 && <p>{riskFactors[result.category]}</p>}
        {zone.factors.length > 0 && <dl>{zone.factors.map(factor => <div key={factor.label}>
          <dt>{factor.label}</dt><dd>{factor.value == null ? 'Есть отметка' : `${formatNumber(factor.value)}${factor.unit ? ' ' + factor.unit : ''}`}</dd>
        </div>)}</dl>}
      </div>}
      <details className="prediction-sources">
        <summary><Layers size={16} aria-hidden="true" /> Данные и даты обновления</summary>
        <ul>{result.sources.map(source => <li key={source.id}>
          <a href={source.url} target="_blank" rel="noreferrer">{source.name} ↗</a>
          <span>{source.description}</span>
          <small>{sourceStatus[source.status]}{source.edition ? ' · ' + (source.edition.includes('T') && /^\d{4}-\d{2}-\d{2}T/.test(source.edition) ? formatTime(source.edition) + ' UTC · получено' : source.edition) : ''}</small>
        </li>)}</ul>
      </details>
      <div className="prediction-limits">
        <strong>Как читать результат</strong>
        <p>Уровни показывают относительный риск. Точность пока не подтверждена на независимых событиях.</p>
        {result.limitations.map(limitation => <p key={limitation}>{limitation}</p>)}
      </div>
    </>}
  </section>;
}
