import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { Activity, Layers, LoaderCircle } from 'lucide-react';
import type { BBox } from './mapLocation';

const categories = {
  water: { label: 'Наводнения', days: [1, 3, 7] },
  fire: { label: 'Лесные пожары', days: [1, 3, 7] },
  agri_fire: { label: 'Пожары на полях', days: [1, 3, 7] },
  forest: { label: 'Потеря леса и вырубка', days: [90, 365] },
} as const;

type Category = keyof typeof categories;
type Level = 'high' | 'medium' | 'low' | 'unavailable' | 'not_applicable';
const periodLabels: Record<number, string> = { 1: '24 часа', 3: '3 дня', 7: '7 дней', 90: '90 дней', 365: '1 год' };
export const riskStyles: Record<Level, { label: string; color: string }> = {
  low: { label: 'Низкий риск', color: '#16834e' },
  medium: { label: 'Средний риск', color: '#be8404' },
  high: { label: 'Высокий риск', color: '#cb3f42' },
  unavailable: { label: 'Недостаточно данных', color: '#617385' },
  not_applicable: { label: 'Категория неприменима', color: '#94a2aa' },
};
export type RiskZone = {
  id: number; level: Level; bbox: BBox;
  factors: { label: string; value: number | null; unit: string }[];
};
type Source = {
  id: string; name: string; description: string; edition: string | null; url: string;
  status: 'available' | 'partial' | 'unavailable' | 'unconfirmed';
};
type RiskResult = {
  category: Category; days: number; status: 'available' | 'partial' | 'unavailable';
  updated_at: string; start: string; end: string; until?: string | null; zones: RiskZone[];
  counts: Record<Level, number>; sources: Source[]; limitations: string[];
};
const sourceStatus: Record<Source['status'], string> = {
  available: 'Доступен', partial: 'Неполное покрытие', unavailable: 'Недоступен',
  unconfirmed: 'Тепловые аномалии не подтверждены',
};
const timestamp = new Intl.DateTimeFormat('ru-RU', { dateStyle: 'short', timeStyle: 'short', timeZone: 'UTC' });
const formatTime = (iso: string) => timestamp.format(new Date(iso));
const calendarDate = (iso: string) => iso.split('-').reverse().join('.');
const formatNumber = (value: number) => value.toLocaleString('ru-RU', { maximumFractionDigits: 1 });
const severity = ['high', 'medium', 'low', 'unavailable', 'not_applicable'] as const;
const riskFactors: Record<Category, string> = {
  water: 'Сильный дождь повышает риск прежде всего на пологих низких участках и рядом с водой.',
  fire: 'Жара, сухой воздух и ветер повышают риск распространения огня в лесах и кустарниках.',
  agri_fire: 'Сухая погода и сильные порывы повышают риск распространения огня по пашне.',
  forest: 'Риск выше рядом с недавними потерями древесного покрова, особенно в доступных местах.',
};

function dateAfter(days: number) {
  const utc = new Date();
  utc.setUTCDate(utc.getUTCDate() + days);
  return utc.toISOString().slice(0, 10);
}

export function usePrediction(area: BBox | null, category: Category, apiBase: string) {
  const [option, setOption] = useState<number | 'date'>(1);
  const [endDate, setEndDate] = useState('');
  const [result, setResult] = useState<RiskResult | null>(null);
  const [selected, setSelected] = useState<number | null>(null);
  const [showMap, setShowMap] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const request = useRef<AbortController | null>(null);
  const bbox = area?.join(',');
  const presets: readonly number[] = categories[category].days;
  const horizon = option === 'date' || presets.includes(option) ? option : presets[0];
  const minDate = dateAfter(category === 'forest' ? presets[0] : 0);
  const maxDate = dateAfter(presets[presets.length - 1] - 1);
  const canCalculate = Boolean(bbox) && (horizon !== 'date' || (endDate >= minDate && endDate <= maxDate));
  const until = horizon === 'date' ? endDate : null;

  useEffect(() => {
    setResult(null);
    setSelected(null);
    setError('');
    setLoading(false);
    return () => {
      request.current?.abort();
      request.current = null;
    };
  }, [bbox, category, horizon, until]);

  async function calculate() {
    if (!bbox || !canCalculate || request.current) return;
    const controller = new AbortController();
    request.current = controller;
    setResult(null);
    setSelected(null);
    setLoading(true);
    setError('');
    const timeout = window.setTimeout(() => controller.abort(), 75000);
    try {
      const params = new URLSearchParams({ bbox, category });
      if (horizon === 'date') params.set('until', endDate);
      else params.set('days', String(horizon));
      const response = await fetch(`${apiBase}/api/predictions?${params}`, { signal: controller.signal });
      const payload = await response.json().catch(() => null);
      if (request.current !== controller) return;
      if (!response.ok) {
        setError(typeof payload?.detail === 'string' ? payload.detail : 'Сервис прогноза временно недоступен.');
        return;
      }
      if (!Array.isArray(payload?.zones) || !payload.zones.length) {
        setError('Сервис вернул неполные данные.');
        return;
      }
      const next = payload as RiskResult;
      setResult(next);
      setShowMap(true);
      const priority = severity.find(level => next.counts[level] > 0);
      const zone = next.zones.find(item => item.level === priority);
      setSelected(zone?.id ?? null);
    } catch {
      if (request.current !== controller) return;
      setError(controller.signal.aborted ? 'Истекло время ожидания. Попробуйте повторить расчёт.'
        : 'Не удалось связаться с сервисом прогноза.');
    } finally {
      window.clearTimeout(timeout);
      if (request.current === controller) {
        request.current = null;
        setLoading(false);
      }
    }
  }

  return { category, horizon, setOption, endDate, setEndDate, minDate, maxDate, hasArea: Boolean(bbox), canCalculate,
    result, selected, setSelected, showMap, setShowMap, loading, error, calculate };
}

type PredictionState = ReturnType<typeof usePrediction>;

export function PredictionPanel({ state }: { state: PredictionState }) {
  const { category, horizon, setOption, endDate, setEndDate, minDate, maxDate, hasArea,
    canCalculate, loading, error, calculate } = state;
  return <section className="prediction-panel" lang="ru" aria-labelledby="prediction-title">
    <h3 id="prediction-title"><Activity size={17} aria-hidden="true" />Прогнозирование</h3>
    <p className="prediction-category">{categories[category].label} · экспериментальная оценка</p>
    <div className="prediction-form">
      <label className="prediction-period">Горизонт оценки
        <select value={horizon} onChange={event => setOption(event.target.value === 'date' ? 'date' : Number(event.target.value))}>
          {categories[category].days.map(period => <option key={period} value={period}>{periodLabels[period]}</option>)}
          <option value="date">До выбранной даты</option>
        </select>
      </label>
      {horizon === 'date' && <label className="prediction-period">Дата окончания (UTC)
        <input type="date" value={endDate} min={minDate} max={maxDate} onInput={event => setEndDate(event.currentTarget.value)} />
      </label>}
      <button className="primary" disabled={!canCalculate || loading} onClick={() => void calculate()}>
        {loading ? <LoaderCircle className="spin" size={16} aria-hidden="true" /> : <Activity size={16} aria-hidden="true" />}
        {loading ? 'Выполняем расчёт…' : 'Рассчитать риск'}
      </button>
    </div>
    {horizon === 'date' && <p className="hint">Период включает выбранный день. Доступны даты с {calendarDate(minDate)} по {calendarDate(maxDate)}.</p>}
    {!hasArea && <p className="hint">Выберите участок на карте или через поиск, чтобы запустить расчёт.</p>}
    {loading && <p className="hint" role="status">Получаем погоду и спутниковые данные. Это может занять до минуты.</p>}
    {error && <p className="error" role="alert">{error}</p>}
    {state.result && <PredictionResults state={state} />}
  </section>;
}

export function PredictionLegend() {
  return <div className="prediction-legend" aria-label="Легенда риска">
    {Object.entries(riskStyles).map(([level, { color, label }]) => <span key={level}>
      <i className={level === 'not_applicable' ? 'outline' : ''} style={{ '--risk-color': color } as CSSProperties} />{label}
    </span>)}
  </div>;
}

function PredictionResults({ state }: { state: PredictionState }) {
  const { result, selected, setSelected, showMap, setShowMap } = state;
  if (!result) return null;
  const zone = result.zones.find(item => item.id === selected);
  const highest = severity.slice(0, 3).find(level => result.counts[level] > 0);
  return <div className="prediction-results">
      <p className="prediction-timestamp">{result.until ? `До ${calendarDate(result.until)} включительно (UTC)`
        : `${formatTime(result.start)} → ${formatTime(result.end)} UTC`}
        <span>Расчёт обновлён {formatTime(result.updated_at)} UTC</span></p>
      {highest ? <p className="prediction-summary" role="status">Максимальный уровень среди оценённых секторов
        <strong style={{ color: riskStyles[highest].color }}>{riskStyles[highest].label}</strong></p>
        : <p className="prediction-summary">{result.counts.unavailable ? 'Данных недостаточно для оценки.' : 'В выбранной области категория неприменима.'}</p>}
      {highest && <p className="prediction-coverage">Оценено {result.counts.high + result.counts.medium + result.counts.low} из {result.zones.length} секторов.</p>}
      {result.status === 'partial' && <p>Часть секторов не оценена из-за пропусков в данных.</p>}
      <label className="prediction-map-toggle"><input type="checkbox" checked={showMap} onChange={event => setShowMap(event.target.checked)} />Слой риска на карте</label>
      <label className="prediction-zone-select">Участок на карте
        <select value={selected ?? ''} onChange={event => setSelected(Number(event.target.value))}>
          <option value="" disabled>Выберите сектор</option>
          {result.zones.map(item => <option key={item.id} value={item.id}>Сектор {item.id} · {riskStyles[item.level].label}</option>)}
        </select>
      </label>
      {zone && <div className="prediction-zone">
        <h3>Сектор {zone.id} <span style={{ color: riskStyles[zone.level].color }}>{riskStyles[zone.level].label}</span></h3>
        {zone.factors.length > 0 && <p>{riskFactors[result.category]}</p>}
        {zone.factors.length > 0 && <dl>{zone.factors.map(factor => <div key={factor.label}>
          <dt>{factor.label}</dt><dd>{factor.value == null ? 'Есть отметка' : `${formatNumber(factor.value)}${factor.unit ? ' ' + factor.unit : ''}`}</dd>
        </div>)}</dl>}
      </div>}
      <details className="prediction-sources">
        <summary><Layers size={16} aria-hidden="true" /> Данные и даты обновления</summary>
        <ul>{result.sources.map(source => <li key={source.id}>
          <a href={source.url} target="_blank" rel="noreferrer">{source.name} ↗</a>
          <span>{source.description}</span>
          <small>{sourceStatus[source.status]}{source.edition ? ' · ' + (source.edition.includes('T') && /^\d{4}-\d{2}-\d{2}T/.test(source.edition) ? formatTime(source.edition) + ' UTC · получено' : source.edition) : ''}</small>
        </li>)}</ul>
      </details>
      <div className="prediction-limits">
        <strong>Как читать результат</strong>
        <p>Уровни показывают относительный риск. Точность пока не подтверждена на независимых событиях.</p>
        {result.limitations.map(limitation => <p key={limitation}>{limitation}</p>)}
      </div>
  </div>;
}
