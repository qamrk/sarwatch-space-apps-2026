import { useEffect, useRef, useState, type FormEvent } from 'react';
import { LoaderCircle, MapPin, Search } from 'lucide-react';
import type { BBox } from './mapLocation';

type Language = 'en' | 'ru' | 'kk';
export type MapPlace = {
  label: string;
  latitude: number;
  longitude: number;
  bounds?: BBox | null;
  country?: string | null;
};

const copy = {
  en: {
    label: 'Search the map', placeholder: 'City, region, address or coordinates',
    search: 'Find a place', searching: 'Searching places…', empty: 'No places found. Try another name.',
    unavailable: 'Place search is temporarily unavailable. Try again.',
    badCoordinates: 'Enter latitude (−90 to 90) and longitude (−180 to 180).',
  },
  ru: {
    label: 'Поиск по карте', placeholder: 'Город, область, адрес или координаты',
    search: 'Найти место', searching: 'Ищем места…', empty: 'Места не найдены. Попробуйте другое название.',
    unavailable: 'Поиск мест временно недоступен. Попробуйте ещё раз.',
    badCoordinates: 'Введите широту от −90 до 90 и долготу от −180 до 180.',
  },
  kk: {
    label: 'Картадан іздеу', placeholder: 'Қала, облыс, мекенжай не координаттар',
    search: 'Орынды табу', searching: 'Орындар ізделуде…', empty: 'Орындар табылмады. Басқа атауды енгізіңіз.',
    unavailable: 'Орын іздеу уақытша қолжетімсіз. Кейінірек қайталап көріңіз.',
    badCoordinates: 'Ендікті −90 мен 90, бойлықты −180 мен 180 аралығында енгізіңіз.',
  },
};

const coordinates = /^([+-]?(?:\d+(?:\.\d+)?|\.\d+))(?:\s*[,;]\s*|\s+)([+-]?(?:\d+(?:\.\d+)?|\.\d+))$/;

export function PlaceSearch({ lang, disabled, search, onSelect }: {
  lang: Language;
  disabled: boolean;
  search: (query: string, signal: AbortSignal) => Promise<MapPlace[]>;
  onSelect: (place: MapPlace) => void;
}) {
  const t = copy[lang];
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<MapPlace[]>([]);
  const [status, setStatus] = useState<'idle' | 'searching' | 'empty' | 'unavailable' | 'badCoordinates'>('idle');
  const request = useRef<AbortController | null>(null);
  const input = useRef<HTMLInputElement>(null);

  useEffect(() => () => request.current?.abort(), []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const value = query.trim();
    if (disabled || value.length < 2) return;
    request.current?.abort();
    setResults([]);

    const match = coordinates.exec(value);
    if (match) {
      const latitude = Number(match[1]), longitude = Number(match[2]);
      if (Math.abs(latitude) > 90 || Math.abs(longitude) > 180) {
        setStatus('badCoordinates');
        return;
      }
      setStatus('idle');
      onSelect({ label: value, latitude, longitude });
      return;
    }

    const controller = new AbortController();
    request.current = controller;
    setStatus('searching');
    try {
      const places = await search(value, controller.signal);
      if (controller.signal.aborted) return;
      setResults(places);
      setStatus(places.length ? 'idle' : 'empty');
    } catch {
      if (!controller.signal.aborted) setStatus('unavailable');
    }
  }

  return <form className="place-search" role="search" onSubmit={submit}>
    <label htmlFor="map-place-query">{t.label}</label>
    <div className="place-search-field">
      <input id="map-place-query" ref={input} type="search" autoComplete="off" maxLength={160}
        value={query} placeholder={t.placeholder} disabled={disabled}
        onChange={event => {
          request.current?.abort();
          setQuery(event.target.value);
          setResults([]);
          setStatus('idle');
        }}
        onKeyDown={event => {
          if (event.key === 'Escape') {
            request.current?.abort();
            setResults([]);
            setStatus('idle');
          }
        }} />
      <button type="submit" title={t.search} aria-label={t.search}
        disabled={disabled || status === 'searching' || query.trim().length < 2}>
        {status === 'searching' ? <LoaderCircle className="spin" size={17} /> : <Search size={17} />}
      </button>
    </div>
    {status !== 'idle' && <p className="hint" role="status">{t[status]}</p>}
    {!!results.length && <ul aria-label={t.search}>
      {results.map(place => <li key={JSON.stringify([place.label, place.longitude, place.latitude])}>
        <button type="button" disabled={disabled} onClick={() => {
          setQuery(place.label);
          input.current?.focus();
          setResults([]);
          onSelect(place);
        }}>
          <MapPin size={15} aria-hidden="true" />
          <span>{place.label}</span>
          {place.country && <small>{place.country}</small>}
        </button>
      </li>)}
    </ul>}
  </form>;
}
