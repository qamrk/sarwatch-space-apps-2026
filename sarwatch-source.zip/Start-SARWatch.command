#!/bin/zsh
set -eu
TASK_ROOT="${0:A:h}"
cd "$TASK_ROOT"
if [[ ! -x .venv/bin/python ]]; then
  print 'Не найдено окружение Python. Откройте README.md: раздел установки.'
  read -k 1 '?Нажмите любую клавишу для выхода…'
  exit 1
fi
if [[ ! -f frontend/dist/index.html ]]; then
  print 'Не найдена сборка интерфейса. Откройте README.md: раздел сборки.'
  read -k 1 '?Нажмите любую клавишу для выхода…'
  exit 1
fi
print 'Запускаем SARWatch. Оставьте это окно открытым, пока работаете с приложением.'
exec .venv/bin/python -m sarwatch.serve
