# Prepared SARWatch cases

The collection includes Mozambique, the North Aral Sea, Rasuwa, and Sinlahekin from NISAR, plus Lake Urmia from Landsat. Each case directory contains a `manifest.json` with dates, scene identifiers, and event sources, along with map image layers and PDF reports. `ready_for_demo` indicates that the observations can be displayed. Water and inundation estimates require quality checks. Radar intensity alone cannot establish burned area, slope displacement, or a forecast.

To prepare a case from a finished analysis, ensure that the preset matches the acquired scene IDs and run:

```sh
PYTHONPATH=. .venv/bin/python scripts/prepare_reviewed_case.py <preset_id> <calculation_folder>
```
