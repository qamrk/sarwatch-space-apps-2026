"""Reproducible real-data technical probe; not a verified water case."""
import json
import os
from pathlib import Path
import resource
import sys
import time
from dotenv import load_dotenv
from sarwatch.catalog import compatible_pairs
from sarwatch.gcov import inspect_window
from sarwatch.comparison import compare
from shapely.geometry import shape, box


def main():
    load_dotenv(override=False)
    catalog=json.loads(Path('work/balkhash.json').read_text())
    scenes=[next(s for s in catalog['scenes'] if date in s['id'])
            for date in ('20261009T000101','20261021T000101')]
    bounds=[74.48,46.185,74.52,46.215]
    if not compatible_pairs(scenes) or not all(shape(s['geometry']).covers(box(*bounds)) for s in scenes):
        raise ValueError('Probe pair metadata/coverage check failed')
    token=os.environ.get('EARTHDATA_TOKEN','')
    started=time.monotonic(); remaining=100_000_000; reports=[]
    out=Path('work/probe'); out.mkdir(parents=True,exist_ok=True)
    for label,scene in zip(('before','after'),scenes):
        report=inspect_window(scene['url'],token,bounds,out/f'{label}.tif',budget=remaining,seconds=900-(time.monotonic()-started))
        report.update(source_id=scene['id'],observed_at=scene['start'],maturity=scene['maturity'],crid=scene['crid'])
        reports.append(report); remaining-=report['transferred_bytes']
        print(json.dumps({'phase':label,'transferred_bytes':report['transferred_bytes'],'elapsed_seconds':report['elapsed_seconds']}),flush=True)
    result=compare(out/'before.tif',out/'after.tif',out/'comparison')
    rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    result.update(observations=reports,total_transferred_bytes=100_000_000-remaining,
                  total_seconds=round(time.monotonic()-started,3),
                  peak_rss_mb=round(rss/(1024**2 if sys.platform=='darwin' else 1024),1))
    (out/'report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='observations'},ensure_ascii=False))


if __name__=='__main__': main()
