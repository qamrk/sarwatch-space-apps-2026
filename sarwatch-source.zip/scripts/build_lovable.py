"""Package the React client for Lovable's Upload code import."""
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
API = 'https://sarwatch-space-apps-2026.onrender.com'


def main():
    frontend = ROOT/'frontend'
    output = ROOT/'release'/'sarwatch-lovable.zip'
    output.parent.mkdir(exist_ok=True)
    files = {'index.html', 'package.json', 'pnpm-lock.yaml', 'pnpm-workspace.yaml', 'tsconfig.json', 'vite.config.ts', 'public/favicon.png'}
    files.update(path.relative_to(frontend).as_posix() for path in (frontend/'src').rglob('*')
                 if path.is_file() and path.suffix in {'.ts', '.tsx', '.css', '.json'})
    with ZipFile(output, 'w', ZIP_DEFLATED) as archive:
        for name in sorted(files):
            if name == 'src/main.tsx':
                source = (frontend/name).read_text(encoding='utf-8')
                placeholder = "import.meta.env.VITE_API_URL || ''"
                if source.count(placeholder) != 1:
                    raise ValueError('Frontend API default not found')
                archive.writestr(name, source.replace(placeholder, f"import.meta.env.VITE_API_URL || '{API}'"))
            else:
                archive.write(frontend/name, name)
    print(output)


if __name__ == '__main__':
    main()
