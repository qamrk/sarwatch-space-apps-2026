"""Deterministic public release with explicit paths, never a workspace dump."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT=Path(__file__).resolve().parent.parent
PUBLIC_ROOT_FILES=['README.md','DEPLOY.md','CANDIDATE_AUDIT.md','Dockerfile','.dockerignore','.gitignore','render.yaml',
                   'pyproject.toml','requirements.lock.txt','config.env.example','Start-SARWatch.command','SARWatch.html']


def main():
    out=ROOT/'release';out.mkdir(exist_ok=True)
    files=[ROOT/p for p in PUBLIC_ROOT_FILES]
    allowed={'.py','.ttf','.txt','.md','.json','.png','.pdf','.geojson'}
    for base in ['sarwatch','scripts','tests','cases']:
        files.extend(p for p in (ROOT/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and (p.suffix in allowed or p.name.startswith('LICENSE')) and not p.name.startswith('.'))
    for name in ['package.json','pnpm-lock.yaml','pnpm-workspace.yaml','tsconfig.json','vite.config.ts','index.html']:
        files.append(ROOT/'frontend'/name)
    files.append(ROOT/'frontend/public/favicon.png')
    for base in ['frontend/src','frontend/dist']:
        # Case assets already live under cases/ and FastAPI serves them there.
        # Avoid a second compressed copy in the browser-upload source ZIP.
        files.extend(p for p in (ROOT/base).rglob('*') if p.is_file()
                     and not (p.is_relative_to(ROOT/'frontend/dist/cases') and p.name!='index.json'))
    target=out/'sarwatch-source.zip'
    forbidden={'data','work','outputs','.git','.venv','node_modules','.pnpm-store','release','.codex','.agents'}
    seen=set()
    with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for path in sorted(set(files)):
            rel=path.relative_to(ROOT)
            if not path.is_file():raise ValueError(f'Missing public release input: {rel}')
            if any(part in forbidden or part=='.env' or part.startswith('.env.') for part in rel.parts):raise ValueError(f'Private release input: {rel}')
            if path.is_symlink():raise ValueError(f'Symlink release input: {rel}')
            name=rel.as_posix()
            if name in seen:raise ValueError('Duplicate archive path')
            seen.add(name);info=zipfile.ZipInfo(name,date_time=(2026,11,14,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=((0o755 if path.suffix=='.command' else 0o644)|0o100000)<<16
            archive.writestr(info,path.read_bytes())
    for name in ['Dockerfile','.dockerignore','render.yaml','README.md']:
        shutil.copyfile(ROOT/name,out/name)
    result={'archive':target.name,'files':len(seen),'bytes':target.stat().st_size,'sha256':hashlib.sha256(target.read_bytes()).hexdigest()}
    (out/'release.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))


if __name__=='__main__':main()
