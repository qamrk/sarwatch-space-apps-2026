"""Package an already completed real calculation; never synthesize observations."""
import argparse
import json
import shutil
from pathlib import Path
from sarwatch.report import create_report
from sarwatch.exports import render_preview

ROOT=Path(__file__).resolve().parent.parent


def package(preset_id,calculation):
    presets=json.loads((ROOT/'sarwatch/assets/presets.json').read_text(encoding='utf-8'))['presets']
    preset=next(p for p in presets if p['id']==preset_id)
    calculation=Path(calculation);result=json.loads((calculation/'result.json').read_text())
    assert [s['id'] for s in result['sources']]==[preset['before_id'],preset['after_id']]
    assert result['requested_side_km']==preset['side_km']
    assert result['theme']==preset.get('theme','water')
    if 'channel' in preset:
        assert all(o['channel']==preset['channel'] for o in result['observations'])
    assert 0<result['comparison']['finite_overlap_fraction']<=1
    # Only source/derived, reviewed outputs enter the public case.
    folder=ROOT/'cases'/preset_id;folder.mkdir(parents=True,exist_ok=True)
    for layer in result['layers']:
        shutil.copyfile(calculation/'mapping'/layer['file'],folder/layer['file'])
    if (calculation/'water/water.geojson').is_file():shutil.copyfile(calculation/'water/water.geojson',folder/'water.geojson')
    water=result['water'].get('status')=='experimental'
    manifest={**result,'id':preset_id,'title':preset['title'],'story':preset['note'],
        'metrics':result['water'] if water else result['comparison'],
        'previews':{'ru':'preview-ru.png','en':'preview-en.png'},'ready_for_demo':True,
        'validation_status':'real_nisar_pair_with_documented_context_not_independently_validated',
        'event_sources':[{'title':preset.get('source_title','Event context / catalogue audit'),'url':preset['source_url']}],
        'attribution':['NASA/JPL/ASF NISAR '+preset['maturity']],
        'interpretation':preset.get('interpretation') or {
            'ru':'Экспериментальная оценка открытой воды по NISAR.' if water else 'Сравнение радарного сигнала NISAR. Надёжно выделить открытую воду не удалось.',
            'en':'Experimental open-water estimate from NISAR.' if water else 'NISAR radar comparison. Open water could not be separated reliably.'}}
    # Strip runtime URLs; the static/public API assigns its own paths.
    for layer in manifest['layers']:layer.pop('url',None)
    for lang in ('ru','en'):
        render_preview(manifest,folder,folder/f'preview-{lang}.png',lang,prepared=True)
        create_report(manifest,folder,folder/f'report-{lang}.pdf',lang,prepared=True)
    (folder/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return {'id':preset_id,'side_km':preset['side_km'],'water':water,'seconds':result['elapsed_seconds'],'bytes':result['transferred_bytes']}


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('preset_id');parser.add_argument('calculation');args=parser.parse_args()
    print(json.dumps(package(args.preset_id,args.calculation)))
