import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createRoot } from 'react-dom/client';
import L from 'leaflet';
import { WeatherContext } from './WeatherContext';
import { kazakh } from './kazakh';
import { Radar, ArrowUpRight, Layers, Droplets, Trees, Flame, Wheat, LocateFixed, Download, Search, ChevronRight, Info, LoaderCircle, Satellite, MapPin, RefreshCw } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import './style.css';

const languages = ['en', 'ru', 'kk'] as const;
type Lang = typeof languages[number];
type Localized = Partial<Record<Lang, string>> | string;
type BBox = [number, number, number, number];
const OVERVIEW_BOUNDS: BBox = [46, 40, 88, 56];
type Theme = 'water' | 'forest' | 'fire' | 'agri_fire';
type Channel = 'auto' | 'HHHH' | 'HVHV' | 'VVVV' | 'VHVH';
type Sensor = 'nisar' | 'landsat' | 'modis';
type SourceChoice = Sensor | 'auto';
type Basemap = 'default' | 'satellite';
const AREA_SIZES = [10, 30, 50, 75, 100];
const LANDSAT_START = '1982-08-22';
const NISAR_START = '2025-10-01';
type Layer = { id: string; file?: string; url?: string; bounds: BBox; label?: Localized };
type Scene = { id: string; start: string; crid?: string; maturity?: string; track?: string; frame?: string; platform?: string; browse_preview_url?:string;
  granule_id?:string; collection_id?:string; url?:string; source_url?:string; scene_ids?:string[]; previews?:Record<string,string>; browse?:string[]; browse_urls?:string[] };
type Preset = {id:string;title:Localized;note:Localized;theme?:Theme;channel?:Channel;sensor?:Sensor;lat:number;lon:number;side_km:number;start:string;end:string;maturity?:string;before_id:string;after_id:string;source_url:string;};
type Stats = {
  water_before_km2?: number; water_after_km2?: number; water_gain_km2?: number; water_loss_km2?: number;
  comparable_area_km2?: number; threshold_db?: number; status?: string; reason?: string; channel?: string;
  pixel_area_m2?: number; potential_flood_km2?: number;
};
type Comparison = { median_delta_db?: number; mean_delta_db?: number; p95_absolute_delta_db?: number; comparable_pixels?: number; finite_overlap_fraction?: number };
type Flood = {
  status: 'experimental' | 'unavailable' | 'not_requested'; candidate_area_km2?: number; assessed_fraction?: number; reason?: string;
  sources?: { name: string; url?: string; attribution?: string }[]; limitations?: string[];
};
type ReferenceCheck = { reference_id?: string; reference_time?: string; iou_vs_reference?: number; gate_passed?: boolean };
type Case = {
  id: string; title: Localized; theme?: Theme; sensor?:Sensor; story?: Localized; description?: Localized; summary?: Localized;
  sources: Scene[]; metrics?: Stats & Comparison; layers: Layer[]; previews?: Partial<Record<Lang, string>>;
  interpretation?: Localized; ready_for_demo?: boolean; validation_status?: string;
  reference_checks?: Record<string, ReferenceCheck>; attribution?: string[]; bbox?: BBox;
  comparison?: Comparison; classification_status?: string; flood?: Flood;
  observations?:{channel?:string;pixel_spacing_m?:number[]}[];event_sources?:{title:string;url:string}[];
};
type Catalog = { scenes: Scene[]; pairs: { before: string; after: string }[]; series?: string[]; sensor?:Sensor; potentially_truncated?: boolean; potentially_incomplete?: boolean; truncated?: boolean };
type Health = { status: string; data_access_configured: boolean; analysis_busy: boolean; area_sizes_km?:number[]; max_side_km?:number; max_dates?: number; landsat_start?:string; nisar_start?:string };
type Result = { layers: Layer[]; sources: Scene[]; water?: Stats; flood?: Flood; comparison?: Comparison; theme?: Theme; sensor?:Sensor; total_area_km2?:number; transferred_bytes?: number; elapsed_seconds?: number; attribution?:string[]; observations?: { channel?: string; pixel_spacing_m?: number[] }[] };
type Assets = { comparison?: string; reports?: Partial<Record<Lang, string>> };
type Step = { result: Result; assets: Assets };
type Job = { id: string; status: 'waiting' | 'processing' | 'completed' | 'failed'; queue_position?:number; error?: string; result?: Result; assets?: Assets; sequence?: {steps: Step[]}; progress?: {completed: number; total: number} };

const API = (import.meta.env.VITE_API_URL || 'https://sarwatch-space-apps-2026.onrender.com').replace(/\/$/, '');
const ESRI_TOPO_TILES = 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer/tile/{z}/{y}/{x}';
const ESRI_ROOT = 'https://services.arcgisonline.com/ArcGIS/rest/services/';
const ESRI_TOPO_ATTRIBUTION = '<a href="https://www.arcgis.com/home/item.html?id=6e850093c837475e8c23d905ac43b7d0">Esri</a>, HERE, Garmin, Intermap, increment P Corp., GEBCO, USGS, FAO, NPS, NRCAN, GeoBase, IGN, Kadaster NL, Ordnance Survey, Esri Japan, METI, Esri China (Hong Kong), © OpenStreetMap contributors, and the GIS User Community';
const themes: Record<Theme, typeof Droplets> = { water: Droplets, forest: Trees, fire: Flame, agri_fire: Wheat };
const text = {
  ru: {
    tag: 'НАБЛЮДЕНИЯ ЗЕМЛИ', prototype: 'Исследовательский прототип', title: 'Земля меняется.\nПосмотрим, где.',
    intro: 'Сравнивайте снимки NISAR и изучайте изменения водоёмов по архиву Landsat.', ready: 'Готовые примеры', custom: 'Новый анализ',
    sensor: 'Источник снимков', autoSensor: 'Автоматически по датам', archive: 'Landsat · архив с 1982 года',
    archiveHint: 'Поиск начинается с 32 дней от каждой даты и при необходимости расширяется. В списке указаны фактические даты съёмки.',
    archiveAuto: 'Для этой даты поиск начнётся с архива Landsat. Если подходящей пары нет, сайт проверит NASA MODIS.',
    dateInvalid: 'Введите разные даты в формате ГГГГ-ММ-ДД или ДД.ММ.ГГГГ. Архив начинается 22 августа 1982 года, обзор MODIS — 24 февраля 2000 года.',
    dateBefore: 'Дата «До»', dateAfter: 'Дата «После»',
    overview: 'NASA MODIS · обзор с 2000 года',
    overviewHint: 'Цветные снимки для визуального сравнения. На снимках возможны облака и пропуски.',
    opticalImages: 'Цветные снимки Landsat с маской облаков и теней.',
    visualComparison: 'Спутниковые снимки',
    scenePreview: 'Изображение всей сцены',
    sceneData: 'Исходный файл HDF5',
    sceneSource: 'Карточка сцены NASA Earthdata',
    archiveResult: 'Оценка по оптическим снимкам Landsat. Площади рассчитаны по ясным пикселям, общим для обеих дат.',
    archiveMethod: 'Landsat Collection 2 Level-2. Маска QA_PIXEL исключает облака, тени, снег и пропуски. Для выделения воды флаг Water дополнен проверкой отражения в инфракрасном канале.',
    archiveNote: 'Солончаки, мелководье и смешанные береговые пиксели могут классифицироваться ошибочно.',
    archiveEmpty: 'Для этого участка и дат архив не вернул пару снимков. Укажите ближайшие даты или уменьшите область.',
    comparable: 'Ясная область в обе даты',
    prepared: 'ПОДГОТОВЛЕННЫЕ ПРИМЕРЫ', reviewed: 'Сверено с Sentinel-2', realCase: 'Реальные наблюдения', dates: 'ДАТЫ НАБЛЮДЕНИЙ · UTC',
    before: 'До', after: 'После', water: 'Вода', forest: 'Леса', fire: 'Пожары', agri_fire: 'Поля / пожары',
    area: 'ОБЛАСТЬ АНАЛИЗА', click: 'Нажмите на карту, чтобы выбрать центр области.', side: 'Сторона участка, до км',
    presets:'Проверенные места и даты',presetHint:'Для каждого места подобрана пара снимков.',nominalArea:'Площадь выбранного квадрата',grid:'Сетка анализа',coarse:'Большие области анализируются на укрупнённой сетке. Мелкие объекты могут быть потеряны.',browse:'Обзор ASF',browseHint:'Превью всей сцены. Только для просмотра; площади по нему не считаются.',
    start: 'С даты', end: 'По дату', maturity: 'Зрелость данных', find: 'Найти наблюдения', finding: 'Ищем наблюдения…',
    pair: 'Совместимая пара', run: 'Запустить анализ', running: 'Обрабатываем наблюдения…', waiting: 'Задание принято',
    wait: 'Чтение новых наблюдений может занять несколько минут.',
    queued: 'Позиция в очереди',
    mapLayers: 'Подложка карты', defaultMap: 'Обычная', satellite: 'Спутник', interactiveMap: 'Интерактивная карта',
    noPairs: 'Не нашлось двух совместимых снимков NISAR с полным покрытием участка. Попробуйте уменьшить область или изменить даты.',
    nisarAuto: 'Автоматический поиск выбрал NISAR. Если совместимых снимков нет, можно отдельно запустить оптический поиск.',
    nisarSeriesEmpty: 'Не нашлось совместимой серии NISAR с полным покрытием каждой даты. Попробуйте изменить даты или уменьшить область.',
    pairNote: 'Совпадение метаданных ещё не подтверждает качество пикселей. Оно проверяется при обработке.',
    partial: 'Каталог достиг лимита выдачи. Сузьте период, чтобы не пропустить наблюдения.', layer: 'Слой воды',
    potential_flood: 'Возможное затопление', floodNote: 'Кандидатный слой требует проверки: появление водного класса само по себе не подтверждает наводнение.',
    floodScreen: 'ПРЕДВАРИТЕЛЬНЫЙ ОТБОР ВОЗМОЖНОГО ЗАТОПЛЕНИЯ', floodArea: 'Кандидатная площадь', floodAssessed: 'Область с достаточными вспомогательными данными',
    floodUnavailable: 'Предварительный отбор затопления недоступен для этого расчёта.', floodSources: 'Постоянная вода и рельеф',
    opacity: 'Прозрачность', fit: 'К области', mapTip: 'Выберите область на карте', coverage: 'ВОДА В ВЫБРАННОЙ ОБЛАСТИ',
    prior: 'Первая дата', later: 'Вторая дата', units: 'км²', stable: 'Вода в обе даты', gain: 'Появление водного класса', loss: 'Исчезновение водного класса',
    note: 'Малые различия границы могут отражать шум и смешанные пиксели. Это не подтверждённое затопление.',
    sources: 'Источники и метод', waterMethod: 'NISAR GCOV. Экспериментальная классификация открытой воды: маска качества, медианный фильтр и общий порог. Сверка одного примера не устанавливает универсальную точность.',
    signalMethod: 'NISAR GCOV: сопоставимые наблюдения, маска качества и разность обратного рассеяния в dB. Причины изменения сигнала требуют отдельной проверки.',
    download: 'Скачать PNG', pdf: 'Отчёт PDF', delta: 'Разность',
    deltaHint: 'Разность dB: красный — рост, синий — снижение сигнала, белый — около нуля.', empty: 'Выберите область и найдите доступные наблюдения.',
    unverified: 'Предварительный результат — без независимой сверки', unavailable: 'Воду надёжно разделить не удалось. Доступно сравнение радарного сигнала.',
    data: 'Реальные спутниковые данные', method: 'Каждый пример содержит даты наблюдений, источники и ограничения интерпретации.',
    network: 'Сервис не отвечает. Проверьте подключение или повторите запрос.', experimental: 'Экспериментальная оценка', radar: 'Радарный сигнал',
    noWaterMetrics: 'Показываем изменения радарного сигнала. Площадь пожара, вырубки и ущерб автоматически не определяются.',
    newArea: 'Новая область', serviceChecking: 'Проверяем сервис расчётов…', serviceReady: 'Сервис расчётов доступен',
    serviceBusy: 'Сервис выполняет расчёты. Можно отправить новый анализ в очередь.', serviceMissing: 'Доступ к спутниковым данным на сервисе не настроен. Готовые примеры доступны.',
    serviceOffline: 'Сервис расчётов недоступен. Готовые примеры продолжают работать.', refresh: 'Обновить статус',
    assetsError: 'Не удалось загрузить подготовленные примеры. Обновите страницу.', noCases: 'Готовые примеры появятся позже.',
    noCasesHint: 'Пока можно выбрать место и даты в разделе «Новый анализ».',
    invalidArea: 'Выберите участок между 80° ю. ш. и 84° с. ш., без пересечения линии смены дат.',
    median: 'Медиана разности', overlap: 'Общие пиксели', measured: 'Расчёт', seconds: 'с', reference: 'Оптическая сверка этого примера',
    noReference: 'Независимая сверка этого расчёта не выполнена. Проверка подготовленных примеров к нему не относится.',
    retryPoll: 'Связь с сервисом прервалась. Повторяем проверку задания…',
    reload: 'Обновить страницу', crash: 'Интерфейс не удалось отобразить. Обновите страницу; результаты можно повторно получить с сервиса.',
    retryResult: 'Проверить результат', job: 'Задание', loading: 'Загружаем примеры…',
    addDate: 'Добавить дату', removeDate: 'Убрать дату', dateLabel: 'Дата', interval: 'Интервал сравнения',
    seriesEmpty: 'Для всех дат не нашлось совместимых снимков из одного источника. Попробуйте изменить даты или спутник.',
    seriesFound: 'Фактические даты съёмки. Анализ сравнит соседние снимки.', queueFull: 'Очередь заполнена. Попробуйте чуть позже.',
    requestFailed: 'Задание не удалось выполнить. Проверьте даты и участок и повторите попытку.', expired: 'Задание не найдено или срок хранения истёк.',
    eventSource: 'Источник о событии', zoomIn: 'Приблизить', zoomOut: 'Отдалить',
  },
  en: {
    tag: 'EARTH OBSERVATIONS', prototype: 'Research prototype', title: 'Earth is changing.\nLet’s see where.',
    intro: 'Compare NISAR radar observations and explore water changes in the Landsat archive.', ready: 'Prepared cases', custom: 'New analysis',
    sensor: 'Satellite source', autoSensor: 'Automatic by date', archive: 'Landsat · archive since 1982',
    archiveHint: 'Search starts within 32 days of each date and expands as needed. The list shows actual acquisition dates.',
    archiveAuto: 'This date starts with Landsat. If a pair is unavailable, the site checks NASA MODIS.',
    dateInvalid: 'Enter distinct dates as YYYY-MM-DD or DD.MM.YYYY. Landsat starts on August 22, 1982 and MODIS on February 24, 2000.',
    dateBefore: 'Before date', dateAfter: 'After date',
    overview: 'NASA MODIS · overview since 2000',
    overviewHint: 'True colour imagery for visual comparison. Clouds and gaps may be present.',
    opticalImages: 'Landsat true colour imagery with cloud and shadow masking.',
    visualComparison: 'Satellite images',
    scenePreview: 'Full-scene preview',
    sceneData: 'Original HDF5 file',
    sceneSource: 'NASA Earthdata scene record',
    archiveResult: 'Optical Landsat estimate. Areas use clear pixels shared by both dates.',
    archiveMethod: 'Landsat Collection 2 Level-2. QA_PIXEL excludes clouds, shadows, snow and gaps. Water detection combines the Water flag with shortwave infrared reflectance.',
    archiveNote: 'Salt flats, shallow water and mixed shoreline pixels can be misclassified.',
    archiveEmpty: 'The archive did not return an image pair for this area and dates. Try nearby dates or a smaller area.',
    comparable: 'Clear coverage on both dates',
    prepared: 'PREPARED CASES', reviewed: 'Compared with Sentinel-2', realCase: 'Real observations', dates: 'OBSERVATION DATES · UTC',
    before: 'Before', after: 'After', water: 'Water', forest: 'Forests', fire: 'Wildfires', agri_fire: 'Fields / fires',
    area: 'AREA OF INTEREST', click: 'Click the map to choose the centre of your area.', side: 'Side length, up to km',
    presets:'Checked locations and dates',presetHint:'Each location has an observation pair.',nominalArea:'Selected square area',grid:'Analysis grid',coarse:'Larger areas use a coarser analysis grid. Small features may be lost.',browse:'ASF overview',browseHint:'Whole-scene preview for viewing; never used to measure areas.',
    start: 'Start date', end: 'End date', maturity: 'Data maturity', find: 'Find observations', finding: 'Searching observations…',
    pair: 'Compatible pair', run: 'Run analysis', running: 'Processing observations…', waiting: 'Analysis accepted',
    wait: 'Reading new observations may take several minutes.',
    queued: 'Queue position',
    mapLayers: 'Map basemap', defaultMap: 'Default', satellite: 'Satellite', interactiveMap: 'Interactive map',
    noPairs: 'No two compatible NISAR images covered the entire area. Try a smaller area or different dates.',
    nisarAuto: 'Automatic search selected NISAR. You can search optical sources separately if compatible images are unavailable.',
    nisarSeriesEmpty: 'No compatible NISAR series covered the entire area at every date. Try changing the dates or reducing the area.',
    pairNote: 'Matching metadata does not establish pixel quality. That is checked during processing.',
    partial: 'The catalogue reached its result limit. Narrow the dates to avoid missing observations.', layer: 'Water layer',
    potential_flood: 'Potential flooding', floodNote: 'This candidate layer needs review: water-class gain alone does not establish a flood.',
    floodScreen: 'PRELIMINARY POTENTIAL-FLOOD SCREENING', floodArea: 'Candidate area', floodAssessed: 'Area with sufficient auxiliary data',
    floodUnavailable: 'Potential-flood screening is unavailable for this analysis.', floodSources: 'Permanent water and terrain',
    opacity: 'Opacity', fit: 'Fit area', mapTip: 'Choose an area on the map', coverage: 'WATER IN THE SELECTED AREA',
    prior: 'First date', later: 'Second date', units: 'km²', stable: 'Water on both dates', gain: 'Water class gain', loss: 'Water class loss',
    note: 'Small boundary differences may reflect noise and mixed pixels. This is not confirmed flooding.',
    sources: 'Sources and method', waterMethod: 'NISAR GCOV. Experimental open-water classification: quality mask, median filter and a pooled threshold. Checking one case does not establish general accuracy.',
    signalMethod: 'NISAR GCOV: comparable observations, quality mask and backscatter difference in dB. Causes of signal changes need a separate check.',
    download: 'Download PNG', pdf: 'PDF report', delta: 'Difference',
    deltaHint: 'Difference in dB: red — signal increase, blue — decrease, white — near zero.', empty: 'Select an area and search available observations.',
    unverified: 'Preliminary result — no independent reference check', unavailable: 'Water could not be reliably separated. Radar intensity comparison is available.',
    data: 'Real satellite observations', method: 'Every case includes observation dates, sources and interpretation limits.',
    network: 'The service is not responding. Check connectivity or try again.', experimental: 'Experimental estimate', radar: 'Radar intensity',
    noWaterMetrics: 'This shows radar intensity changes. Burned area, forest loss and damage are not inferred automatically.',
    newArea: 'New area', serviceChecking: 'Checking analysis service…', serviceReady: 'Analysis service is available',
    serviceBusy: 'Analyses are running. You can submit another job to the queue.', serviceMissing: 'Satellite data access is not configured on the service. Prepared cases remain available.',
    serviceOffline: 'Analysis service is unavailable. Prepared cases continue to work.', refresh: 'Refresh status',
    assetsError: 'Prepared cases could not be loaded. Refresh the page.', noCases: 'Prepared cases will be added later.',
    noCasesHint: 'Choose a location and dates in New analysis to get started.',
    invalidArea: 'Choose a site between 80° S and 84° N without crossing the date line.',
    median: 'Median difference', overlap: 'Common pixels', measured: 'Analysis', seconds: 's', reference: 'Optical comparison for this case',
    noReference: 'This analysis has not been independently checked. Assessments of prepared cases do not apply.',
    retryPoll: 'Connection interrupted. Retrying the analysis status…',
    reload: 'Refresh page', crash: 'The interface could not be displayed. Refresh the page; your results can be retrieved from the service.',
    retryResult: 'Check result', job: 'Job', loading: 'Loading cases…',
    addDate: 'Add date', removeDate: 'Remove date', dateLabel: 'Date', interval: 'Comparison interval',
    seriesEmpty: 'No single source had compatible images for every date. Try changing the dates or satellite.',
    seriesFound: 'Actual acquisition dates. Analysis compares consecutive images.', queueFull: 'The queue is full. Try again shortly.',
    requestFailed: 'The job could not be completed. Check the dates and area and try again.', expired: 'The job has expired or could not be found.',
    eventSource: 'Event source', zoomIn: 'Zoom in', zoomOut: 'Zoom out',
  },
  kk: kazakh,
};

class ApiError extends Error {
  constructor(message: string, public status: number) { super(message); }
}
async function api<T>(path: string, signal?: AbortSignal, init?: RequestInit): Promise<T> {
  const r = await fetch(API + path, { ...init, signal });
  const body = await r.json().catch(() => null);
  if (!r.ok) {
    const detail = typeof body?.detail === 'string' ? body.detail
      : Array.isArray(body?.detail) ? body.detail.map((d: { msg?: string; loc?: string[] }) => `${d.loc?.slice(1).join('.') || 'Request'}: ${d.msg || 'Invalid value'}`).join('; ')
      : `HTTP ${r.status}`;
    throw new ApiError(detail, r.status);
  }
  if (!body) throw new ApiError('Invalid response from service', r.status);
  return body as T;
}
function local(value: Localized | undefined, lang: Lang) { return typeof value === 'string' ? value : value?.[lang] || value?.ru || value?.en || ''; }
function message(error: unknown, t: typeof text[Lang]) {
  if (!(error instanceof ApiError)) return t.network;
  if (error.status === 429) return t.queueFull;
  if (error.status === 404) return t.expired;
  return error.status < 500 ? t.requestFailed : t.network;
}
function isAbort(error: unknown) { return error instanceof DOMException && error.name === 'AbortError'; }
function square(lat: number, lon: number, side: number): BBox {
  const dy = side * 1000 / 112000 / 2;
  const closestLatitude = Math.max(0, Math.abs(lat) - dy);
  const dx = dy / Math.cos(closestLatitude * Math.PI / 180);
  return [lon - dx, lat - dy, lon + dx, lat + dy];
}
function validArea(b: BBox) { return b.every(Number.isFinite) && b[0] >= -180 && b[2] <= 180 && b[1] >= -80 && b[3] <= 84; }
const bounds = (b: BBox): L.LatLngBoundsExpression => [[b[1], b[0]], [b[3], b[2]]];
const date = (s?: string) => s ? s.slice(0, 10).split('-').reverse().join('.') : '—';

function sceneDate(value: string) {
  const trimmed = value.trim();
  const localDate = /^(\d{2})\.(\d{2})\.(\d{4})$/.exec(trimmed);
  const iso = localDate ? [localDate[3], localDate[2], localDate[1]].join('-') : trimmed;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return '';
  const stamp = new Date(iso + 'T00:00:00Z');
  return Number.isFinite(stamp.valueOf()) && stamp.toISOString().slice(0, 10) === iso ? iso : '';
}

function sceneLinks(scene: Scene, sensor: Sensor, t: typeof text[Lang]): {label:string;href:string;title?:string}[] {
  if (sensor === 'modis') return scene.source_url ? [{label:'NASA Worldview', href:scene.source_url}] : [];
  if (sensor === 'landsat') {
    return (scene.scene_ids ?? [scene.id]).flatMap(id => {
      const catalog = 'https://planetarycomputer.microsoft.com/api/stac/v1/collections/landsat-c2-l2/items/';
      return [{label:id,href:catalog + encodeURIComponent(id)},
        ...(scene.previews?.[id] ? [{label:t.scenePreview,href:scene.previews[id]}] : [])];
    });
  }
  const query = new URLSearchParams();
  if (scene.collection_id) {
    query.set('p', scene.collection_id);
    query.set('pg[0][id]', scene.id);
  } else {
    query.set('q', scene.id);
  }
  const links: {label:string;href:string;title?:string}[] = [
    {label:scene.id,href:'https://search.earthdata.nasa.gov/search/granules?' + query.toString(),title:t.sceneSource},
  ];
  const browse = (scene.browse_urls ?? scene.browse ?? []).find(url => url.endsWith('.png') && !url.endsWith('_thumbnail.png'));
  if (browse) links.push({label:t.scenePreview,href:assetUrl(`/api/scenes/${encodeURIComponent(scene.id)}/browse.png`)});
  if (scene.url) links.push({label:t.sceneData,href:scene.url});
  return links;
}
const finite = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);
const assetUrl = (url: string) => /^https?:\/\//.test(url) ? url : API + url;
const opticalChecked = (c: Case | null) => c?.validation_status === 'case_compared_with_optical_reference'
  || (!!c?.reference_checks && Object.values(c.reference_checks).length >= 2 && Object.values(c.reference_checks).every(r => r.gate_passed));

function MapView({ layers, epoch, overlay, opacity, area, showArea, selectable, onSelect, fit, lang, basemap }: {
  layers: Layer[]; epoch: string; overlay: string; opacity: number; area: BBox; selectable: boolean;
  onSelect: (lat: number, lon: number) => void; fit: number; lang: Lang; showArea: boolean; basemap: Basemap;
}) {
  const node = useRef<HTMLDivElement>(null), map = useRef<L.Map | null>(null);
  const raster = useRef<L.LayerGroup | null>(null), rectangle = useRef<L.Rectangle | null>(null);
  const zoomControl = useRef<L.Control.Zoom | null>(null);
  const action = useRef({ selectable, onSelect }), areaRef = useRef(area);
  action.current = { selectable, onSelect }; areaRef.current = area;
  useEffect(() => {
    if (!node.current) return;
    const m = L.map(node.current, { zoomControl: false }).setView([48, 67], 5);
    map.current = m;
    const labelsPane = m.createPane('satellite-labels');
    labelsPane.style.zIndex = '425';
    labelsPane.style.pointerEvents = 'none';
    L.control.scale({ imperial: false, position: 'bottomleft' }).addTo(m);
    raster.current = L.layerGroup().addTo(m);
    m.on('click', e => { if (action.current.selectable) { const p = e.latlng.wrap(); action.current.onSelect(p.lat, p.lng); } });
    const resize = new ResizeObserver(() => {
      m.invalidateSize();
      if (node.current && node.current.clientHeight > 0) m.fitBounds(bounds(areaRef.current), { padding: [45, 45], maxZoom: 14, animate: false });
    });
    resize.observe(node.current);
    return () => { resize.disconnect(); m.remove(); map.current = null; raster.current = null; };
  }, []);
  useEffect(() => {
    const m = map.current;
    if (!m) return;
    zoomControl.current = L.control.zoom({position:'bottomleft', zoomInTitle:text[lang].zoomIn, zoomOutTitle:text[lang].zoomOut}).addTo(m);
    return () => { zoomControl.current?.remove(); zoomControl.current = null; };
  }, [lang]);
  useEffect(() => {
    const m = map.current;
    if (!m) return;
    const presets = {
      default: {
        url: import.meta.env.VITE_TILE_URL || ESRI_TOPO_TILES,
        attribution: import.meta.env.VITE_TILE_URL
          ? (import.meta.env.VITE_TILE_ATTRIBUTION || '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors')
          : ESRI_TOPO_ATTRIBUTION,
      },
      satellite: {
        url: ESRI_ROOT + 'World_Imagery/MapServer/tile/{z}/{y}/{x}',
        attribution: 'Esri, Vantor, Earthstar Geographics, HERE, Garmin, FAO, NOAA, USGS, © OpenStreetMap contributors, and the GIS User Community',
      },
    };
    const layer = L.tileLayer(presets[basemap].url, {maxZoom:19,
      attribution:presets[basemap].attribution}).addTo(m);
    let labels: L.Layer | undefined;
    let active = true;
    if (basemap === 'satellite') {
      void import('./satelliteLabels').then(({satelliteLabels}) => {
        if (!active) return;
        labels = satelliteLabels('satellite-labels');
        labels.addTo(m);
      }).catch(() => labels?.remove());
    }
    return () => { active = false; labels?.remove(); layer.remove(); };
  }, [basemap]);
  useEffect(() => {
    const group = raster.current; if (!group) return;
    group.clearLayers();
    const base = layers.find(l => l.id === epoch);
    if (base?.url) L.imageOverlay(base.url, bounds(base.bounds), { opacity: .94, alt: epoch }).addTo(group);
    const mask = layers.find(l => l.id === overlay);
    if (mask?.url) L.imageOverlay(mask.url, bounds(mask.bounds), { opacity, alt: overlay }).addTo(group);
  }, [layers, epoch, overlay, opacity]);
  useEffect(() => {
    const m = map.current; if (!m) return;
    rectangle.current?.remove();
    rectangle.current = null;
    if (!showArea) return;
    rectangle.current = L.rectangle(bounds(area), { color: selectable ? '#f3a141' : '#18a899', weight: 1.5, fill: false, dashArray: '5 6', interactive: false }).addTo(m);
  }, [area, selectable, showArea]);
  useEffect(() => { map.current?.fitBounds(bounds(areaRef.current), { padding: [45, 45], maxZoom: 14, animate:false }); }, [fit]);
  return <div className={'map ' + (selectable ? 'selectable' : '')} ref={node} aria-label={text[lang].interactiveMap} />;
}

function App() {
  const [lang, setLang] = useState<Lang>(() => {
    const saved = localStorage.getItem('sarwatch-language');
    return languages.find(language => language === saved) ?? 'en';
  }), [mode, setMode] = useState<'case' | 'new'>('case');
  const [cases, setCases] = useState<Case[]>([]), [current, setCurrent] = useState<Case | null>(null), [loadingCases, setLoadingCases] = useState(true);
  const [presets,setPresets]=useState<Preset[]>([]),[presetId,setPresetId]=useState('');
  const [epoch, setEpoch] = useState('after'), [overlay, setOverlay] = useState('water'), [opacity, setOpacity] = useState(.85), [fit, setFit] = useState(1);
  const [area, setArea] = useState<BBox>(() => square(48, 67, 30)), [center, setCenter] = useState<[number, number]>([48, 67]), [side, setSide] = useState(30);
  const [theme, setTheme] = useState<Theme>('water'), [start, setStart] = useState('2026-06-17'), [end, setEnd] = useState(new Date().toISOString().slice(0,10)), [maturity, setMaturity] = useState('PROVISIONAL');
  const [extraDates, setExtraDates] = useState<string[]>([]), [stepIndex, setStepIndex] = useState(0);
  const [sourceChoice, setSourceChoice] = useState<SourceChoice>('auto');
  const [basemap, setBasemap] = useState<Basemap>('default');
  const [catalogNote, setCatalogNote] = useState('');
  const [catalog, setCatalog] = useState<Catalog | null>(null), [pair, setPair] = useState(0), [searching, setSearching] = useState(false);
  const [busy, setBusy] = useState(false), [error, setError] = useState(''), [job, setJob] = useState<Job | null>(null), [pollWarning, setPollWarning] = useState(false);
  const [health, setHealth] = useState<Health | null>(null), [healthChecking, setHealthChecking] = useState(false), [healthError, setHealthError] = useState(false);
  const searchController = useRef<AbortController | null>(null), pollController = useRef<AbortController | null>(null), healthController = useRef<AbortController | null>(null);
  const polling = useRef<ReturnType<typeof setTimeout> | null>(null), generation = useRef(0), mounted = useRef(true);
  const selectionMade=useRef(false);
  const t = text[lang], tRef = useRef(t); tRef.current = t;
  const requestLocked = busy || searching;

  const stopPolling = useCallback(() => {
    generation.current += 1;
    if (polling.current) clearTimeout(polling.current);
    polling.current = null; pollController.current?.abort(); pollController.current = null;
  }, []);
  const refreshHealth = useCallback(async () => {
    healthController.current?.abort(); const controller = new AbortController(); healthController.current = controller;
    setHealthChecking(true); const timeout = setTimeout(() => controller.abort(), 15000);
    try {
      const d = await api<Health>('/api/health', controller.signal);
      if (healthController.current !== controller || !mounted.current) return;
      setHealth(d); setHealthError(false);
    } catch {
      if (healthController.current !== controller || !mounted.current) return;
      setHealth(null); setHealthError(true);
    } finally {
      clearTimeout(timeout);
      if (healthController.current === controller && mounted.current) setHealthChecking(false);
    }
  }, []);
  useEffect(() => { document.documentElement.lang = lang; localStorage.setItem('sarwatch-language', lang); }, [lang]);
  useEffect(()=>{const controller=new AbortController(); fetch(API ? `${API}/api/presets` : '/presets/index.json',{signal:controller.signal}).then(r=>r.ok?r.json():Promise.reject()).then(d=>setPresets(d.presets||[])).catch(()=>{});return()=>controller.abort();},[]);
  useEffect(() => {
    mounted.current = true; let active = true; const controller = new AbortController();
    fetch(API ? `${API}/api/cases` : '/cases/index.json', { signal: controller.signal }).then(r => {
      if (!r.ok) throw Error(); return r.json();
    }).then((d: { cases?: Case[] }) => {
      if (!active) return;
      const cs = (d.cases || []).filter(c => c.ready_for_demo && c.layers?.some(l => l.id === 'before') && c.layers?.some(l => l.id === 'after'))
        .map(c => ({ ...c, layers: c.layers.map(l => ({ ...l, url: assetUrl(`/cases/${encodeURIComponent(c.id)}/${l.file}`) })) }))
        .sort((a, b) => Number(b.id === 'mozambique') - Number(a.id === 'mozambique'));
      setCases(cs);
      if (cs[0]&&!selectionMade.current) {
        const firstArea = cs[0].bbox || cs[0].layers[0].bounds;
        setCurrent(cs[0]); setArea(firstArea); setCenter([(firstArea[1] + firstArea[3]) / 2, (firstArea[0] + firstArea[2]) / 2]);
        setOverlay(cs[0].layers.some(l => l.id === 'water') ? 'water' : ''); setFit(n => n + 1);
      }
    }).catch(e => { if (active && !isAbort(e)) setError(tRef.current.assetsError); }).finally(() => { if (active) setLoadingCases(false); });
    return () => {
      active = false; mounted.current = false; controller.abort(); searchController.current?.abort(); healthController.current?.abort(); stopPolling();
    };
  }, [stopPolling]);
  useEffect(() => { if (mode === 'new') void refreshHealth(); }, [mode, refreshHealth]);

  const sequence = mode === 'new' ? job?.sequence?.steps : undefined;
  const step = sequence?.[stepIndex];
  const result = step?.result ?? job?.result;
  const assets = step?.assets ?? job?.assets;
  const activeLayers = useMemo(() => mode === 'case' ? current?.layers || [] : (result?.layers || []).map(l => ({ ...l, url: l.url ? assetUrl(l.url) : undefined })), [mode, current, result]);
  const intervalSources = mode === 'case' ? current?.sources || [] : result?.sources || [];
  const sources = sequence ? [sequence[0].result.sources[0], ...sequence.map(item => item.result.sources[1])] : intervalSources;
  const candidateStats = mode === 'case' ? current?.metrics : result?.water;
  const stats = candidateStats && finite(candidateStats.water_before_km2) && finite(candidateStats.water_after_km2) ? candidateStats : undefined;
  const comparison = mode === 'case' ? current?.comparison || current?.metrics : result?.comparison;
  const flood = mode === 'case' ? current?.flood : result?.flood;
  const reviewed = mode === 'case' && opticalChecked(current);
  const overlays = activeLayers.filter(l => ['water', 'potential_flood', 'flood'].includes(l.id));
  const firstArchiveDate = health?.landsat_start ?? LANDSAT_START;
  const firstRadarDate = health?.nisar_start ?? NISAR_START;
  const requestedDates = [start, end, ...extraDates].map(sceneDate).sort();
  const from = requestedDates[0], to = requestedDates[requestedDates.length - 1];
  const seriesMode = requestedDates.length > 2;
  const hasMatch = !!(seriesMode ? catalog?.series?.length : catalog?.pairs.length);
  const archiveByDate = sourceChoice !== 'landsat' && sourceChoice !== 'modis' && !!from && from < firstRadarDate;
  const archiveSearch = sourceChoice === 'landsat' || archiveByDate;
  const activeSensor = mode === 'case' ? current?.sensor ?? 'nisar'
    : result?.sensor ?? catalog?.sensor ?? (archiveSearch ? 'landsat' : sourceChoice === 'modis' ? 'modis' : 'nisar');
  const optical = activeSensor !== 'nisar';
  const overview = activeSensor === 'modis';
  const dataAvailable = optical || health?.data_access_configured;
  const serviceReady = health?.status === 'ok' && dataAvailable && !healthError;
  const serviceText = healthChecking ? t.serviceChecking : healthError ? t.serviceOffline : !health ? t.serviceChecking : !dataAvailable ? t.serviceMissing : health.analysis_busy && !busy ? t.serviceBusy : t.serviceReady;
  const validDates = !!from && new Set(requestedDates).size === requestedDates.length && to <= new Date().toISOString().slice(0, 10)
    && from >= (sourceChoice === 'modis' ? '2000-02-24' : firstArchiveDate);
  const shownTheme = mode === 'case' ? current?.theme || 'water' : theme;

  function resetResult() { stopPolling(); setJob(null); setError(''); setPollWarning(false); setEpoch('after'); setStepIndex(0); setOverlay(''); }
  function selectArea(lat: number, lon: number) {
    if (requestLocked) return;
    selectionMade.current=true;
    const next = square(lat, lon, side);
    if (!validArea(next)) { setError(t.invalidArea); return; }
    resetResult(); setPresetId(''); setCenter([lat, lon]); setArea(next); setCatalog(null);
  }
  function choosePreset(p:Preset){
    if(requestLocked)return;
    selectionMade.current=true;
    resetResult();setMode('new');setPresetId(p.id);setTheme(p.theme ?? 'water');setSide(p.side_km);setCenter([p.lat,p.lon]);setArea(square(p.lat,p.lon,p.side_km));setStart(p.start);setEnd(p.end);setExtraDates([]);setMaturity(p.maturity ?? 'PROVISIONAL');setSourceChoice(p.sensor ?? 'auto');setCatalog(null);setFit(v=>v+1);
  }
  function chooseCase(c: Case) {
    selectionMade.current=true;
    const nextArea = c.bbox || c.layers[0].bounds;
    resetResult(); setCurrent(c); setArea(nextArea); setCenter([(nextArea[1] + nextArea[3]) / 2, (nextArea[0] + nextArea[2]) / 2]);
    setOverlay(c.layers.some(l => l.id === 'water') ? 'water' : ''); setFit(n => n + 1);
  }
  function switchMode(value: 'case' | 'new') {
    if (requestLocked) return;
    selectionMade.current=true;
    resetResult(); setMode(value);
    if (value === 'case' && current) chooseCase(current);
    else { setArea(square(...center, side)); setCatalog(null); setFit(n => n + 1); }
  }
  function updateDate(which: 'start' | 'end', value: string) {
    resetResult(); setPresetId(''); setCatalog(null); setCatalogNote('');
    if (which === 'start') setStart(value); else setEnd(value);
    const parsed = sceneDate(value);
    if (sourceChoice === 'nisar' && parsed && parsed < firstRadarDate) setSourceChoice('auto');
  }
  function updateExtraDates(dates: string[]) {
    resetResult(); setPresetId(''); setCatalog(null); setCatalogNote(''); setExtraDates(dates);
  }

  function selectEpoch(index: number) {
    if (sequence) {
      setStepIndex(Math.max(0, index - 1));
      setOverlay('');
    }
    setEpoch(index === 0 ? 'before' : 'after');
  }
  async function find(choice: SourceChoice = sourceChoice) {
    if (requestLocked) return;
    if (!validDates) { setError(t.dateInvalid); return; }
    setStart(from); setEnd(seriesMode ? requestedDates[1] : to); setExtraDates(requestedDates.slice(2));
    resetResult(); setCatalog(null); setCatalogNote(''); setSearching(true);
    const controller = new AbortController(); searchController.current?.abort(); searchController.current = controller;
    const timeout = setTimeout(() => controller.abort(), 120000);
    try {
      const sensor = choice === 'nisar' && from < firstRadarDate ? 'auto' : choice;
      const query = new URLSearchParams({bbox:area.join(','), maturity, sensor, theme});
      if (seriesMode) requestedDates.forEach(value => query.append('dates', value));
      else { query.set('start', from); query.set('end', to); }
      const d = await api<Catalog>(`/api/${seriesMode ? 'series' : 'scenes'}?${query}`, controller.signal);
      if (searchController.current !== controller || !mounted.current) return;
      if (!Array.isArray(d.scenes) || !Array.isArray(d.pairs)) throw Error('Invalid catalogue');
      const chosen=presets.find(p=>p.id===presetId);
      const recommended=chosen?d.pairs.findIndex(p=>p.before===chosen.before_id&&p.after===chosen.after_id):-1;
      setCatalog(d);
      setPair(recommended >= 0 ? recommended : sensor === 'nisar' ? Math.max(0, d.pairs.length - 1) : 0);
      if (seriesMode && !d.series?.length) setCatalogNote(tRef.current.seriesEmpty);
      if (!seriesMode && !d.pairs.length) setCatalogNote(d.sensor === 'nisar' ? tRef.current.noPairs : tRef.current.archiveEmpty);
    } catch (e) { if (mounted.current && searchController.current === controller) setError(message(e, tRef.current)); }
    finally { clearTimeout(timeout); if (mounted.current && searchController.current === controller) setSearching(false); }
  }
  function pollJob(id: string) {
    stopPolling(); const revision = generation.current; let failures = 0;
    setBusy(true); setError(''); setPollWarning(false);
    const poll = async () => {
      if (!mounted.current || generation.current !== revision) return;
      const controller = new AbortController(); pollController.current = controller;
      const timeout = setTimeout(() => controller.abort(), 20000);
      try {
        const d = await api<Job>(`/api/analyses/${encodeURIComponent(id)}`, controller.signal);
        if (!mounted.current || generation.current !== revision) return;
        failures = 0; setPollWarning(false); setJob(d);
        if (d.status === 'completed' && (d.result || d.sequence)) {
          const lastIndex = (d.sequence?.steps.length ?? 1) - 1;
          const last = d.sequence?.steps[lastIndex].result ?? d.result;
          setStepIndex(lastIndex); setBusy(false); setOverlay(last?.layers.some(l => l.id === 'water') ? 'water' : ''); setEpoch('after'); setFit(n => n + 1); void refreshHealth(); return;
        }
        if (d.status === 'failed') { setError(tRef.current.requestFailed); setBusy(false); void refreshHealth(); return; }
      } catch (e) {
        if (!mounted.current || generation.current !== revision) return;
        if (e instanceof ApiError && [404, 409, 422].includes(e.status)) { setError(message(e, tRef.current)); setBusy(false); void refreshHealth(); return; }
        failures += 1; setPollWarning(true);
      } finally { clearTimeout(timeout); }
      polling.current = setTimeout(poll, failures ? Math.min(15000, 3000 * failures) : 3000);
    };
    void poll();
  }
  async function run() {
    if (requestLocked || !serviceReady || !catalog || !hasMatch) return;
    const selected = catalog.pairs[pair];
    const preset = selected && presets.find(p => p.id === presetId && p.theme === theme &&
      p.before_id === selected.before && p.after_id === selected.after);
    const observations = seriesMode ? {scene_ids: catalog.series} : {before_id: selected.before, after_id: selected.after};
    resetResult(); setBusy(true);
    const controller = new AbortController(); pollController.current = controller;
    const timeout = setTimeout(() => controller.abort(), 30000);
    try {
      const r = await api<Job>('/api/analyses', controller.signal, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ bbox: area, side_km:side, ...observations, sensor: catalog.sensor ?? 'nisar', theme, channel: preset?.channel ?? 'auto' }) });
      if (!mounted.current) return;
      setJob(r); pollJob(r.id);
    } catch (e) { if (mounted.current) { setError(message(e, tRef.current)); setBusy(false); void refreshHealth(); } }
    finally { clearTimeout(timeout); }
  }

  const pdf = mode === 'case' && current ? assetUrl(`/cases/${current.id}/report-${lang}.pdf`) : assets?.reports?.[lang] ? assetUrl(assets.reports[lang]!) : null;
  const preview = current?.previews?.[lang] || current?.previews?.ru || current?.previews?.en;
  const download = mode === 'case' && current && preview ? assetUrl(`/cases/${current.id}/${preview}`) : assets?.comparison ? `${assetUrl(assets.comparison)}?lang=${lang}` : null;
  const resultTitle = mode === 'case' ? !current ? loadingCases ? t.loading : t.noCases : local(current.interpretation, lang) || (stats ? t.experimental : t.noWaterMetrics)
    : busy ? t.running : !result ? t.empty : overview ? t.overviewHint : optical ? stats ? t.archiveResult : t.opticalImages : stats ? t.unverified : theme === 'water' ? t.unavailable : t.noWaterMetrics;
  const channel = candidateStats?.channel || (mode === 'case' ? current?.observations : result?.observations)?.[0]?.channel;
  const statusLabel = mode === 'case' ? !current ? t.noCases : reviewed ? t.reviewed : t.realCase : busy ? job?.status === 'waiting' ? t.waiting : t.running : result ? t.unverified : t.mapTip;
  const referenceEntries = reviewed ? Object.entries(current?.reference_checks || {}) : [];
  const weatherUrl = mode === 'case' && current ? `/api/cases/${encodeURIComponent(current.id)}/weather`
    : job?.status === 'completed' ? `/api/analyses/${encodeURIComponent(job.id)}/weather` : null;

  return <div className="app">
    <header><a href="/" className="brand"><span className="brand-icon"><Radar size={26} /></span>SAR<span>Watch</span><span className="version">0.9</span></a><div className="header-center"><Satellite size={15} /> NASA Space Apps 2026 <span> / </span> Dancing with the SARs</div><div className="header-right"><span className="prototype"><i />{t.prototype}</span><div className="languages">{languages.map(l => <button key={l} lang={l} title={{en:'English',ru:'Русский',kk:'Қазақша'}[l]} className={lang === l ? 'on' : ''} aria-pressed={lang === l} onClick={() => setLang(l)}>{l.toUpperCase()}</button>)}</div></div></header>
    <div className="workspace">
      <aside>
        <div className="eyebrow"><span />{t.tag}</div><h1>{t.title}</h1><p className="intro">{t.intro}</p>
        <div className="mode-tabs"><button disabled={requestLocked} className={mode === 'case' ? 'active' : ''} onClick={() => switchMode('case')}>{t.ready}</button><button disabled={requestLocked} className={mode === 'new' ? 'active' : ''} onClick={() => switchMode('new')}>{t.custom}</button></div>
        {presets.length>0&&<div className="preset-picker"><label htmlFor="location-preset">{t.presets}</label><select id="location-preset" value={presetId} disabled={requestLocked} onChange={e=>{const p=presets.find(p=>p.id===e.target.value);if(p)choosePreset(p);}}><option value="">—</option>{presets.map(p=><option key={p.id} value={p.id}>{local(p.title,lang)} · {p.side_km} km</option>)}</select>{presetId&&<p className="hint">{local(presets.find(p=>p.id===presetId)?.note,lang)}</p>}<p className="hint small-hint">{t.presetHint}</p></div>}
        {mode === 'case' ? <>
          <div className="section-label">{t.prepared}</div>
          {loadingCases && <p className="hint" role="status">{t.loading}</p>}
          {!loadingCases && !cases.length && <div className="empty-cases"><Layers size={28} /><h2>{t.noCases}</h2><p>{t.noCasesHint}</p><button className="primary full" onClick={() => switchMode('new')}>{t.custom}<ChevronRight size={15} /></button></div>}
          <div className="case-list">{cases.map((c, i) => {
            const Icon = themes[c.theme || 'water'] || Radar;
            const story = local(c.story || c.description || c.summary, lang);
            return <button className={'case-card ' + (current?.id === c.id ? 'chosen' : '')} aria-pressed={current?.id === c.id} key={c.id} onClick={() => chooseCase(c)}>
              <div className={'case-art theme-' + (c.theme || 'water')}><div className="case-ring" /><Icon size={30} /><span>{String(i + 1).padStart(2, '0')}</span></div>
              <div className="case-card-body"><div className="tiny-tag">{c.sensor === 'landsat' ? 'Landsat' : 'NISAR'} · {t[c.theme || 'water']}</div><strong>{local(c.title, lang)}</strong>{story && <p>{story}</p>}<div className="case-date">{date(c.sources?.[0]?.start)} / {date(c.sources?.[1]?.start)}</div><div className="checked"><span>{opticalChecked(c) ? '✓' : '↗'}</span>{opticalChecked(c) ? t.reviewed : t.realCase}<ChevronRight size={16} /></div></div>
            </button>;
          })}</div>
          {cases.length > 0 && <div className="quiet-note"><Info size={16} /><span>{t.method}</span></div>}
        </> : <>
          <div className={'service-state ' + (healthError || (health && !dataAvailable) ? 'unavailable' : '')} role="status"><span>{healthChecking ? <LoaderCircle className="spin" size={14} /> : <i className="live-dot" />}{serviceText}</span><button aria-label={t.refresh} title={t.refresh} disabled={healthChecking || busy} onClick={() => void refreshHealth()}><RefreshCw size={15} /></button></div>
          <label htmlFor="scene-source">{t.sensor}</label>
          <select id="scene-source" value={sourceChoice} disabled={requestLocked} onChange={e => {
            const choice = e.target.value as SourceChoice;
            resetResult(); setCatalog(null); setCatalogNote(''); setPresetId(''); setSourceChoice(choice);
          }}><option value="auto">{t.autoSensor}</option><option value="nisar">NISAR L-band</option><option value="landsat">{t.archive}</option><option value="modis">{t.overview}</option></select>
          <div className="themes">{(Object.entries(themes) as [Theme, typeof Droplets][]).map(([name, Icon]) => <button disabled={requestLocked} key={name} onClick={() => { resetResult(); setTheme(name); setCatalog(null); }} className={theme === name ? 'active' : ''} aria-pressed={theme === name}><Icon size={16} />{t[name]}</button>)}</div>
          <div className="section-label">{t.area}</div><p className="hint">{t.click}</p>
          <div className="area-sizes">{(health?.area_sizes_km ?? AREA_SIZES).map(n=><button key={n} className={side===n?'active':''} aria-pressed={side===n} disabled={requestLocked} onClick={()=>{const next=square(...center,n);if(!validArea(next)){setError(t.invalidArea);return;}resetResult();setPresetId('');setSide(n);setArea(next);setCatalog(null);setFit(v=>v+1);}}>{n} × {n}</button>)}</div>
          <label htmlFor="area-side">{t.side}<input id="area-side" type="range" min="1" max={health?.max_side_km ?? 100} step="1" value={side} disabled={requestLocked} onChange={e => {
            const n = +e.target.value, next = square(...center, n);
            if (!validArea(next)) { setError(t.invalidArea); return; }
            resetResult(); setPresetId(''); setSide(n); setArea(next); setCatalog(null); setFit(v => v + 1);
          }} /><span>{side.toFixed(1)} × {side.toFixed(1)} km</span></label>
          <p className="hint">{t.nominalArea}: <strong>{(side*side).toLocaleString(lang)} {t.units}</strong></p>{side>10&&<p className="hint small-hint">{t.coarse}</p>}
          <div className="coordinate"><MapPin size={14} />{Math.abs(center[0]).toFixed(4)}° {center[0] >= 0 ? 'N' : 'S'}, {Math.abs(center[1]).toFixed(4)}° {center[1] >= 0 ? 'E' : 'W'}</div>
          <div className="date-inputs">
            <label htmlFor="date-start">{seriesMode ? `${t.dateLabel} 1` : t.dateBefore}
              <input id="date-start" type="text" autoComplete="off" spellCheck={false} placeholder="YYYY-MM-DD"
                value={start} disabled={requestLocked} onChange={e => updateDate('start', e.currentTarget.value)}
                onKeyDown={e => { if (e.key === 'Enter') void find(); }} />
            </label>
            <label htmlFor="date-end">{seriesMode ? `${t.dateLabel} 2` : t.dateAfter}
              <input id="date-end" type="text" autoComplete="off" spellCheck={false} placeholder="YYYY-MM-DD"
                value={end} disabled={requestLocked} onChange={e => updateDate('end', e.currentTarget.value)}
                onKeyDown={e => { if (e.key === 'Enter') void find(); }} />
            </label>
          </div>
          {extraDates.map((value, index) => <div className="extra-date" key={index}>
            <label htmlFor={`date-${index+3}`}>{t.dateLabel} {index+3}
              <input id={`date-${index+3}`} type="text" autoComplete="off" spellCheck={false} placeholder="YYYY-MM-DD" value={value} disabled={requestLocked}
                onChange={e => updateExtraDates(extraDates.map((item, i) => i === index ? e.currentTarget.value : item))}
                onKeyDown={e => { if (e.key === 'Enter') void find(); }} />
            </label>
            <button className="secondary" aria-label={`${t.removeDate} ${index+3}`} title={t.removeDate} disabled={requestLocked} onClick={() => updateExtraDates(extraDates.filter((_, i) => i !== index))}>×</button>
          </div>)}
          {requestedDates.length < (health?.max_dates ?? 6) && <button className="secondary add-date" disabled={requestLocked} onClick={() => updateExtraDates([...extraDates, ''])}>+ {t.addDate}</button>}
          {!archiveSearch && sourceChoice !== 'modis' && <><label className="maturity-label" htmlFor="data-maturity">{t.maturity}</label><select id="data-maturity" disabled={requestLocked} value={maturity} onChange={e => { resetResult(); setPresetId(''); setMaturity(e.target.value); setCatalog(null); }}><option>BETA</option><option>PROVISIONAL</option><option>VALIDATED</option></select></>}
          {archiveSearch && <p className="hint small-hint">{archiveByDate ? t.archiveAuto : t.archiveHint}</p>}
          {sourceChoice === 'auto' && from >= firstRadarDate && <p className="hint small-hint">{t.nisarAuto}</p>}
          {sourceChoice === 'modis' && <p className="hint small-hint">{t.overviewHint}</p>}
          <button className="secondary full" disabled={requestLocked} onClick={() => void find()}>{searching ? <LoaderCircle className="spin" size={16} /> : <Search size={16} />}{searching ? t.finding : t.find}</button>
          {catalogNote && catalog && !hasMatch && <p className="hint" role="status">{catalog.sensor === 'nisar' ? seriesMode ? t.nisarSeriesEmpty : t.noPairs : seriesMode ? t.seriesEmpty : t.archiveEmpty}</p>}
          {!!catalog?.series?.length && <p className="hint" role="status">{t.seriesFound}<br />{catalog.scenes.map(scene => date(scene.start)).join(' → ')}</p>}
          {sourceChoice === 'auto' && catalog?.sensor === 'nisar' && !hasMatch &&
            <button className="secondary full" disabled={requestLocked} onClick={() => {
              setSourceChoice('landsat'); void find('landsat');
            }}>{t.archive}</button>}
          {sourceChoice !== 'modis' && from >= '2000-02-24' && catalog && catalog.sensor !== 'modis' &&
            (!hasMatch || job?.status === 'failed') &&
            <button className="secondary full" disabled={requestLocked} onClick={() => {
              setSourceChoice('modis'); void find('modis');
            }}>{t.overview}</button>}
          {catalog && catalog.pairs.length > 0 && <><label htmlFor="scene-pair">{t.pair}<select id="scene-pair" value={pair} disabled={requestLocked} onChange={e => { resetResult(); setPair(+e.target.value); }}>{catalog.pairs.map((p, i) => {
            const a = catalog.scenes.find(s => s.id === p.before), b = catalog.scenes.find(s => s.id === p.after);
            return <option key={`${p.before}-${p.after}`} value={i}>{date(a?.start)} / {date(b?.start)} · {optical ? [a?.platform, b?.platform].join(' / ') : 'T' + a?.track + ' F' + a?.frame}</option>;
          })}</select></label><p className="hint small-hint">{overview ? t.overviewHint : optical ? t.archiveHint : t.pairNote}</p>{!optical && <details className="browse-overviews"><summary>{t.browse}</summary><p className="hint">{t.browseHint}</p><div>{[catalog.pairs[pair].before,catalog.pairs[pair].after].map((id,i)=>{const s=catalog.scenes.find(s=>s.id===id);return s?.browse_preview_url?<figure key={id}><img src={assetUrl(s.browse_preview_url)} alt={`${i===0?t.before:t.after}: ${date(s.start)}`} loading="lazy"/><figcaption>{i===0?t.before:t.after} · {date(s.start)}</figcaption></figure>:null;})}</div></details>}</>}
          {(catalog?.potentially_truncated || catalog?.potentially_incomplete || catalog?.truncated) && <p className="hint warning-text">{t.partial}</p>}
          <button className="primary full" disabled={requestLocked || !serviceReady || !hasMatch} onClick={() => void run()}>{busy ? <LoaderCircle className="spin" size={17} /> : <Radar size={17} />}{busy ? t.running : t.run}</button>
          {busy && <p className="hint" role="status">{pollWarning ? t.retryPoll : job?.status === 'waiting'
            ? job.queue_position ? `${t.queued} · ${job.queue_position}` : t.waiting : job?.progress ? `${t.interval} ${job.progress.completed + 1} / ${job.progress.total}` : t.wait}</p>}
          {!busy && job && job.status !== 'completed' && job.status !== 'failed' && <button className="secondary full" onClick={() => pollJob(job.id)}>{t.retryResult}</button>}
          {job && <p className="job-id">{t.job}: {job.id}</p>}
        </>}
        {error && <div className="error" role="alert">{error}</div>}
        <div className="sidebar-bottom"><span className="live-dot" />{t.data}<ArrowUpRight size={14} /></div>
      </aside>
      <main>
        <div className="map-wrap">
          <MapView layers={activeLayers} epoch={epoch} overlay={overlay} opacity={opacity} area={mode === 'case' && !current ? OVERVIEW_BOUNDS : area} showArea={mode === 'new' || !!current} selectable={mode === 'new' && !requestLocked} onSelect={selectArea} fit={fit} lang={lang} basemap={basemap} />
          <div className="map-heading"><span className="map-heading-icon"><MapPin size={18} /></span><div><strong>{mode === 'case' ? local(current?.title, lang) || t.ready : t.newArea}</strong><span>{statusLabel}</span></div><span className="satellite-badge">{overview ? 'NASA MODIS' : optical ? 'Landsat' : 'NISAR L-band'}</span></div>
          <button className="fit-button" title={t.fit} aria-label={t.fit} onClick={() => setFit(n => n + 1)}><LocateFixed size={19} /></button>
          <div className="basemap-picker"><Layers size={15} aria-hidden="true" />
            <select aria-label={t.mapLayers} value={basemap} onChange={e => setBasemap(e.target.value as Basemap)}>
              <option value="default">{t.defaultMap}</option>
              <option value="satellite">{t.satellite}</option>
            </select>
          </div>
          {activeLayers.length > 0 && <div className="map-controls">
            <div className="period"><span className="control-label">{t.dates}</span><div className="timeline">{sources.map((scene, index) => {
              const selected = epoch !== 'delta' && index === (sequence ? stepIndex : 0) + (epoch === 'before' ? 0 : 1);
              return <button key={scene.id} onClick={() => selectEpoch(index)} className={selected ? 'active' : ''} aria-pressed={selected}>
                <span>{sequence ? `${t.dateLabel} ${index+1}` : index === 0 ? t.before : t.after}</span><strong>{date(scene.start)}</strong>
              </button>;
            })}{activeLayers.some(l => l.id === 'delta') && <button onClick={() => { setEpoch('delta'); setOverlay(''); }} className={epoch === 'delta' ? 'active' : ''} aria-pressed={epoch === 'delta'}><span>Δ dB</span><strong>{t.delta}</strong></button>}</div></div>
            {overlays.length > 0 && <div className="layer-switch"><Layers size={16} /><div className="overlay-options">{overlays.map(l => <label key={l.id}><input type="checkbox" checked={overlay === l.id} onChange={e => setOverlay(e.target.checked ? l.id : '')} />{local(l.label, lang) || (l.id === 'water' ? t.layer : t.potential_flood)}</label>)}</div>{overlay && <input aria-label={t.opacity} type="range" min="0" max="1" step=".05" value={opacity} onChange={e => setOpacity(+e.target.value)} />}</div>}
          </div>}
        </div>
        <section className="results" aria-live="polite">
          <div className="result-title"><div><div className="section-label">{mode === 'case' && !current ? t.prepared : stats ? t.coverage : optical ? t.visualComparison : t.radar.toUpperCase()}</div><h2>{resultTitle}</h2></div><div className="exports">{pdf && <a className="secondary" href={pdf} download target="_blank" rel="noreferrer"><Download size={16} />{t.pdf}</a>}{download && <a className="secondary" href={download} download target="_blank" rel="noreferrer"><Download size={16} />{t.download}</a>}</div></div>
          {mode === 'case' && !current && !loadingCases && <p className="hint">{t.noCasesHint}</p>}
          {weatherUrl && <WeatherContext key={weatherUrl} url={assetUrl(weatherUrl)} lang={lang} theme={shownTheme} />}
          {sequence && <label className="interval-selector">{t.interval}<select value={stepIndex} onChange={e => {
            setStepIndex(+e.target.value); setEpoch('after'); setOverlay('');
          }}>{sequence.map((item, i) => <option key={i} value={i}>{item.result.sources.map(scene => date(scene.start)).join(' → ')}</option>)}</select></label>}
          {epoch === 'delta' && <p className="result-note">{t.deltaHint}</p>}
          {overlay && overlay !== 'water' && <p className="result-note warning-text"><Info size={14} />{t.floodNote}</p>}
          {stats && <><div className="metrics"><div><span>{t.prior}</span><strong>{stats.water_before_km2!.toFixed(3)} <small>{t.units}</small></strong></div><div><span>{t.later}</span><strong>{stats.water_after_km2!.toFixed(3)} <small>{t.units}</small></strong></div><div className="legend"><span><i className="stable" />{t.stable}</span><span><i className="gain" />{t.gain}{finite(stats.water_gain_km2) ? ` · ${stats.water_gain_km2.toFixed(3)} ${t.units}` : ''}</span><span><i className="loss" />{t.loss}{finite(stats.water_loss_km2) ? ` · ${stats.water_loss_km2.toFixed(3)} ${t.units}` : ''}</span></div></div><p className="result-note"><Info size={14} />{optical ? t.archiveNote : t.note}</p></>}
          {flood?.status === 'experimental' && <section className="flood-summary"><div className="section-label">{t.floodScreen}</div><div className="metrics"><div><span>{t.floodArea}</span><strong>{finite(flood.candidate_area_km2) ? flood.candidate_area_km2.toFixed(3) : '—'} <small>{t.units}</small></strong></div>{finite(flood.assessed_fraction) && <div><span>{t.floodAssessed}</span><strong>{(flood.assessed_fraction * 100).toFixed(1)} <small>%</small></strong></div>}</div><p className="result-note"><Info size={14} />{t.floodNote}</p></section>}
          {flood?.status === 'unavailable' && <p className="result-note warning-text"><Info size={14} /><span>{t.floodUnavailable}</span></p>}
          {!stats && comparison && finite(comparison.median_delta_db) && <div className="metrics signal-metrics"><div><span>{t.median}</span><strong>{comparison.median_delta_db.toFixed(2)} <small>dB</small></strong></div>{finite(comparison.comparable_pixels) && <div><span>{t.overlap}</span><strong>{comparison.comparable_pixels.toLocaleString(lang)}</strong></div>}</div>}
          {optical && stats && finite(comparison?.finite_overlap_fraction) && finite(stats.comparable_area_km2) &&
            <p className="measurement">{t.comparable}: {(100 * comparison.finite_overlap_fraction).toFixed(1)}% · {stats.comparable_area_km2.toFixed(1)} {t.units}</p>}
          {mode === 'new' && result && <p className="result-note">{t.noReference}</p>}
          {mode === 'new' && result && finite(result.elapsed_seconds) && <p className="measurement">{t.measured}: {result.elapsed_seconds.toFixed(1)} {t.seconds}{finite(result.transferred_bytes) ? ` · ${(result.transferred_bytes / 1000000).toFixed(2)} MB` : ''}</p>}
          {(mode==='case'?current?.observations:result?.observations)?.[0]?.pixel_spacing_m&&<p className="measurement">{t.grid}: {(mode==='case'?current?.observations:result?.observations)?.[0]?.pixel_spacing_m?.join(' × ')} m</p>}
          {sources.length > 0 && <details><summary>{t.sources}<ChevronRight size={15} /></summary><p>{overview ? t.overviewHint : optical ? stats ? t.archiveMethod : t.opticalImages : shownTheme === 'water' ? t.waterMethod : t.signalMethod}{channel ? ` ${channel}.` : ''}</p>{sources.map((s, i) => <div className="source" key={`${s.id}-${i}`}><strong>{sequence ? `${t.dateLabel} ${i+1}` : i === 0 ? t.before : t.after}: {date(s.start)} UTC</strong>
            <small>{optical ? s.platform : <>{s.maturity} · CRID {s.crid} · track {s.track} / frame {s.frame}</>}</small>
            <div className="scene-links">
              {sceneLinks(s, activeSensor, t).filter(link => link.href.startsWith('https://') || link.href.startsWith('/api/scenes/')).map(link =>
                <a key={link.href} href={link.href} title={'title' in link ? link.title : undefined} target="_blank" rel="noreferrer">{link.label} ↗</a>)}
              {!optical && (s.browse_urls?.length || s.browse?.length) ? <details className="scene-preview">
                <summary>{t.browse}</summary>
                <a href={assetUrl(`/api/scenes/${encodeURIComponent(s.id)}/browse.png`)} target="_blank" rel="noreferrer">
                  <img src={assetUrl(`/api/scenes/${encodeURIComponent(s.id)}/browse.png`)} alt={t.scenePreview} loading="lazy" />
                </a>
              </details> : null}
            </div></div>)}{referenceEntries.length > 0 && <div className="reference-details"><strong>{t.reference}</strong>{referenceEntries.map(([key, check]) => <p key={key}>{key === 'before' ? t.before : key === 'after' ? t.after : key}: {check.reference_id} · {date(check.reference_time)}{finite(check.iou_vs_reference) ? ` · IoU ${check.iou_vs_reference.toFixed(4)}` : ''}</p>)}</div>}{flood && flood.status !== 'not_requested' && <div className="reference-details flood-source-details"><strong>{t.floodSources}</strong>{flood.sources?.map(source => <p key={source.name}>{source.url?.startsWith('https://') ? <a href={source.url} target="_blank" rel="noreferrer">{source.name} ↗</a> : source.name}{source.attribution && <small>{source.attribution}</small>}</p>)}{flood.limitations?.map(limit => <p key={limit}>{limit}</p>)}</div>}{mode === 'case' && current?.event_sources?.map(source=><p key={source.url}><a href={source.url} target="_blank" rel="noreferrer">{source.title} ↗</a></p>)}{(mode === 'case' ? current?.attribution : job?.result?.attribution)?.map(a => <p className="attribution" key={a}>{a}</p>)}</details>}
        </section>
      </main>
    </div>
    <footer><span>SARWatch <span>·</span> NASA–ISRO Synthetic Aperture Radar</span><span>NASA / JPL / ASF <span>·</span> USGS Landsat</span></footer>
  </div>;
}

class ErrorBoundary extends React.Component<{ children: React.ReactNode }, { failed: boolean }> {
  state = { failed: false };
  static getDerivedStateFromError() { return { failed: true }; }
  render() {
    if (this.state.failed) {
      const t = text[languages.find(language => language === document.documentElement.lang) ?? 'en'];
      return <main className="fatal-error"><h1>SARWatch</h1><p>{t.crash}</p><button className="primary" onClick={() => window.location.reload()}>{t.reload}</button></main>;
    }
    return this.props.children;
  }
}

createRoot(document.getElementById('root')!).render(<React.StrictMode><ErrorBoundary><App /></ErrorBoundary></React.StrictMode>);
